/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { TdsSectionInfo } from '../types';

export const TDS_SECTIONS_DATA: TdsSectionInfo[] = [
  {
    section: "192",
    title: "Salary Income",
    category: "Salary (Form 24Q)",
    threshold: 250000, // No tax up to basic exemption, custom calculated
    rateInd: 0, // Calculated dynamically based on Slabs
    rateCo: 0,
    provisions: "Tax is to be deducted at source by employer based on average rate of income tax of the employee computed on estimated income for the financial year. Employees can choose between the Old Regime (with exemptions like 80C, 80D, HRA) and the New Regime (default under section 115BAC with lower slab rates but no standard deductions/exemptions except standard deduction of Rs. 75,000 as updated for FY 2025-26).",
    formType: "24Q"
  },
  {
    section: "194C",
    title: "Payments to Contractors & Sub-contractors",
    category: "Non-Salary (Form 26Q)",
    threshold: 30000, // 30,000 single or 100,000 aggregate
    rateInd: 1, // 1% for Individual/HUF
    rateCo: 2, // 2% for Partnerships/Companies
    provisions: "Deductible on single contracts exceeding Rs. 30,000 or annual aggregate exceeding Rs. 1,00,000. Under sub-section (6), no tax is deducted if contractor is in transport business, owns <= 10 goods carriages, and provides PAN.",
    formType: "26Q"
  },
  {
    section: "194J",
    title: "Fees for Professional or Technical Services",
    category: "Non-Salary (Form 26Q)",
    threshold: 30000,
    rateInd: 10, // 10% professional, 2% technical / royalty / call centers
    rateCo: 10,
    provisions: "Professional services (10%), Technical services / Royalty or sale of product (2%), call center operators (2%). For FY 2025-26, thresholds remain at Rs. 30,000 per annum, except no threshold for payments to directors.",
    formType: "26Q"
  },
  {
    section: "194I(a)",
    title: "Rent on Plant & Machinery",
    category: "Non-Salary (Form 26Q)",
    threshold: 240000,
    rateInd: 2,
    rateCo: 2,
    provisions: "Rent paid on plant, machinery, or equipment. Threshold of Rs. 2,40,000 per annum applies. No tax is deducted if annual rent doesn't exceed this limit.",
    formType: "26Q"
  },
  {
    section: "194I(b)",
    title: "Rent on Land, Building, or Furniture",
    category: "Non-Salary (Form 26Q)",
    threshold: 240000,
    rateInd: 10,
    rateCo: 10,
    provisions: "Rent paid on land, building, furniture, or fittings. Threshold of Rs. 2,40,000 per annum. For co-owners, the Rs. 2,40,000 threshold applies to each co-owner's share individually.",
    formType: "26Q"
  },
  {
    section: "194A",
    title: "Interest Other Than Interest on Securities",
    category: "Non-Salary (Form 26Q)",
    threshold: 40000, // 40,000/50,000 for senior citizens
    rateInd: 10,
    rateCo: 10,
    provisions: "Deduction on interest from bank deposits, post office scheme deposits. Post FY 2024, threshold is Rs. 40,000 (standard limit) or Rs. 50,000 (Senior Citizens). Normal rate is 10%, or 20% if PAN is not furnished.",
    formType: "26Q"
  },
  {
    section: "194H",
    title: "Commission or Brokerage",
    category: "Non-Salary (Form 26Q)",
    threshold: 15000,
    rateInd: 5,
    rateCo: 5,
    provisions: "Commission or brokerage agreements. Deduction of 5% on amounts exceeding Rs. 15,000 per year. No deduction under Section 194H on commission payable by BSNL/MTNL to public phone booth operators.",
    formType: "26Q"
  },
  {
    section: "195",
    title: "Other Sums Payable to Non-Residents (NRI)",
    category: "NRI (Form 27Q)",
    threshold: 0, // No minimum threshold
    rateInd: 30, // Base rate is usually high (30%+ according to nature of income / DTAA)
    rateCo: 40,
    provisions: "Any payment to a Non-Resident Indian or foreign company which is chargeable to tax in India. Rates are dependent on specific categories of payments, or as per Double Taxation Avoidance Agreements (DTAA). Form 15CA and Form 15CB are required to be furnished during remittance.",
    formType: "27Q"
  },
  {
    section: "206C",
    title: "Tax Collection at Source (TCS) on Scrap/Timber",
    category: "TCS (Form 27EQ)",
    threshold: 0,
    rateInd: 1, // Scrap 1%, Timber 2.5%, Tendu leaves 5%
    rateCo: 1,
    provisions: "Sellers of Scrap, Timber, Tendu Leaves, Minerals, etc., must collect tax from buyers. Scrap is 1%, coal/lignite is 1%. Remitted to government using Form 27EQ.",
    formType: "27EQ"
  },
  {
    section: "206C(1G)",
    title: "TCS on Overseas Remittance (LRS)",
    category: "TCS (Form 27EQ)",
    threshold: 700000,
    rateInd: 20, // 5% for education/medical below limit, 20% others above 7L
    rateCo: 20,
    provisions: "Liberalized Remittance Scheme (LRS) or sale of overseas tour program packages. Threshold of Rs. 7,00,000. 5% if for education financed by loan; 5% for education/medical; 20% for other remittances beyond Rs. 7 Lakhs.",
    formType: "27EQ"
  }
];

export const OLD_VS_NEW_SCHEME = {
  title: "Tax Slab Comparison - FY 2025-26",
  description: "Budget 2024 & revised 2025 rules updated the default New Tax Regime with an increased standard deduction and revised brackets, offering a simplified tax structure with lower rates.",
  standardDeduction: {
    old: 50000,
    new: 75000
  },
  slabs: {
    old: [
      { min: 0, max: 250000, rate: 0 },
      { min: 250001, max: 500000, rate: 5 },
      { min: 500001, max: 1000000, rate: 20 },
      { min: 1000001, max: 999999999, rate: 30 }
    ],
    new: [
      { min: 0, max: 400000, rate: 0 },
      { min: 400001, max: 800000, rate: 5 },
      { min: 800001, max: 1200000, rate: 10 },
      { min: 1200001, max: 1600000, rate: 15 },
      { min: 1600001, max: 2000000, rate: 22 },
      { min: 2000001, max: 999999999, rate: 30 }
    ]
  },
  tips: [
    "The New Tax Regime is the DEFAULT tax regime unless specifically opted out by submitting Form 10-IEA before the due date.",
    "Section 80C deductions (up to 1.5 Lakhs), Section 80D (health insurance premium), and HRA exemptions are strictly NOT available in the New Regime.",
    "Under Section 87A, rebate is available up to taxable income of Rs. 5 Lakhs (Old Regime) or Rs. 7 Lakhs (New Regime), making tax virtually zero for net income within these limits."
  ]
};

export const RECENT_CIRCULARS = [
  {
    id: "circular_01",
    title: "Circular No. 04/2025",
    date: "May 20, 2025",
    subject: "Guidelines under Section 194R concerning TDS on benefits or perquisites in respect of business or profession.",
    summary: "Clarification on valuation of perquisites in case of complimentary travel bookings, incentive models for dealers, and treatment of free samples given to doctors."
  },
  {
    id: "circular_02",
    title: "Circular No. 12/2024",
    date: "Oct 15, 2024",
    subject: "Clarification on applicability of double rate rules (Section 206AB & 206CCA) on Non-Filers of Income Tax Returns (Specified Persons).",
    summary: "Sets out verification criteria via the 'Compliance Check for Section 206AB & 206CCA' utility on TRACES. Double rates are applicable if the deductee has not filed return for immediately preceding year with tax credit of >= Rs. 50,000."
  },
  {
    id: "circular_03",
    title: "Notification 45/2025",
    date: "Feb 10, 2025",
    subject: "Revision of Form 16 (Annexure B) guidelines to capture standard deduction increase to Rs. 75,000 for salaried employees in the New Regime.",
    summary: "Updated XML/FVU schema validation rules to incorporate the revised slabs starting April 1, 2025."
  }
];

export const RELEVANT_CASE_LAWS = [
  {
    id: "case_01",
    citation: "Supreme Court in CIT vs. Eli Lilly & Co. (India) P. Ltd.",
    subject: "Foreign payments & Salary TDS scope under 192",
    summary: "The apex court held that even if a part of salary is paid overseas by a foreign parent company to expats working in India, the Indian subsidiary is obligated to deduct tax under Section 192 on the home salary portion."
  },
  {
    id: "case_02",
    citation: "High Court of Bombay in CIT vs. Kotak Securities Ltd.",
    subject: "Transaction fees paid to stock exchange. Section 194J vs Section 194C",
    summary: "Transaction charges paid by an stockbroker do not fall under professional services or technical services. Consequently, Section 194J is not attracted; instead, standard business expenditure applies without TDS."
  }
];
