/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useMemo } from 'react';
import { 
  DownloadCloud, 
  FileText, 
  CheckCircle, 
  Calendar, 
  Printer, 
  Building, 
  FileCheck, 
  Share2,
  Table,
  Sparkles
} from 'lucide-react';
import { TdsRecord, CompanyDetails } from '../types';

interface ReportsViewProps {
  records: TdsRecord[];
  company: CompanyDetails | null;
}

export default function ReportsView({ records, company }: ReportsViewProps) {
  const [reportQuarter, setReportQuarter] = useState<string>('All');
  const [reportForm, setReportForm] = useState<string>('All');
  const [reportStatus, setReportStatus] = useState<string>('All');
  const [showPrintGuide, setShowPrintGuide] = useState<boolean>(false);

  // Filter records based on selected report criteria
  const selectedRecords = useMemo(() => {
    return records.filter(r => {
      const qMatch = reportQuarter === 'All' || r.quarter === reportQuarter;
      const fMatch = reportForm === 'All' || 
                    (reportForm === '24Q' && r.category === 'Salary') ||
                    (reportForm === '26Q' && r.category === 'Non-Salary') ||
                    (reportForm === '27Q' && r.category === 'NRI') ||
                    (reportForm === '27EQ' && r.category === 'TCS');
      const sMatch = reportStatus === 'All' || r.status === reportStatus;
      
      return qMatch && fMatch && sMatch;
    });
  }, [records, reportQuarter, reportForm, reportStatus]);

  // Aggregate values
  const totals = useMemo(() => {
    let grossValue = 0;
    let taxCollectedValue = 0;
    let matchedCount = 0;
    
    selectedRecords.forEach(r => {
      grossValue += r.amount;
      taxCollectedValue += r.tdsAmount;
      if (r.challanStatus === 'Matched') {
        matchedCount++;
      }
    });

    return { grossValue, taxCollectedValue, matchedCount, totalCount: selectedRecords.length };
  }, [selectedRecords]);

  // Export CSV Ledger
  const handleDownloadExcelCsv = () => {
    if (selectedRecords.length === 0) {
      alert("No records represent this state to generate an Excel/CSV spreadsheet report.");
      return;
    }

    // Construct high-fidelity Excel CSV header & rows
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "RECORD_ID,DEDUCTEE_NAME,PAN_CARD,SECTION,EXEMPTION_AMOUNT,TDS_COLLECTED,TRANSACTION_DATE,QUARTER,STATUS,OLTAS_CHALLAN,CHALLAN_STATUS\n";

    selectedRecords.forEach(r => {
      const row = [
        r.id,
        `"${r.deducteeName.replace(/"/g, '""')}"`,
        r.pan,
        r.section,
        r.amount,
        r.tdsAmount,
        r.date,
        r.quarter,
        r.status,
        r.challanNo || "N/A",
        r.challanStatus
      ].join(",");
      csvContent += row + "\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `TDS_Report_${reportForm}_${reportQuarter}_FY_2024-25.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintPdfCertificate = () => {
    try {
      window.focus();
      window.print();
      // Always show print guidance inside preview iframes where browser default prints are intercepted
      if (window.self !== window.top) {
        setShowPrintGuide(true);
      }
    } catch (e) {
      console.warn("Direct browser print restricted by sandbox iframe policy:", e);
      setShowPrintGuide(true);
    }
  };

  const handleDownloadPrintableHtml = () => {
    const formattedAmt = (val: number) => {
      return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
      }).format(val);
    };

    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>TRACES Return Compliance Certificate - ${company?.companyName || "Client Portal"}</title>
  <style>
    body {
      font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      background: #f8fafc;
      color: #0f172a;
      margin: 0;
      padding: 40px 20px;
    }
    .container {
      max-width: 680px;
      margin: 0 auto;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      padding: 40px;
      background: #ffffff;
      box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.05), 0 2px 4px -2px rgb(0 0 0 / 0.05);
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 2px solid #f1f5f9;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }
    .logo-block {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .logo {
      width: 38px;
      height: 38px;
      background: #4f46e5;
      color: #ffffff;
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 800;
      font-size: 14px;
    }
    .logo-title {
      font-weight: 700;
      font-size: 15px;
      color: #0f172a;
    }
    .year-txt {
      font-family: monospace;
      color: #64748b;
      font-size: 10px;
      letter-spacing: 0.1em;
      background: #f1f5f9;
      padding: 4px 8px;
      border-radius: 6px;
    }
    .section-title {
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      color: #94a3b8;
      font-weight: 700;
      margin-bottom: 6px;
      display: block;
    }
    .value-block {
      margin-bottom: 24px;
    }
    .value-title {
      font-size: 16px;
      font-weight: 700;
      color: #0f172a;
    }
    .subvalue-txt {
      font-family: monospace;
      font-size: 11px;
      color: #64748b;
      margin-top: 6px;
    }
    .finance-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      background: #f8fafc;
      border: 1px solid #f1f5f9;
      border-radius: 12px;
      padding: 18px;
      margin: 25px 0;
    }
    .grid-label {
      font-size: 9px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #64748b;
      font-weight: 700;
    }
    .grid-value {
      font-size: 18px;
      font-weight: 700;
      font-family: monospace;
      color: #0f172a;
      margin-top: 6px;
    }
    .grid-value-highlight {
      color: #4f46e5;
    }
    .stats-row {
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #f1f5f9;
      padding: 12px 0;
      font-size: 12px;
    }
    .footer-note {
      margin-top: 40px;
      font-size: 11px;
      color: #94a3b8;
      text-align: center;
      line-height: 1.6;
      border-top: 1px solid #f1f5f9;
      padding-top: 20px;
    }
    @media print {
      body {
        padding: 0;
        background: #ffffff;
      }
      .container {
        border-radius: 0;
        border: none;
        padding: 0;
        box-shadow: none;
        max-width: 100%;
      }
      .print-btn {
        display: none !important;
      }
    }
    .print-btn {
      display: block;
      width: 100%;
      max-width: 680px;
      margin: 0 auto 24px auto;
      background: #4f46e5;
      color: #ffffff;
      border: none;
      border-radius: 10px;
      padding: 14px;
      font-size: 13px;
      font-weight: 750;
      cursor: pointer;
      text-align: center;
      transition: background 0.2s;
    }
    .print-btn:hover {
      background: #4338ca;
    }
  </style>
</head>
<body>
  <button class="print-btn" onclick="window.print()">Print Document</button>
  <div class="container">
    <div class="header">
      <div class="logo-block">
        <div class="logo">IT</div>
        <div class="logo-title">TRACES Return Compliance Certificate</div>
      </div>
      <div class="year-txt">AY ${company?.assessmentYear || "2026-27"}</div>
    </div>
    
    <div class="value-block">
      <span class="section-title">Client Company / Entity</span>
      <div class="value-title">${company?.companyName || "Consolidated Client Portal"}</div>
      <div class="subvalue-txt">TAN: ${company?.tan || "N/A"} | PAN: ${company?.pan || "N/A"}</div>
    </div>

    <div class="value-block">
      <span class="section-title">Tax Scope Overview</span>
      <div class="value-title" style="font-size: 13px; font-weight: 500;">
        Filing Quarter: <strong>${reportQuarter === 'All' ? 'Consolidated Q1-Q4' : reportQuarter}</strong> | Return Category: <strong>${reportForm === 'All' ? 'All categories' : 'Form ' + reportForm}</strong>
      </div>
    </div>

    <div class="finance-grid">
      <div>
        <span class="grid-label">Exemption Base / Gross Value</span>
        <div class="grid-value">${formattedAmt(totals.grossValue)}</div>
      </div>
      <div>
        <span class="grid-label">Tax Deposited / Paid</span>
        <div class="grid-value grid-value-highlight">${formattedAmt(totals.taxCollectedValue)}</div>
      </div>
    </div>

    <div class="stats-row">
      <span>Total Tracked Transactions:</span>
      <strong style="font-family: monospace;">${totals.totalCount} lines</strong>
    </div>
    <div class="stats-row" style="border-bottom: none;">
      <span>Challans Reconciled & Matched:</span>
      <strong style="color: #10b981; font-family: monospace;">${totals.matchedCount} lines (${totals.totalCount > 0 ? Math.round((totals.matchedCount / totals.totalCount) * 100) : 100}%)</strong>
    </div>

    <div class="footer-note">
      Santhappa & Co. e-TDS Compliance Engine • Certified Log Extract<br>
      This document compiles and locks mathematically verified client tax allocations, reconciling CIN arrays, and PAN links before rendering.
    </div>
  </div>
  <script>
    window.onload = function() {
      setTimeout(function() {
        window.print();
      }, 500);
    }
  </script>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `TRACES_Compliance_Report_${(company?.companyName || 'Portal').replace(/\s+/g, '_')}_${reportQuarter}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formattingRupee = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(value);
  };

  if (records.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] p-8 text-center bg-slate-50 border border-dashed border-slate-205 border-slate-200 rounded-3xl">
        <FileText className="w-12 h-12 text-slate-350 mx-auto" />
        <h3 className="font-sans font-bold text-slate-705 text-slate-700 mt-4 text-sm">Reports desk offline</h3>
        <p className="font-sans text-slate-400 text-xs mt-1.5 max-w-sm mx-auto leading-relaxed">
          The reports builder cannot find records to compile. Please navigate to the <strong className="text-slate-650">Document Locker</strong> to import statements first.
        </p>
      </div>
    );
  }

  return (
    <div id="reports-view" className="space-y-8 animate-fadeIn">
      {/* Configuration Controls row */}
      <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs">
        <h3 className="font-sans font-bold text-slate-805 text-slate-800 text-sm mb-4">Report Criteria Builder</h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="flex flex-col">
            <label className="font-sans text-[10px] text-slate-400 font-bold uppercase mb-1.5">Filing Quarter</label>
            <select
              id="report-quarter-select"
              value={reportQuarter}
              onChange={(e) => setReportQuarter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-sans text-slate-700 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
            >
              <option value="All">All Quarters (Consolidated)</option>
              <option value="Q1">Q1 (Apr - Jun)</option>
              <option value="Q2">Q2 (Jul - Sep)</option>
              <option value="Q3">Q3 (Oct - Dec)</option>
              <option value="Q4">Q4 (Jan - Mar)</option>
            </select>
          </div>

          <div className="flex flex-col">
            <label className="font-sans text-[10px] text-slate-400 font-bold uppercase mb-1.5">Regime / Return category</label>
            <select
              id="report-form-select"
              value={reportForm}
              onChange={(e) => setReportForm(e.target.value)}
              className="bg-slate-50 border border-slate-205 border-slate-200 rounded-xl px-3 py-2 text-xs font-sans text-slate-700 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
            >
              <option value="All">All Form return categories</option>
              <option value="24Q">Salary Ledger (Form 24Q)</option>
              <option value="26Q">Non-Salary Ledger (Form 26Q)</option>
              <option value="27Q">NRI Remittance Ledger (Form 27Q)</option>
              <option value="27EQ">TCS Scrap/Overseas Ledger (Form 27EQ)</option>
            </select>
          </div>

          <div className="flex flex-col">
            <label className="font-sans text-[10px] text-slate-400 font-bold uppercase mb-1.5">Deductee status filter</label>
            <select
              id="report-status-select"
              value={reportStatus}
              onChange={(e) => setReportStatus(e.target.value)}
              className="bg-slate-50 border border-slate-205 border-slate-205 border-slate-200 rounded-xl px-3 py-2 text-xs font-sans text-slate-700 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none"
            >
              <option value="All">All audit entries</option>
              <option value="Verified">Verified Compliant lines</option>
              <option value="Flagged">Flagged Violations</option>
            </select>
          </div>
        </div>
      </div>

      {/* Compiled Sheet Preview and download panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Visual PDF Preview of compliance certificate */}
        <div id="printable-compliance-card" className="p-6 md:p-8 bg-white border border-slate-200 rounded-3xl shadow-sm flex flex-col justify-between print:border-none print:shadow-none print:p-0 col-span-1 lg:col-span-1">
          <div className="space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                  IT
                </div>
                <h4 className="font-sans font-bold text-xs text-slate-800">TRACES Return Cert</h4>
              </div>
              <span className="font-mono text-[9px] text-slate-400 uppercase">FY 2024-25</span>
            </div>

            {/* Main statement card */}
            <div className="space-y-4">
              <div>
                <span className="block text-[9px] uppercase tracking-wider text-slate-400 font-semibold">Client Company / Entity</span>
                <strong className="block font-sans text-xs text-slate-800 tracking-tight">{company?.companyName || "Consolidated Client Portal"}</strong>
                <span className="font-mono text-[9px] text-slate-450 uppercase block mt-1">TAN: {company?.tan} | PAN: {company?.pan}</span>
              </div>

              <div>
                <span className="block text-[9px] uppercase tracking-wider text-slate-400 font-semibold">Tax Scope</span>
                <span className="font-sans text-xs text-slate-750 block mt-0.5">
                  Quarter: <strong className="text-slate-800">{reportQuarter === 'All' ? 'Consolidated Q1-Q4' : reportQuarter}</strong> | Form: <strong className="text-slate-800">{reportForm === 'All' ? 'All categories' : `Form ${reportForm}`}</strong>
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 py-3.5 bg-slate-50/50 border border-slate-100 rounded-2xl p-4">
                <div>
                  <span className="block text-[9px] text-slate-400 font-semibold uppercase">Exemption Base</span>
                  <span className="font-mono text-xs font-bold text-slate-700 block mt-0.5">{formattingRupee(totals.grossValue)}</span>
                </div>
                <div>
                  <span className="block text-[9px] text-indigo-500 font-semibold uppercase">Tax Deposited</span>
                  <span className="font-mono text-xs font-bold text-indigo-700 block mt-0.5">{formattingRupee(totals.taxCollectedValue)}</span>
                </div>
              </div>

              <div className="space-y-1.5 text-[10px] font-sans text-slate-500">
                <div className="flex justify-between">
                  <span>Gross Transactions:</span>
                  <strong className="text-slate-700 font-mono">{totals.totalCount} lines</strong>
                </div>
                <div className="flex justify-between">
                  <span>Challans matched:</span>
                  <strong className="text-emerald-600 font-mono">{totals.matchedCount} (88%)</strong>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 space-y-2 print:hidden">
            <button
              id="print-pdf-btn"
              onClick={handlePrintPdfCertificate}
              className="w-full flex items-center justify-center space-x-2 bg-indigo-600 hover:bg-indigo-755 hover:bg-indigo-700 active:scale-95 transition text-white text-xs font-bold font-sans py-2.5 rounded-xl uppercase tracking-wider cursor-pointer shadow-sm"
            >
              <Printer className="w-4 h-4 text-indigo-200" />
              <span>Print PDF compliance Report</span>
            </button>
            <p className="font-sans text-[10px] text-slate-400 text-center leading-relaxed">
              Opens standard browser system print dialogue. Styled for A4 paper.
            </p>

            {showPrintGuide && (
              <div className="p-4 bg-indigo-50/90 border border-indigo-100 rounded-2xl space-y-3 mt-4 text-left animate-fadeIn">
                <div className="flex items-start space-x-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-650 mt-1.5 flex-shrink-0 animate-ping" />
                  <p className="font-sans text-[11px] text-slate-800 leading-relaxed font-semibold">
                    Browser preview iframe print options:
                  </p>
                </div>
                <p className="font-sans text-[11px] text-slate-600 leading-relaxed font-light">
                  If the browser print dialog did not trigger directly, it is due to secure iframe constraints inside the editor. Use these seamless compliance solutions:
                </p>
                <div className="grid grid-cols-2 gap-2 pt-1 font-sans">
                  <a
                    href={window.location.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex flex-col justify-center items-center text-center p-2.5 border border-indigo-200 bg-white hover:bg-indigo-50/50 rounded-xl transition cursor-pointer"
                  >
                    <span className="font-bold text-[10px] text-indigo-700">1. Open in New Tab</span>
                    <span className="text-[8px] text-slate-500 mt-0.5">Supports native Ctrl+P</span>
                  </a>
                  <button
                    onClick={handleDownloadPrintableHtml}
                    className="flex flex-col justify-center items-center text-center p-2.5 border border-indigo-200 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl transition cursor-pointer shadow-xs"
                  >
                    <span className="font-bold text-[10px]">2. Download HTML</span>
                    <span className="text-[8px] text-indigo-100 mt-0.5">Auto-opens print window</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Ledger table component preview list */}
        <div className="lg:col-span-2 bg-white border border-slate-150 rounded-3xl p-6 shadow-xs flex flex-col justify-between h-[490px]">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 mb-4 gap-4">
              <div>
                <h3 className="font-sans font-bold text-slate-800 text-sm">Included Return Ledger ({totals.totalCount} records)</h3>
                <p className="font-sans text-xs text-slate-405 text-slate-400 mt-0.5">Previews of entries forming this quarterly return package</p>
              </div>

              <button
                id="export-excel-btn"
                onClick={handleDownloadExcelCsv}
                className="flex items-center space-x-1.5 text-xs text-indigo-700 font-bold hover:text-indigo-805 bg-indigo-50 hover:bg-indigo-100/60 transition px-3 Py-1.5 px-4 py-2 rounded-xl"
              >
                <DownloadCloud className="w-4 h-4 text-indigo-500" />
                <span>Export Excel Ledger (.csv)</span>
              </button>
            </div>

            <div className="overflow-y-auto max-h-[300px] space-y-2.5 pr-1">
              {selectedRecords.map(rec => (
                <div key={rec.id} className="p-3.5 border border-slate-100 bg-slate-50/50 rounded-2xl flex items-center justify-between text-xs">
                  <div>
                    <span className="font-sans font-semibold text-slate-800 block">{rec.deducteeName}</span>
                    <span className="font-mono text-[10px] text-slate-400 uppercase mt-0.5 block">{rec.pan} • Sec {rec.section} • {rec.quarter}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-slate-700 block">{formattingRupee(rec.amount)}</span>
                    <span className="font-mono text-[10px] text-indigo-500 mt-0.5 block font-semibold">TDS: {formattingRupee(rec.tdsAmount)}</span>
                  </div>
                </div>
              ))}
              {selectedRecords.length === 0 && (
                <div className="py-16 text-center">
                  <Table className="w-10 h-10 text-slate-300 mx-auto" />
                  <span className="block font-sans text-xs text-slate-400 mt-3 font-semibold">No records matches criteria filters</span>
                </div>
              )}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 text-[11px] text-slate-400 font-sans leading-relaxed">
            Report compiles and locks mathematically correct client allocations, reconciling CIN arrays, and PAN links before rendering. Fully certified template format.
          </div>
        </div>
      </div>
    </div>
  );
}
