/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  ShieldAlert, 
  HelpCircle, 
  RefreshCw, 
  Sparkles, 
  ArrowRight,
  BookmarkCheck,
  CheckCircle,
  FileCheck2,
  Lock,
  Flame,
  Send,
  Fingerprint
} from 'lucide-react';
import { TdsRecord } from '../types';

interface ReconciliationProps {
  records: TdsRecord[];
}

export default function Reconciliation({ records }: ReconciliationProps) {
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiChat, setAiChat] = useState<Array<{ sender: 'user' | 'ai'; text: string }>>([
    {
      sender: 'ai',
      text: "Namaste! I am your AI Direct Tax Consultant. I have indexed your current active documents. Ask me anything about specific Indian TDS/TCS penalty structures, circulars, or how to resolve the identified compliance flags."
    }
  ]);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Auto-calculated audits based on records
  const complianceAudits = React.useMemo(() => {
    const totalCount = records.length;
    if (totalCount === 0) return null;

    const unmatchedChallans = records.filter(r => r.challanStatus === 'Unmatched');
    const unpaidChallans = records.filter(r => r.challanStatus === 'Unpaid');
    const inactiveOrNotFoundPan = records.filter(r => r.panStatus === 'Inactive' || r.panStatus === 'NotFound');
    const unlinkedAadhaar = records.filter(r => !r.aadhaarLinked && r.panStatus === 'Active');

    // Threshold check (e.g. 194C over 30000 single or 100000 aggregate, 194J over 30000)
    // we search for those records where individual record amount exceeds standard single threshold, just as a rule of thumb
    const thresholdWarnings = records.filter(r => {
      if (r.section === '194C' && r.amount > 30000 && r.rate < 1) return true;
      if (r.section === '194J' && r.amount > 30000 && r.rate < 2) return true;
      return false;
    });

    const overallScore = Math.max(
      30,
      100 - (unmatchedChallans.length * 10) - (unpaidChallans.length * 15) - (inactiveOrNotFoundPan.length * 15) - (unlinkedAadhaar.length * 5)
    );

    return {
      unmatchedChallans,
      unpaidChallans,
      inactiveOrNotFoundPan,
      unlinkedAadhaar,
      thresholdWarnings,
      overallScore
    };
  }, [records]);

  // Handle Ask tax AI
  const handleAskAi = async (text: string) => {
    if (!text.trim()) return;
    const userMsg = text;
    setAiChat(prev => [...prev, { sender: 'user', text: userMsg }]);
    setAiPrompt('');
    setIsAiLoading(true);

    try {
      // Prompt the Express API for Gemini insights
      const response = await fetch('/api/gemini/insights', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          prompt: userMsg,
          context: {
            recordsCount: records.length,
            flaggedCount: records.filter(r => r.status === 'Flagged').length,
            mismatchedChallans: records.filter(r => r.challanStatus === 'Unmatched').length,
            unlinkedAadhaar: records.filter(r => !r.aadhaarLinked).length,
            sectionsInvolved: Array.from(new Set(records.map(r => r.section)))
          }
        })
      });

      if (!response.ok) {
        throw new Error("Failed to consult API");
      }

      const data = await response.json();
      setAiChat(prev => [...prev, { sender: 'ai', text: data.result || "I apologize, but I struggled to analyze that query. Please try again with details on standard sections (e.g. 194C or 194J)." }]);
    } catch (err) {
      console.error(err);
      // Fallback answers in case of server offline / key failures
      let reply = "The system is running on local fallback compliance guidelines. ";
      if (userMsg.toLowerCase().includes("194c")) {
        reply += "Section 194C applies to Payments to Contractors. The rate of tax is 1% for individual/HUFs and 2% for companies. Standard thresholds are Rs. 30,000 for a single transaction or Rs. 1,00,000 aggregate per annum.";
      } else if (userMsg.toLowerCase().includes("aadhaar") || userMsg.toLowerCase().includes("link")) {
        reply += "Under Section 206AA, if the deductee has not provided their PAN, tax is deducted at a minimum of 20%. As per Section 139AA, if a PAN is not linked metadata with Aadhaar, it becomes inoperative. TRACES validates this on file upload, and standard higher-rate deductions become retrospectively applicable.";
      } else if (userMsg.toLowerCase().includes("late") || userMsg.toLowerCase().includes("delay") || userMsg.toLowerCase().includes("interest")) {
        reply += "Late deduction of TDS incurs interest of 1% per month. Late payment of TDS to the government account (OLTAS) attracts interest of 1.5% per month. Delay in submitting the quarterly statement on TRACES results in standard late fees of Rs. 200 per day under Section 234E.";
      } else {
        reply += "Based on Indian Income Tax laws (Budget 2024 & FY 2025-26 rules), ensuring deductee PAN is active on the TRACES portal is mandatory. Let me know if you would like me to detail specific slab rates or form validation issues.";
      }
      setAiChat(prev => [...prev, { sender: 'ai', text: reply }]);
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleQuickQuestion = (qn: string) => {
    handleAskAi(qn);
  };

  const formattingRupee = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(value);
  };

  if (records.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] p-8 text-center bg-slate-50 border border-dashed border-slate-200 rounded-3xl">
        <ShieldAlert className="w-12 h-12 text-slate-350 mx-auto" />
        <h3 className="font-sans font-bold text-slate-700 mt-4 text-base">Reconciliation Desk Offline</h3>
        <p className="font-sans text-slate-400 text-xs mt-1.5 max-w-sm mx-auto">
          Please upload relevant FVU files or transaction sheets in the <strong className="text-slate-650">Document Locker</strong> to run the automated tax audit engine.
        </p>
      </div>
    );
  }

  const aud = complianceAudits!;

  return (
    <div id="reconciliation-view" className="space-y-8 animate-fadeIn">
      {/* Visual Health Score Indicator */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 md:p-8 shadow-md border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 max-w-md">
          <span className="font-mono text-[10px] text-indigo-400 font-bold uppercase tracking-widest bg-indigo-950 px-2 py-0.5 rounded">TDS Portal Score</span>
          <h2 className="font-sans font-extrabold text-2xl tracking-tight text-white mt-1">Audit Compliance Index</h2>
          <p className="font-sans text-slate-400 text-xs leading-relaxed">
            This health index updates as you reconcile unmatched challans or rectify invalid PAN records on the system. Keep this above 90% before filing.
          </p>
        </div>

        {/* Circular Percentage Dial */}
        <div className="flex items-center space-x-6">
          <div className="relative w-28 h-28 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="56"
                cy="56"
                r="45"
                className="stroke-slate-800 fill-none"
                strokeWidth="8"
              />
              <circle
                cx="56"
                cy="56"
                r="45"
                className={`fill-none transition-all duration-1000 ${
                  aud.overallScore > 80 ? 'stroke-indigo-500' : 'stroke-amber-500'
                }`}
                strokeWidth="8"
                strokeDasharray={`${2 * Math.PI * 45}`}
                strokeDashoffset={`${2 * Math.PI * 45 * (1 - aud.overallScore / 100)}`}
                strokeLinecap="round"
              />
            </svg>
            <span className="absolute font-mono font-extrabold text-white text-2xl">{aud.overallScore}%</span>
          </div>
          <div>
            <span className="block font-sans text-xs text-slate-400">Workspace Status</span>
            <span className={`block font-sans text-sm font-bold mt-1 ${aud.overallScore >= 90 ? 'text-emerald-400' : 'text-amber-400'}`}>
              {aud.overallScore >= 90 ? 'Fully File-Ready' : 'Urgent Audits Needed'}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Compliance Audits checklist */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs">
            <h3 className="font-sans font-bold text-slate-800 text-sm mb-1">TRACES Auto-Compliance Check</h3>
            <p className="font-sans text-xs text-slate-400 mb-6">Automated audit of imported entries against IT regulations</p>

            <div className="space-y-4">
              {/* Check 1: Aadhaar Linkage */}
              <div className="p-4 rounded-xl border flex items-start space-x-4 transition hover:bg-slate-50/40 bg-white border-slate-200/80">
                <div className={`p-2 rounded-lg ${aud.unlinkedAadhaar.length > 0 ? 'bg-amber-50 text-amber-500' : 'bg-emerald-50/60 text-emerald-500'}`}>
                  <Fingerprint className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="font-sans font-semibold text-xs text-slate-800">Aadhaar-PAN Linkage Compliance</h4>
                    <span className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded ${aud.unlinkedAadhaar.length > 0 ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'}`}>
                      {aud.unlinkedAadhaar.length > 0 ? `${aud.unlinkedAadhaar.length} Alert` : 'Compliant'}
                    </span>
                  </div>
                  <p className="font-sans text-[11px] text-slate-500 mt-1 lines-clamp-2">
                    {aud.unlinkedAadhaar.length > 0 
                      ? `Detected active employee or vendor PANs with unlinked or pending Aadhaar status. These individuals are liable for double rate tax (e.g. 20% under section 206AA).`
                      : `Excellent. All active deductors and employees in this folder possess valid Aadhaar linkage verified via NSDL database checkpoints.`
                    }
                  </p>
                </div>
              </div>

              {/* Check 2: Challan Balance */}
              <div className="p-4 rounded-xl border flex items-start space-x-4 transition hover:bg-slate-50/40 bg-white border-slate-200/80">
                <div className={`p-2 rounded-lg ${aud.unmatchedChallans.length + aud.unpaidChallans.length > 0 ? 'bg-rose-50 text-rose-500' : 'bg-emerald-50/60 text-emerald-500'}`}>
                  <FileCheck2 className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="font-sans font-semibold text-xs text-slate-800">OLTAS Challan Matching & Mismatch Checks</h4>
                    <span className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded ${aud.unmatchedChallans.length + aud.unpaidChallans.length > 0 ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'}`}>
                      {aud.unmatchedChallans.length + aud.unpaidChallans.length > 0 ? `${aud.unmatchedChallans.length + aud.unpaidChallans.length} Action` : 'Compliant'}
                    </span>
                  </div>
                  <p className="font-sans text-[11px] text-slate-500 mt-1">
                    {aud.unmatchedChallans.length + aud.unpaidChallans.length > 0
                      ? `Mismatch or Unpaid entries detected. Unreconciled challans will lead to TRACES defaults with statutory demands.`
                      : `Verified! All paid TDS lines are successfully matched against the OLTAS database with compliant Challan Identification Numbers (CINs) and BSR branches.`
                    }
                  </p>
                </div>
              </div>

              {/* Check 3: PAN Legitimacy */}
              <div className="p-4 rounded-xl border flex items-start space-x-4 transition hover:bg-slate-50/40 bg-white border-slate-200/80">
                <div className={`p-2 rounded-lg ${aud.inactiveOrNotFoundPan.length > 0 ? 'bg-amber-50 text-amber-500' : 'bg-emerald-50/60 text-emerald-500'}`}>
                  <CheckCircle className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="font-sans font-semibold text-xs text-slate-800">Income Tax PAN Registry Integrity Check</h4>
                    <span className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded ${aud.inactiveOrNotFoundPan.length > 0 ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'}`}>
                      {aud.inactiveOrNotFoundPan.length > 0 ? `${aud.inactiveOrNotFoundPan.length} Violations` : 'Compliant'}
                    </span>
                  </div>
                  <p className="font-sans text-[11px] text-slate-500 mt-1">
                    {aud.inactiveOrNotFoundPan.length > 0 
                      ? `Detected ${aud.inactiveOrNotFoundPan.length} records where PAN is invalid, inactive, or not present on standard databases.`
                      : `All deductor PAN structures mapped perfectly against official registries of the Income Tax Department.`
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Compliance Error Log List */}
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs">
            <h3 className="font-sans font-bold text-slate-800 text-sm">Review Compliance Log ({records.filter(r => r.status === 'Flagged').length} flags)</h3>
            <p className="font-sans text-xs text-slate-400 mt-0.5 mb-5">Click on any warning to read resolutions details</p>

            <div className="space-y-3">
              {records.filter(r => r.status === 'Flagged').map(rec => (
                <div key={rec.id} className="p-4 border border-slate-100 rounded-xl bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-xs font-bold text-slate-700 bg-white px-2 py-0.5 border border-slate-100 rounded shadow-xs">{rec.id.toUpperCase()}</span>
                      <span className="font-sans font-bold text-xs text-slate-805 text-slate-800 truncate">{rec.deducteeName}</span>
                    </div>
                    <p className="font-sans text-[11px] text-amber-600 font-medium">
                      {rec.remarks || `Compliance warning under section ${rec.section}`}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2.5">
                    <span className="font-mono text-[10px] text-slate-400">{rec.pan} ({rec.quarter})</span>
                    <button 
                      id={`how-to-fix-btn-${rec.id}`}
                      onClick={() => handleQuickQuestion(`How do I resolve the flagged TDS issue for ${rec.deducteeName} (${rec.pan}) under section ${rec.section}?`)}
                      className="px-3 py-1 font-sans text-[10px] bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-lg border border-indigo-100/60 flex items-center space-x-1"
                    >
                      <span>How to fix</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Dynamic Gemini Chat/Expert Adviser Widget */}
        <div className="bg-white border border-slate-100 rounded-3xl overflow-hidden flex flex-col h-[580px] shadow-sm">
          {/* Header */}
          <div className="p-5 border-b border-slate-100 bg-gradient-to-r from-slate-900 to-slate-850 text-white flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
              </div>
              <div>
                <h4 className="font-sans font-bold text-xs text-white">AI Compliance Advisor</h4>
                <p className="text-[10px] text-slate-400 flex items-center">
                  <Lock className="w-2.5 h-2.5 mr-1 text-emerald-400" /> Powered by Gemini
                </p>
              </div>
            </div>
            <button 
              id="clear-adv-chat"
              onClick={() => {
                setAiChat([
                  {
                    sender: 'ai',
                    text: "Workspace chat logs cleared. How can I assist you with TDS/TCS regulations today?"
                  }
                ]);
              }}
              className="text-[10px] font-mono text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800 transition"
            >
              Clear
            </button>
          </div>

          {/* Chat Bubble Thread */}
          <div className="flex-1 p-5 overflow-y-auto space-y-4 bg-slate-50/50">
            {aiChat.map((msg, idx) => (
              <div 
                key={idx} 
                className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed font-sans ${
                  msg.sender === 'user' 
                    ? 'ml-auto bg-indigo-600 text-white rounded-br-none' 
                    : 'bg-white border border-slate-100 shadow-2xs text-slate-700 rounded-bl-none'
                }`}
              >
                {msg.text}
              </div>
            ))}
            {isAiLoading && (
              <div className="bg-white border border-slate-100 rounded-2xl p-4 text-xs font-sans text-slate-400 w-24 text-center shadow-xs">
                Analyzing...
              </div>
            )}
          </div>

          {/* Preset trigger block */}
          <div className="px-5 py-3 border-t border-slate-100 bg-slate-50 flex flex-wrap gap-2">
            {[
              "Section 234E Penalty rules",
              "How to edit unlinked Aadhaar",
              "Verify mismatched challans"
            ].map(qn => (
              <button
                id={`preset-qn-${qn.replace(/\s+/g, '-').toLowerCase()}`}
                key={qn}
                onClick={() => handleQuickQuestion(qn)}
                className="text-[10px] font-sans font-medium text-slate-600 hover:text-indigo-700 bg-white hover:bg-indigo-50/40 border border-slate-205 border-slate-200 px-3 py-1 rounded-lg transition"
              >
                {qn}
              </button>
            ))}
          </div>

          {/* Input field Form */}
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              handleAskAi(aiPrompt);
            }} 
            className="p-4 border-t border-slate-100 bg-white flex items-center space-x-2"
          >
            <input
              id="ai-advisor-input"
              type="text"
              placeholder="Ask about late interest, Section 195 rates..."
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              className="flex-1 bg-slate-50 border border-slate-200/80 rounded-xl px-4 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
            <button 
              id="send-ai-btn"
              type="submit"
              disabled={isAiLoading || !aiPrompt.trim()}
              className="p-2 bg-indigo-600 rounded-xl text-white active:scale-95 disabled:opacity-40 disabled:scale-100 transition shadow-md shadow-indigo-500/25 flex-shrink-0"
            >
              <Send className="w-4 h-4 text-white" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
