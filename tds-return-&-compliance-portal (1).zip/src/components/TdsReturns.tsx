/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  FileText, 
  Search, 
  Calendar, 
  ShieldCheck, 
  AlertCircle,
  Download,
  AlertTriangle,
  Building,
  CheckCircle,
  ChevronRight,
  ChevronDown,
  Layers,
  User,
  Tag,
  TrendingUp,
  X,
  CreditCard
} from 'lucide-react';
import { TdsRecord } from '../types';

interface TdsReturnsProps {
  records: TdsRecord[];
  initialFormCategory?: 'TDS_24Q' | 'TDS_26Q' | 'NRI' | 'TCS';
}

const MONTH_MAP: Record<number, { name: string; q: 'Q1' | 'Q2' | 'Q3' | 'Q4' }> = {
  1: { name: 'January', q: 'Q4' },
  2: { name: 'February', q: 'Q4' },
  3: { name: 'March', q: 'Q4' },
  4: { name: 'April', q: 'Q1' },
  5: { name: 'May', q: 'Q1' },
  6: { name: 'June', q: 'Q1' },
  7: { name: 'July', q: 'Q2' },
  8: { name: 'August', q: 'Q2' },
  9: { name: 'September', q: 'Q2' },
  10: { name: 'October', q: 'Q3' },
  11: { name: 'November', q: 'Q3' },
  12: { name: 'December', q: 'Q3' }
};

const QUARTER_MONTHS: Record<'Q1' | 'Q2' | 'Q3' | 'Q4', number[]> = {
  Q1: [4, 5, 6],
  Q2: [7, 8, 9],
  Q3: [10, 11, 12],
  Q4: [1, 2, 3]
};

export default function TdsReturns({ records, initialFormCategory = 'TDS_26Q' }: TdsReturnsProps) {
  const [activeSubTab, setActiveSubTab] = useState<'ledger' | 'quarter' | 'section' | 'pan'>('ledger');
  
  // For TDS (Form 24Q or 26Q), we let them toggle between Salary and Non-Salary
  const [tdsSubForm, setTdsSubForm] = useState<'24Q' | '26Q'>('26Q');
  
  // Deduce Form Type
  const activeFormTab = useMemo(() => {
    if (initialFormCategory === 'NRI') return '27Q';
    if (initialFormCategory === 'TCS') return '27EQ';
    if (initialFormCategory === 'TDS_24Q') return '24Q';
    if (initialFormCategory === 'TDS_26Q') return '26Q';
    return tdsSubForm;
  }, [initialFormCategory, tdsSubForm]);

  const [returnQuarter, setReturnQuarter] = useState<'Q1' | 'Q2' | 'Q3' | 'Q4'>('Q1');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Popup details states for Month, Section-Month, and PAN-Month drilling
  const [drawerTitle, setDrawerTitle] = useState<string>('');
  const [drawerRecords, setDrawerRecords] = useState<TdsRecord[]>([]);
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);

  // Filter records based on Category (TDS form 24Q/26Q, NRI form 27Q, TCS form 27EQ)
  const categoryRecords = useMemo(() => {
    return records.filter(r => {
      if (initialFormCategory === 'TDS_24Q') {
        return r.category === 'Salary';
      } else if (initialFormCategory === 'TDS_26Q') {
        return r.category === 'Non-Salary';
      } else if (initialFormCategory === 'NRI') {
        return r.category === 'NRI';
      } else if (initialFormCategory === 'TCS') {
        return r.category === 'TCS';
      }
      return true;
    });
  }, [records, initialFormCategory]);

  // Main filtered ledger records matches
  const filteredRecords = useMemo(() => {
    return categoryRecords.filter(r => {
      const isCorrectQuarter = r.quarter === returnQuarter;
      const matchesSearch = 
        r.deducteeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.pan.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.section.toLowerCase().includes(searchQuery.toLowerCase());
      return isCorrectQuarter && matchesSearch;
    });
  }, [categoryRecords, returnQuarter, searchQuery]);

  // General Category totals (Q-independent for analytics overview)
  const categoryStats = useMemo(() => {
    let totalTaxable = 0;
    let totalTds = 0;
    let verifiedCount = 0;
    let flaggedCount = 0;

    categoryRecords.forEach(r => {
      totalTaxable += r.amount;
      totalTds += r.tdsAmount;
      if (r.status === 'Flagged') flaggedCount++;
      else verifiedCount++;
    });

    return { totalTaxable, totalTds, verifiedCount, flaggedCount, count: categoryRecords.length };
  }, [categoryRecords]);

  // Current selected quarter stats
  const returnStats = useMemo(() => {
    let totalExemptionValue = 0;
    let totalTaxDeducted = 0;
    let flagCount = 0;

    filteredRecords.forEach(r => {
      totalExemptionValue += r.amount;
      totalTaxDeducted += r.tdsAmount;
      if (r.status === 'Flagged') flagCount++;
    });

    return { totalExemptionValue, totalTaxDeducted, flagCount, recordLength: filteredRecords.length };
  }, [filteredRecords]);

  // Quarter-wise / Month-wise breakdown aggregator
  const quarterMonthBreakdown = useMemo(() => {
    const data: Record<'Q1' | 'Q2' | 'Q3' | 'Q4', {
      totalAmount: number;
      totalTds: number;
      count: number;
      months: { monthNum: number; name: string; totalAmount: number; totalTds: number; count: number; items: TdsRecord[] }[];
    }> = {
      Q1: { totalAmount: 0, totalTds: 0, count: 0, months: [] },
      Q2: { totalAmount: 0, totalTds: 0, count: 0, months: [] },
      Q3: { totalAmount: 0, totalTds: 0, count: 0, months: [] },
      Q4: { totalAmount: 0, totalTds: 0, count: 0, months: [] }
    };

    // Initialize months for each quarter
    (Object.keys(QUARTER_MONTHS) as ('Q1'|'Q2'|'Q3'|'Q4')[]).forEach(qKey => {
      data[qKey].months = QUARTER_MONTHS[qKey].map(mNum => ({
        monthNum: mNum,
        name: MONTH_MAP[mNum].name,
        totalAmount: 0,
        totalTds: 0,
        count: 0,
        items: []
      }));
    });

    categoryRecords.forEach(r => {
      const monthNum = parseInt(r.date.split('-')[1], 10) || 4;
      const monthInfo = MONTH_MAP[monthNum];
      if (monthInfo) {
        const qKey = r.quarter || monthInfo.q;
        data[qKey].totalAmount += r.amount;
        data[qKey].totalTds += r.tdsAmount;
        data[qKey].count += 1;

        const mObj = data[qKey].months.find(m => m.monthNum === monthNum);
        if (mObj) {
          mObj.totalAmount += r.amount;
          mObj.totalTds += r.tdsAmount;
          mObj.count += 1;
          mObj.items.push(r);
        }
      }
    });

    return data;
  }, [categoryRecords]);

  // Section-wise / Month-wise breakdown aggregator
  const sectionBreakdown = useMemo(() => {
    const data: Record<string, {
      section: string;
      totalAmount: number;
      totalTds: number;
      count: number;
      months: Record<number, { name: string; totalAmount: number; totalTds: number; count: number; items: TdsRecord[] }>;
    }> = {};

    categoryRecords.forEach(r => {
      const sec = r.section.toUpperCase() || 'UNKNOWN';
      if (!data[sec]) {
        data[sec] = {
          section: sec,
          totalAmount: 0,
          totalTds: 0,
          count: 0,
          months: {}
        };
        // Init 12 months
        for (let m = 1; m <= 12; m++) {
          data[sec].months[m] = {
            name: MONTH_MAP[m].name,
            totalAmount: 0,
            totalTds: 0,
            count: 0,
            items: []
          };
        }
      }

      data[sec].totalAmount += r.amount;
      data[sec].totalTds += r.tdsAmount;
      data[sec].count += 1;

      const monthNum = parseInt(r.date.split('-')[1], 10) || 4;
      if (data[sec].months[monthNum]) {
        data[sec].months[monthNum].totalAmount += r.amount;
        data[sec].months[monthNum].totalTds += r.tdsAmount;
        data[sec].months[monthNum].count += 1;
        data[sec].months[monthNum].items.push(r);
      }
    });

    return Object.values(data).sort((a,b) => b.totalAmount - a.totalAmount);
  }, [categoryRecords]);

  // PAN-wise (Individual Deductees) / Month-wise breakdown aggregator
  const panBreakdown = useMemo(() => {
    const data: Record<string, {
      pan: string;
      deducteeName: string;
      totalAmount: number;
      totalTds: number;
      count: number;
      status: string;
      aadhaarLinked: boolean;
      months: Record<number, { name: string; totalAmount: number; totalTds: number; count: number; items: TdsRecord[] }>;
    }> = {};

    categoryRecords.forEach(r => {
      const key = `${r.pan.toUpperCase()}_${r.deducteeName.toUpperCase()}`;
      if (!data[key]) {
        data[key] = {
          pan: r.pan.toUpperCase(),
          deducteeName: r.deducteeName,
          totalAmount: 0,
          totalTds: 0,
          count: 0,
          status: r.status,
          aadhaarLinked: r.aadhaarLinked,
          months: {}
        };
        // Init 12 months
        for (let m = 1; m <= 12; m++) {
          data[key].months[m] = {
            name: MONTH_MAP[m].name,
            totalAmount: 0,
            totalTds: 0,
            count: 0,
            items: []
          };
        }
      }

      data[key].totalAmount += r.amount;
      data[key].totalTds += r.tdsAmount;
      data[key].count += 1;

      const monthNum = parseInt(r.date.split('-')[1], 10) || 4;
      if (data[key].months[monthNum]) {
        data[key].months[monthNum].totalAmount += r.amount;
        data[key].months[monthNum].totalTds += r.tdsAmount;
        data[key].months[monthNum].count += 1;
        data[key].months[monthNum].items.push(r);
      }
    });

    return Object.values(data).sort((a, b) => b.totalAmount - a.totalAmount);
  }, [categoryRecords]);

  // Helper trigger to open month drill-down drawer
  const openDrillDownDrawer = (title: string, records: TdsRecord[]) => {
    setDrawerTitle(title);
    setDrawerRecords(records);
    setIsDrawerOpen(true);
  };

  // Generate simulated FVU text structure
  const handleDownloadFvu = () => {
    if (filteredRecords.length === 0) {
      alert("No records present to generate the FVU file structure for this quarter.");
      return;
    }

    const companyTAN = "MUMZ01243A";
    const companyPAN = "AAACZ1290K";
    
    let fvuText = `SAM_FVU_FILE_VERSION 4.2\n`;
    fvuText += `FILE_EST_DATE: 2026-06-13\n`;
    fvuText += `FORM_TYPE: ${activeFormTab}\n`;
    fvuText += `QUARTER: ${returnQuarter}\n`;
    fvuText += `DEDUCTOR_TAN: ${companyTAN}\n`;
    fvuText += `DEDUCTOR_PAN: ${companyPAN}\n`;
    fvuText += `RECORD_COUNT: ${filteredRecords.length}\n`;
    fvuText += `TOTAL_TDS_AMOUNT: ${returnStats.totalTaxDeducted}\n`;
    fvuText += `===========================================================\n`;
    fvuText += `LINE_NO | DEDUCTEE_PAN | DEDUCTEE_NAME | SECTION | TRANSACTION_AMOUNT | REF_TDS | CHALLAN_NO\n`;
    
    filteredRecords.forEach((r, idx) => {
      fvuText += `${(idx + 1).toString().padStart(4, '0')} | ${r.pan.padEnd(10, ' ')} | ${r.deducteeName.padEnd(30, ' ')} | Sec ${r.section.padEnd(4, ' ')} | ${r.amount.toFixed(2).padStart(12, ' ')} | ${r.tdsAmount.toFixed(2).padStart(10, ' ')} | ${r.challanNo.padEnd(8, ' ')}\n`;
    });
    
    fvuText += `===========================================================\n`;
    fvuText += `COMPLIANCE_SIGNATURE: MD5_SUM_7587FF8B2DCD09E8\n`;
    fvuText += `NSDL_VALIDATION: COMPLIANT`;

    const blob = new Blob([fvuText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `FVU_${activeFormTab}_${returnQuarter}_2024-25.fvu`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formattingRupee = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(value);
  };

  // Human Label Form Names
  const getCategoryTitle = () => {
    if (initialFormCategory === 'TDS_24Q') return 'Form 24Q Salary TDS Returns';
    if (initialFormCategory === 'TDS_26Q') return 'Form 26Q Non-Salary TDS Returns';
    if (initialFormCategory === 'NRI') return 'Form 27Q Foreign Remittances & NRI Returns';
    if (initialFormCategory === 'TCS') return 'Form 27EQ Tax Collected at Source (TCS) Returns';
    return 'Form 24Q & 26Q Resident TDS Returns';
  };

  return (
    <div id="returns-view" className="space-y-8 animate-fadeIn">
      {/* Return Head Banner */}
      <div className="bg-white border border-slate-100 p-6 rounded-3xl shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <span className="font-mono text-xs uppercase tracking-wider text-indigo-600 font-semibold">Active Filing Register</span>
          <h2 className="font-sans font-bold text-xl text-slate-800 tracking-tight flex items-center mt-0.5">
            <FileText className="w-6 h-6 text-indigo-500 mr-2.5" />
            {getCategoryTitle()}
          </h2>
          <p className="font-sans text-xs text-slate-400 mt-0.5 max-w-2xl">
            Calculated in real-time from your uploaded registers and official NSDL caret-delimited returns packages.
          </p>
        </div>
      </div>

      {/* Overview Analytics Banner cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider">Scanned Transactions</span>
            <span className="font-mono text-lg font-bold text-slate-800">{categoryStats.count}</span>
          </div>
        </div>

        <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-dashed border border-indigo-100 bg-indigo-50/10 text-indigo-600 rounded-xl">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider">Total Value Paid</span>
            <span className="font-mono text-lg font-bold text-slate-800">{formattingRupee(categoryStats.totalTaxable)}</span>
          </div>
        </div>

        <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider">Total TDS Deducted</span>
            <span className="font-mono text-lg font-bold text-emerald-600">{formattingRupee(categoryStats.totalTds)}</span>
          </div>
        </div>

        <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-xs flex items-center space-x-4">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
            <AlertTriangle className="w-2.5 h-2.5 sm:w-5 sm:h-5" />
          </div>
          <div>
            <span className="block text-[10px] uppercase font-bold text-slate-400 tracking-wider">Flagged/High Risk</span>
            <span className="font-mono text-lg font-bold text-amber-600">{categoryStats.flaggedCount}</span>
          </div>
        </div>
      </div>

      {/* Sub-view Nav tabs requested: Quarter, Sections, PAN, Ledger */}
      <div className="bg-slate-100/60 p-1 rounded-2xl border border-slate-200/50 flex flex-wrap gap-1">
        {[
          { id: 'ledger', label: 'General Returns Ledger', icon: FileText },
          { id: 'quarter', label: 'Quarter Wise (Month Wise)', icon: Calendar },
          { id: 'section', label: 'Sections Wise (Month Wise)', icon: Tag },
          { id: 'pan', label: 'PAN Wise (Deductee Month Wise)', icon: User }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              id={`subtab-btn-${tab.id}`}
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2.5 font-sans font-semibold text-xs rounded-xl transition ${
                isActive
                  ? 'bg-gradient-to-r from-indigo-500 to-indigo-600 text-white shadow-md shadow-indigo-500/15'
                  : 'text-slate-600 hover:bg-slate-100/50 hover:text-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Render Sub Tab view body */}
      {activeSubTab === 'ledger' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Left Control Sidebar */}
          <div className="space-y-6">
            {/* Quarter Panel Selector */}
            <div className="bg-white border border-slate-100 p-5 rounded-3xl shadow-xs">
              <h4 className="font-sans font-bold text-slate-800 text-xs uppercase tracking-wider mb-4">Filing Quarter</h4>
              <div className="space-y-2">
                {[
                  { id: 'Q1', label: 'Quarter 1', dates: 'April 1 - June 30' },
                  { id: 'Q2', label: 'Quarter 2', dates: 'July 1 - Sept 30' },
                  { id: 'Q3', label: 'Quarter 3', dates: 'Oct 1 - Dec 31' },
                  { id: 'Q4', label: 'Quarter 4', dates: 'Jan 1 - March 31' },
                ].map(q => (
                  <button
                    id={`quarter-btn-${q.id}`}
                    key={q.id}
                    onClick={() => setReturnQuarter(q.id as any)}
                    className={`w-full flex items-center justify-between p-3.5 rounded-xl text-left border transition ${
                      returnQuarter === q.id
                        ? 'bg-indigo-50/50 border-indigo-200 text-indigo-700 font-semibold'
                        : 'bg-slate-50 border-transparent text-slate-600 hover:bg-slate-100/60'
                    }`}
                  >
                    <div>
                      <span className="block font-sans text-xs">{q.label}</span>
                      <span className="block font-sans text-[10px] text-slate-400 font-light mt-0.5">{q.dates}</span>
                    </div>
                    {returnQuarter === q.id && <div className="w-1.5 h-1.5 rounded-full bg-indigo-600" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Form Quick Details Info panel */}
            <div className="bg-indigo-950 text-indigo-100 p-6 rounded-3xl shadow-xs space-y-4">
              <h4 className="font-sans font-bold text-xs uppercase tracking-wider text-indigo-300">File Validation Stats</h4>
              
              <div className="space-y-3.5">
                <div>
                  <span className="block text-[10px] text-indigo-300">Form Scheme</span>
                  <span className="font-sans font-semibold text-sm">FVU / NSDL format {activeFormTab}</span>
                </div>
                <div>
                  <span className="block text-[10px] text-indigo-300">Selected Segment</span>
                  <span className="font-sans font-semibold text-sm">{returnQuarter} of Fiscal Year 2025-26</span>
                </div>
                <div className="border-t border-indigo-900 pt-3.5">
                  <span className="block text-[10px] text-indigo-300">Consolidated Tax base</span>
                  <span className="font-mono text-base font-bold">{formattingRupee(returnStats.totalExemptionValue)}</span>
                </div>
                <div>
                  <span className="block text-[10px] text-indigo-300">Estimated Returns Deducted</span>
                  <span className="font-mono text-base font-bold text-cyan-300">{formattingRupee(returnStats.totalTaxDeducted)}</span>
                </div>
              </div>

              {filteredRecords.length > 0 && (
                <button
                  id="generate-fvu-btn"
                  onClick={handleDownloadFvu}
                  className="w-full mt-4 flex items-center justify-center space-x-2 bg-gradient-to-r from-cyan-400 to-indigo-500 hover:scale-95 transition text-white text-xs font-bold font-sans py-2.5 rounded-xl uppercase tracking-wider shadow-md cursor-pointer"
                >
                  <Download className="w-4 h-4 text-cyan-100" />
                  <span>Download .FVU Statement</span>
                </button>
              )}
            </div>
          </div>

          {/* Right Data Grid Panel */}
          <div className="lg:col-span-3 bg-white border border-slate-100 rounded-3xl shadow-xs overflow-hidden flex flex-col justify-between">
            <div>
              {/* Table Search & Title Header */}
              <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50/40">
                <div>
                  <h3 className="font-sans font-bold text-slate-800 text-sm flex items-center">
                    <FileText className="w-5 h-5 mr-2 text-indigo-500" />
                    Form {activeFormTab} Return Ledger ({returnQuarter})
                  </h3>
                  <p className="font-sans text-xs text-slate-400 mt-0.5">Showing records imported for active filing</p>
                </div>

                {/* Live Search bar */}
                <div className="relative">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <input
                    id="returns-search-input"
                    type="text"
                    placeholder="Query by Name, PAN, Sec..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-white border border-slate-200/80 rounded-xl px-10 py-1.5 text-xs text-slate-700 w-full sm:w-64 placeholder-slate-450 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              {/* Records Data Table */}
              {filteredRecords.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-100 text-[10px] font-sans font-bold text-slate-400 uppercase tracking-wider bg-slate-50/20">
                        <th className="py-4 px-6">Deductee</th>
                        <th className="py-4 px-4">Financials</th>
                        <th className="py-4 px-4">Section / Rate</th>
                        <th className="py-4 px-4">Challan Date</th>
                        <th className="py-4 px-4">Status</th>
                        <th className="py-4 px-6 text-right">Oltas Challan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredRecords.map((rec) => {
                        const isFlagged = rec.status === 'Flagged';
                        const isMatched = rec.challanStatus === 'Matched';
                        return (
                          <tr key={rec.id} className="hover:bg-slate-50/50 transition animate-fadeIn">
                            {/* Name & PAN */}
                            <td className="py-4 px-6">
                              <span className="font-sans font-semibold text-xs text-slate-800 block truncate max-w-[170px]" title={rec.deducteeName}>
                                {rec.deducteeName}
                              </span>
                              <span className="font-mono text-[10px] text-slate-400 flex items-center mt-1 uppercase">
                                {rec.pan}
                                {rec.aadhaarLinked ? (
                                  <span className="ml-1.5 px-1 bg-emerald-50 text-emerald-600 rounded text-[8px] font-bold">Aadhaar Linked</span>
                                ) : (
                                  <span className="ml-1.5 px-1 bg-amber-50 text-amber-600 rounded text-[8px] font-bold">No Link</span>
                                )}
                              </span>
                            </td>
                            {/* Financials amount */}
                            <td className="py-4 px-4">
                              <span className="font-mono font-medium text-xs text-slate-700 block">
                                {formattingRupee(rec.amount)}
                              </span>
                              <span className="block font-mono text-[10px] text-indigo-500 mt-1">
                                TDS: {formattingRupee(rec.tdsAmount)}
                              </span>
                            </td>
                            {/* Rate & section */}
                            <td className="py-4 px-4 font-sans text-xs">
                              <span className="bg-indigo-50 text-indigo-650 font-medium px-2 py-0.5 rounded text-[10px]">Sec {rec.section}</span>
                              <span className="block text-[10px] text-slate-400 mt-1.5">Rate: {rec.rate}%</span>
                            </td>
                            {/* Date of payment */}
                            <td className="py-4 px-4 font-mono text-xs text-slate-500">
                              {rec.date}
                            </td>
                            {/* Compliance Status badge */}
                            <td className="py-4 px-4">
                              {isFlagged ? (
                                <span className="inline-flex items-center space-x-1 font-sans text-[10px] bg-amber-50 text-amber-700 border border-amber-100 px-2 py-0.5 rounded-full font-semibold">
                                  <AlertTriangle className="w-3 h-3 flex-shrink-0" />
                                  <span>Flagged</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center space-x-1 font-sans text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-100 px-2 py-0.5 rounded-full font-semibold">
                                  <ShieldCheck className="w-3 h-3 flex-shrink-0" />
                                  <span>Verified</span>
                                </span>
                              )}
                            </td>
                            {/* Challan matching symbol */}
                            <td className="py-4 px-6 text-right">
                              {isMatched ? (
                                <div>
                                  <span className="font-mono text-xs text-slate-700 font-medium whitespace-nowrap">Ch No: {rec.challanNo}</span>
                                  <span className="block font-sans text-[9px] text-emerald-500 mt-0.5">Matched & Cleared</span>
                                </div>
                              ) : (
                                <div>
                                  <span className="font-mono text-xs text-amber-600 font-semibold whitespace-nowrap">
                                    {rec.challanStatus === 'Unmatched' ? 'Unmatched Mismatch' : 'Unpaid Entry'}
                                  </span>
                                  <span className="block font-sans text-[9px] text-slate-400 mt-0.5">Review audit ledger</span>
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-16 text-center">
                  <FileText className="w-12 h-12 text-slate-300 mx-auto" />
                  <h4 className="font-sans font-bold text-slate-755 mt-4 text-sm text-slate-700">No filing records found</h4>
                  <p className="font-sans text-slate-400 text-xs max-w-sm mx-auto mt-2 leading-relaxed">
                    There are no verified transactions matching <span className="font-semibold text-slate-600">Form {activeFormTab}</span> for <span className="font-semibold text-slate-600">{returnQuarter}</span>. Go to the <span className="font-semibold text-indigo-600">Document Locker</span> to upload statement files.
                  </p>
                </div>
              )}
            </div>
            
            {/* Form Guidelines Drawer footer */}
            <div className="p-5 border-t border-slate-100 bg-slate-50/50 text-[11px] text-slate-500 font-sans leading-relaxed">
              <strong className="text-slate-700 font-medium">Filing Instructions (Form {activeFormTab}):</strong> Please ensure that all validation audits, PAN structures, and challan matched indicators are 100% green prior to signing the FVU. Returns are submitted under the Income Tax Dept TRACES utilities via registered corporate DSC.
            </div>
          </div>
        </div>
      )}

      {/* Quarter Wise Panel breakdown layout (Month Wise) */}
      {activeSubTab === 'quarter' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs">
            <h3 className="font-sans font-bold text-slate-800 text-sm mb-1">Quarterly Financial & Audit Breakdown</h3>
            <p className="font-sans text-xs text-slate-400 leading-relaxed max-w-xl">
              Expand each fiscal quarter below to inspect month-wise consolidated taxable basis, TDS summaries, and drill-down into specific lists.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {(Object.keys(quarterMonthBreakdown) as ('Q1'|'Q2'|'Q3'|'Q4')[]).map(qKey => {
              const qObj = quarterMonthBreakdown[qKey];
              return (
                <div key={qKey} className="bg-white border border-slate-150 rounded-2xl p-6 shadow-xs flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                      <div>
                        <span className="font-sans font-bold text-slate-800 text-sm">{qKey === 'Q1' ? 'Q1 (April - June)' : qKey === 'Q2' ? 'Q2 (July - Sept)' : qKey === 'Q3' ? 'Q3 (Oct - Dec)' : 'Q4 (Jan - March)'}</span>
                        <span className="block font-mono text-[10px] text-slate-400 mt-0.5">{qObj.count} deduction logs registered</span>
                      </div>
                      <span className="font-mono text-xs font-semibold px-2.5 py-1 bg-indigo-50 text-indigo-700 rounded-lg">FY 2025-26</span>
                    </div>

                    <div className="space-y-4">
                      {qObj.months.map(m => (
                        <div key={m.monthNum} className="p-3 bg-slate-50/50 hover:bg-indigo-50/20 rounded-xl flex items-center justify-between transition border border-slate-100">
                          <div>
                            <span className="font-sans font-bold text-xs text-slate-700 block">{m.name}</span>
                            <span className="font-mono text-[9px] text-slate-450 text-slate-400">{m.count} records registered</span>
                          </div>
                          
                          <div className="flex items-center space-x-4">
                            <div className="text-right">
                              <span className="block font-mono text-xs font-bold text-slate-800">{formattingRupee(m.totalAmount)}</span>
                              <span className="block font-mono text-[10px] text-emerald-600 font-semibold">TDS: {formattingRupee(m.totalTds)}</span>
                            </div>

                            <button
                              id={`drilldown-m-${m.monthNum}`}
                              disabled={m.count === 0}
                              onClick={() => openDrillDownDrawer(`${m.name} [Quarter ${qKey}] Returns Ledger`, m.items)}
                              className={`p-1.5 rounded-lg transition ${
                                m.count > 0 
                                  ? 'bg-indigo-50 hover:bg-indigo-100 text-indigo-650 cursor-pointer' 
                                  : 'bg-slate-100 text-slate-305 text-slate-300 cursor-not-allowed'
                              }`}
                              title="Explore month-wise records"
                            >
                              <ChevronRight className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between bg-slate-50/30 p-3 rounded-lg">
                    <div>
                      <span className="block text-[8px] uppercase tracking-wider text-slate-400 font-bold">Consolidated TDS</span>
                      <span className="font-mono text-xs font-bold text-indigo-650 text-indigo-700">{formattingRupee(qObj.totalTds)}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] uppercase tracking-wider text-slate-400 font-bold">Taxable Amount</span>
                      <span className="font-mono text-xs font-bold text-slate-700">{formattingRupee(qObj.totalAmount)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Sections Wise Panel breakdown layout (Month Wise) */}
      {activeSubTab === 'section' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs">
            <h3 className="font-sans font-bold text-slate-800 text-sm mb-1">Section Wise Month-by-Month Audits</h3>
            <p className="font-sans text-xs text-slate-400 leading-relaxed max-w-xl">
              Inspect your TDS/TCS entries pooled according to individual Income Tax Act Sections, featuring detailed monthly aggregates.
            </p>
          </div>

          {sectionBreakdown.length > 0 ? (
            <div className="space-y-6">
              {sectionBreakdown.map(secObj => (
                <div key={secObj.section} className="bg-white border border-slate-150 rounded-2xl p-6 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3 mb-4">
                    <div className="flex items-center space-x-3.5">
                      <div className="p-2.5 bg-indigo-50 text-indigo-700 rounded-xl">
                        <Tag className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-sans font-bold text-slate-800 text-sm">Income Tax Section {secObj.section}</h4>
                        <span className="block font-mono text-[10px] text-slate-400 mt-0.5">{secObj.count} registered audit deductions</span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-6">
                      <div className="text-left sm:text-right">
                        <span className="block text-[9px] uppercase tracking-wider text-slate-400 font-bold">Section Volume</span>
                        <span className="font-mono text-xs font-bold text-slate-800">{formattingRupee(secObj.totalAmount)}</span>
                      </div>
                      <div className="text-left sm:text-right">
                        <span className="block text-[9px] uppercase tracking-wider text-slate-400 font-bold">Consolidated TDS</span>
                        <span className="font-mono text-xs font-bold text-emerald-600">{formattingRupee(secObj.totalTds)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Monthly grid row within this section */}
                  <h5 className="font-sans text-[10px] text-slate-400 uppercase tracking-wider font-bold mb-3">Month-wise Breakout</h5>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                    {Object.keys(secObj.months).map(mNumStr => {
                      const mNum = parseInt(mNumStr, 10);
                      const mData = secObj.months[mNum];
                      if (mData.count === 0) return null; // Only show months with records
                      return (
                        <div key={mNum} className="p-3 bg-slate-50 border border-slate-150 rounded-xl hover:border-indigo-200 transition flex flex-col justify-between h-28">
                          <div>
                            <span className="font-sans font-bold text-xs text-slate-700 block">{mData.name}</span>
                            <span className="font-mono text-[9px] text-slate-400">{mData.count} deductions</span>
                          </div>
                          <div className="mt-3">
                            <span className="block font-mono text-xs font-bold text-slate-850 text-slate-800">{formattingRupee(mData.totalAmount)}</span>
                            <button
                              id={`explore-sec-${secObj.section}-m-${mNum}`}
                              onClick={() => openDrillDownDrawer(`Sec ${secObj.section} - ${mData.name} Ledger`, mData.items)}
                              className="font-sans text-[10px] text-indigo-600 hover:text-indigo-800 font-semibold flex items-center mt-1 cursor-pointer"
                            >
                              <span>Explore</span>
                              <ChevronRight className="w-3 h-3 ml-0.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-16 text-center bg-white border border-slate-100 rounded-3xl">
              <Tag className="w-12 h-12 text-slate-350 text-slate-300 mx-auto" />
              <h4 className="font-sans font-bold text-slate-750 mt-4 text-sm text-slate-700">No segment divisions found</h4>
              <p className="font-sans text-slate-400 text-xs mt-2 leading-relaxed max-w-sm mx-auto">
                No sections could be mapped. Upload your returns from the locker system first to populate these dynamically.
              </p>
            </div>
          )}
        </div>
      )}

      {/* PAN Wise Panel breakdown layout (Month Wise) */}
      {activeSubTab === 'pan' && (
        <div className="space-y-6 animate-fadeIn">
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs">
            <h3 className="font-sans font-bold text-slate-800 text-sm mb-1">Individual Deductees & PAN Audit Register</h3>
            <p className="font-sans text-xs text-slate-400 leading-relaxed max-w-xl">
              Complete catalog of unique PAN holders. Check verification statuses, Aadhaar integration matching, and explore month-by-month deduction details.
            </p>
          </div>

          {panBreakdown.length > 0 ? (
            <div className="space-y-4">
              {panBreakdown.map(pObj => (
                <div key={pObj.pan} className="bg-white border border-slate-150 rounded-2xl p-5 shadow-xs hover:shadow-sm transition flex flex-col md:flex-row md:items-center justify-between gap-6">
                  {/* Left Side: Name and PAN */}
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="font-sans font-bold text-slate-800 text-sm truncate" title={pObj.deducteeName}>
                        {pObj.deducteeName}
                      </h4>
                      <span className="font-mono text-[9px] uppercase tracking-wider font-bold bg-slate-100 text-slate-650 px-2 py-0.5 rounded border">
                        PAN: {pObj.pan}
                      </span>
                      {pObj.aadhaarLinked ? (
                        <span className="text-[8px] font-sans font-bold bg-emerald-50 text-emerald-600 px-1.5 py-0.2 rounded border border-emerald-100">
                          Aadhaar Linked
                        </span>
                      ) : (
                        <span className="text-[8px] font-sans font-bold bg-amber-50 text-amber-600 px-1.5 py-0.2 rounded border border-amber-105">
                          Unlinked/PAN Rule 206AA
                        </span>
                      )}
                    </div>

                    {/* Horizontal months list */}
                    <div className="mt-3.5 flex flex-wrap gap-2">
                      {Object.keys(pObj.months).map(mNumStr => {
                        const mNum = parseInt(mNumStr, 10);
                        const mData = pObj.months[mNum];
                        if (mData.count === 0) return null;
                        return (
                          <button
                            id={`pan-${pObj.pan}-m-${mNum}`}
                            key={mNum}
                            onClick={() => openDrillDownDrawer(`${pObj.deducteeName} (${pObj.pan}) - ${mData.name} Logs`, mData.items)}
                            className="px-2.5 py-1 bg-slate-50 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-200 transition text-[10px] font-sans rounded-lg text-slate-600 hover:text-indigo-700 flex items-center space-x-1 font-semibold cursor-pointer"
                          >
                            <span>{mData.name.substring(0, 3)}</span>
                            <span className="font-mono text-[9px] bg-slate-200 text-slate-700 px-1 rounded-sm">{mData.count}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Right Side: Totals and Drawer explore */}
                  <div className="flex items-center space-x-8 flex-shrink-0 border-t md:border-t-0 pt-4 md:pt-0">
                    <div>
                      <span className="block text-[8px] uppercase tracking-wider text-slate-400 font-bold">Total Paid</span>
                      <span className="font-mono text-xs font-bold text-slate-750 text-slate-800">{formattingRupee(pObj.totalAmount)}</span>
                    </div>

                    <div>
                      <span className="block text-[8px] uppercase tracking-wider text-slate-400 font-bold">Total Tax</span>
                      <span className="font-mono text-xs font-bold text-emerald-600">{formattingRupee(pObj.totalTds)}</span>
                    </div>

                    <button
                      id={`pan-full-ledger-btn-${pObj.pan}`}
                      onClick={() => {
                        // Gather all records for this PAN
                        const allPanRecords = categoryRecords.filter(r => r.pan.toUpperCase() === pObj.pan.toUpperCase());
                        openDrillDownDrawer(`${pObj.deducteeName} - Consolidated Ledger`, allPanRecords);
                      }}
                      className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-sans font-bold text-xs rounded-xl transition flex items-center space-x-1.5 cursor-pointer border border-indigo-100/50"
                    >
                      <User className="w-3.5 h-3.5" />
                      <span>Ledger</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-16 text-center bg-white border border-slate-100 rounded-3xl">
              <User className="w-12 h-12 text-slate-350 text-slate-300 mx-auto" />
              <h4 className="font-sans font-bold text-slate-755 mt-4 text-sm text-slate-730">No Unique PANs Found</h4>
              <p className="font-sans text-slate-400 text-xs mt-2 leading-relaxed max-w-sm mx-auto">
                No active deductee records registered. Go to Document Locker and upload returns files to auto-populate.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Drill-down slide out / drawer popup modal */}
      {isDrawerOpen && (
        <div id="drilldown-drawer-modal" className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl border border-slate-100 max-w-4xl w-full max-h-[85vh] flex flex-col justify-between shadow-2xl overflow-hidden animate-slideUp">
            
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="font-sans font-bold text-slate-800 text-sm flex items-center">
                  <Layers className="w-5 h-5 text-indigo-500 mr-2" />
                  {drawerTitle}
                </h3>
                <p className="font-sans text-xs text-slate-400 mt-0.5">Scanned {drawerRecords.length} complying transaction entries</p>
              </div>
              <button
                id="close-drawer-modal"
                onClick={() => setIsDrawerOpen(false)}
                className="p-1.5 rounded-lg bg-slate-100 hover:bg-rose-50 text-slate-400 hover:text-rose-600 transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Table */}
            <div className="overflow-y-auto p-4 flex-1">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-[10px] font-sans font-bold text-slate-400 uppercase bg-slate-50/20">
                    <th className="py-3 px-4">Deductee Address [PAN]</th>
                    <th className="py-3 px-3">Date</th>
                    <th className="py-3 px-3">Section</th>
                    <th className="py-3 px-3">Taxable Basis</th>
                    <th className="py-3 px-3">Rate</th>
                    <th className="py-3 px-4 text-right">Tax Deducted</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {drawerRecords.map((item, idx) => (
                    <tr key={item.id || idx} className="hover:bg-slate-50/40 text-xs">
                      <td className="py-3.5 px-4 font-sans font-semibold text-slate-800">
                        {item.deducteeName}
                        <span className="block font-mono text-[10px] text-slate-400 mt-0.5 uppercase font-normal">{item.pan}</span>
                      </td>
                      <td className="py-3.5 px-3 font-mono text-slate-500">{item.date}</td>
                      <td className="py-3.5 px-3"><span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[10px] font-medium font-sans">Sec {item.section}</span></td>
                      <td className="py-3.5 px-3 font-mono text-slate-850 font-medium">{formattingRupee(item.amount)}</td>
                      <td className="py-3.5 px-3 font-mono text-slate-500">{item.rate}%</td>
                      <td className="py-3.5 px-4 font-mono text-right font-bold text-emerald-600">{formattingRupee(item.tdsAmount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Footer summary stats */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="font-sans text-slate-500 font-semibold uppercase text-[10px]">Consolidated total:</span>
              <div className="flex items-center space-x-6">
                <div>
                  <span className="text-slate-400 text-[10px] block text-right font-bold uppercase">Taxable Volume</span>
                  <span className="font-mono font-bold text-slate-800">{formattingRupee(drawerRecords.reduce((a, b) => a + b.amount, 0))}</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block text-right font-bold uppercase">Captured Returns</span>
                  <span className="font-mono font-bold text-emerald-600">{formattingRupee(drawerRecords.reduce((a, b) => a + b.tdsAmount, 0))}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
