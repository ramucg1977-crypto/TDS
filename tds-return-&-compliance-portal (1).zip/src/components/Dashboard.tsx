/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Building, 
  IndianRupee, 
  Files, 
  Activity, 
  CheckCircle, 
  AlertTriangle, 
  Clock,
  Sparkles,
  ArrowRight,
  Briefcase,
  Shield,
  Coffee,
  Bookmark,
  RefreshCw,
  Lock,
  Compass
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Legend 
} from 'recharts';
import { TdsRecord, CompanyDetails } from '../types';

const THOUGHTS = [
  "Compliance is the lock, accuracy is the key, and absolute integrity is our fortress.",
  "Precision in tax management is not just a standard of quality — it is an ethical obligation.",
  "An audit is not merely an inspection; it is the ultimate shield protecting public and private trust.",
  "Numbers communicate the truth of our diligence. Every verified statement represents dedication.",
  "Accuracy is the twin brother of professional honesty; inaccuracy is a near relation to negligence.",
  "Diligence is the mother of precision. A perfect tax filing is the signature of a master practitioner."
];

const REFRESHMENT_NOTES = [
  "🍵 Premium Green Tea Breather: Continuous tax audits produce high ocular strain. Please protect your eyesight: glance 20 feet away for 20 seconds, stand up to stretch, and enjoy a warm brew!",
  "☕ Coffee & Refreshment Note: Have you hydrated sufficiently today? A refreshed mind prevents numerical transcription errors in high-value OLTAS filings. Take a quick tea or water break!",
  "🚶 Active Breather Note: Take a short 3-minute physical break away from the screen. Movement supplies a fresh energy flow, keeping mathematical calculations and reconciliations precise!"
];

interface DashboardProps {
  records: TdsRecord[];
  company: CompanyDetails | null;
  onNavigateToTab?: (tab: string) => void;
  onlineData?: {
    thought: string;
    refreshment: string;
    announcements: string[];
    detailedUpdates: any[];
  } | null;
  isSyncingUpdates?: boolean;
  lastSyncedTime?: string;
  onSyncUpdates?: () => void;
  activePeriod?: string;
  onSeedPeriodData?: (fy: string) => void;
  // Dynamic period simulation parameters
  simulatedYear?: number;
  setSimulatedYear?: React.Dispatch<React.SetStateAction<number>>;
  periodsList?: string[];
  setActivePeriod?: (fy: string) => void;
}

export default function Dashboard({ 
  records, 
  company, 
  onNavigateToTab,
  onlineData,
  isSyncingUpdates,
  lastSyncedTime,
  onSyncUpdates,
  activePeriod = '2025-26',
  onSeedPeriodData,
  simulatedYear = 2026,
  setSimulatedYear,
  periodsList = ['2025-26', '2024-25', '2023-24', '2022-23'],
  setActivePeriod
}: DashboardProps) {
  const [selectedQuarter, setSelectedQuarter] = useState<string>('All');
  const [selectedSection, setSelectedSection] = useState<string>('All');

  // Thought and Refreshment Rotation indices
  const [thoughtIndex, setThoughtIndex] = useState(() => Math.floor(Math.random() * THOUGHTS.length));
  const [refreshIndex, setRefreshIndex] = useState(() => Math.floor(Math.random() * REFRESHMENT_NOTES.length));

  const handleNextThought = () => {
    if (onSyncUpdates) {
      onSyncUpdates();
    } else {
      setThoughtIndex((prev) => (prev + 1) % THOUGHTS.length);
    }
  };

  const handleNextRefreshment = () => {
    if (onSyncUpdates) {
      onSyncUpdates();
    } else {
      setRefreshIndex((prev) => (prev + 1) % REFRESHMENT_NOTES.length);
    }
  };

  const activeThought = onlineData?.thought || THOUGHTS[thoughtIndex];
  const activeRefreshment = onlineData?.refreshment || REFRESHMENT_NOTES[refreshIndex];

  // Filtered records
  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      const qMatch = selectedQuarter === 'All' || r.quarter === selectedQuarter;
      const sMatch = selectedSection === 'All' || r.section === selectedSection;
      return qMatch && sMatch;
    });
  }, [records, selectedQuarter, selectedSection]);

  // Primary calculations
  const stats = useMemo(() => {
    let totalTaxable = 0;
    let totalTds = 0;
    let verifiedCount = 0;
    let flaggedCount = 0;
    let pendingCount = 0;

    filteredRecords.forEach(r => {
      totalTaxable += r.amount;
      totalTds += r.tdsAmount;
      if (r.status === 'Verified') verifiedCount++;
      if (r.status === 'Flagged') flaggedCount++;
      if (r.status === 'Pending') pendingCount++;
    });

    const matchRatio = filteredRecords.length > 0 
      ? Math.round((filteredRecords.filter(r => r.challanStatus === 'Matched').length / filteredRecords.length) * 100) 
      : 0;

    return { totalTaxable, totalTds, verifiedCount, flaggedCount, pendingCount, matchRatio };
  }, [filteredRecords]);

  // Quarter-wise segregation data for recharts
  const quarterData = useMemo(() => {
    const quarters = { Q1: 0, Q2: 0, Q3: 0, Q4: 0 };
    filteredRecords.forEach(r => {
      if (quarters[r.quarter] !== undefined) {
        quarters[r.quarter] += r.tdsAmount;
      }
    });

    return [
      { name: 'Q1 (April-June)', TDS: quarters.Q1 },
      { name: 'Q2 (July-Sept)', TDS: quarters.Q2 },
      { name: 'Q3 (Oct-Dec)', TDS: quarters.Q3 },
      { name: 'Q4 (Jan-March)', TDS: quarters.Q4 },
    ];
  }, [filteredRecords]);

  // Section-wise segregation for recharts
  const sectionData = useMemo(() => {
    const sections: { [key: string]: number } = {};
    filteredRecords.forEach(r => {
      sections[r.section] = (sections[r.section] || 0) + r.tdsAmount;
    });

    return Object.keys(sections).map(sec => ({
      name: `Sec ${sec}`,
      value: sections[sec]
    })).sort((a, b) => b.value - a.value);
  }, [filteredRecords]);

  // Top Section List
  const sectionsList = useMemo(() => {
    const sections: { [key: string]: { amount: number; tds: number; count: number } } = {};
    filteredRecords.forEach(r => {
      if (!sections[r.section]) {
        sections[r.section] = { amount: 0, tds: 0, count: 0 };
      }
      sections[r.section].amount += r.amount;
      sections[r.section].tds += r.tdsAmount;
      sections[r.section].count += 1;
    });
    return Object.keys(sections).map(key => ({
      section: key,
      ...sections[key]
    })).sort((a, b) => b.tds - a.tds);
  }, [filteredRecords]);

  // PAN-wise segregation
  const panData = useMemo(() => {
    const pans: { [key: string]: { name: string; tds: number; count: number } } = {};
    filteredRecords.forEach(r => {
      if (!pans[r.pan]) {
        pans[r.pan] = { name: r.deducteeName, tds: 0, count: 0 };
      }
      pans[r.pan].tds += r.tdsAmount;
      pans[r.pan].count += 1;
    });

    return Object.keys(pans).map(p => ({
      pan: p,
      name: pans[p].name,
      tds: pans[p].tds,
      count: pans[p].count
    })).sort((a, b) => b.tds - a.tds).slice(0, 5);
  }, [filteredRecords]);

  // Challan Summary Tracker
  const challanStats = useMemo(() => {
    let matched = 0;
    let unmatched = 0;
    let unpaid = 0;

    filteredRecords.forEach(r => {
      if (r.challanStatus === 'Matched') matched++;
      if (r.challanStatus === 'Unmatched') unmatched++;
      if (r.challanStatus === 'Unpaid') unpaid++;
    });

    return { matched, unmatched, unpaid };
  }, [filteredRecords]);

  // Colors for section pie chart
  const COLORS = ['#6366f1', '#06b6d4', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

  // All unique sections in current dataset for filter dropdown
  const uniqueSections = useMemo(() => {
    const set = new Set<string>();
    records.forEach(r => set.add(r.section));
    return Array.from(set);
  }, [records]);

  const formattingRupee = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(value);
  };

  // Redesigned Santhappa & Co Dashboard Empty / Welcome State
  if (records.length === 0) {
    return (
      <div className="space-y-8 animate-fadeIn max-w-6xl mx-auto">
        {/* Main Welcome Hero Badge */}
        <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/60 rounded-3xl p-8 md:p-10 text-white relative overflow-hidden shadow-2xl">
          <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
          <div className="relative z-10 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center space-x-3.5">
                <div className="w-14 h-14 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300 shadow-inner">
                  <Shield className="w-7 h-7" />
                </div>
                <div>
                  <span className="font-mono text-[10px] uppercase tracking-widest text-indigo-400 font-bold bg-indigo-500/10 px-2.5 py-1 rounded-md border border-indigo-500/10">PREMIUM COMPLIANCE PLATFORM</span>
                  <h1 className="font-sans font-extrabold text-xl md:text-2xl text-white tracking-tight mt-1">
                    SANTHAPPA & CO • TDS MANAGEMENT CENTRE ({activePeriod})
                  </h1>
                </div>
              </div>
              <div className="flex items-center space-x-2 bg-slate-950/60 px-4 py-1.5 rounded-xl border border-slate-800 text-xs font-mono text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>SECURE SSL 256-BIT CRYPTO</span>
              </div>
            </div>

            <p className="font-sans text-slate-300 text-sm max-w-2xl leading-relaxed">
              We welcome you to our professional auditing environment. This console acts as a secure, local-first repository to parse caretaker-delimited 
              e-TDS NSDL files, audit matching challans, and draft compliant tax ledger declarations across Forms 24Q, 26Q, 27Q, and 27EQ for <strong className="text-white">Filing Period FY {activePeriod}</strong>.
            </p>

            {/* Quick Action Entrypoint Launcher */}
            <div className="flex flex-wrap gap-3.5 pt-2">
              <button
                onClick={() => onNavigateToTab && onNavigateToTab('documents')}
                className="flex items-center space-x-2 px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans text-xs font-bold transition shadow-md shadow-indigo-600/30 active:scale-95 cursor-pointer"
              >
                <span>Launch Document Locker (Upload FVU)</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => onSeedPeriodData && onSeedPeriodData(activePeriod)}
                className="flex items-center space-x-2 px-5 py-3 rounded-xl bg-slate-850 hover:bg-slate-850 hover:text-indigo-200 border border-slate-700/80 font-sans text-xs font-bold transition shadow-md active:scale-95 cursor-pointer text-indigo-300"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                <span>Seed Audited Records for FY {activePeriod}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Dynamic Interactive Widgets Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Section: Thought for Day */}
          <div className="bg-white border border-slate-150 rounded-3xl p-6 shadow-sm relative flex flex-col justify-between hover:border-indigo-100 transition duration-300">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 text-indigo-600">
                  <Bookmark className="w-4 h-4" />
                  <span className="font-sans font-bold text-xs uppercase tracking-wider">Thought for the Day</span>
                </div>
                <button
                  onClick={handleNextThought}
                  className="p-1 px-2.5 rounded-lg border border-slate-100 hover:bg-slate-50 transition font-sans text-[10px] text-slate-500 font-bold flex items-center space-x-1"
                  title="Next Thought"
                >
                  <RefreshCw className="w-3 h-3 text-slate-400 mr-1" />
                  <span>Next Quote</span>
                </button>
              </div>
              <p className="font-sans italic text-slate-700 text-sm leading-relaxed pr-2">
                "{activeThought}"
              </p>
            </div>
            <div className="pt-4 border-t border-slate-50 mt-4 text-[10px] text-slate-400 font-sans">
              SANTHAPPA & CO. ETHICAL AUDITING GUIDES • {onlineData ? "LIVE PORTAL FEED" : `ACTIVE CACHE REF: T${thoughtIndex + 1}`}
            </div>
          </div>

          {/* Section: Refreshment Notes */}
          <div className="bg-slate-50 border border-slate-100 rounded-3xl p-6 relative flex flex-col justify-between hover:border-amber-100 hover:bg-amber-50/10 transition duration-300">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 text-amber-600">
                  <Coffee className="w-4 h-4 text-amber-500" />
                  <span className="font-sans font-bold text-xs uppercase tracking-wider">Refreshment Note</span>
                </div>
                <button
                  onClick={handleNextRefreshment}
                  className="p-1 px-2.5 rounded-lg border border-slate-200 hover:bg-slate-150/40 transition font-sans text-[10px] text-slate-600 font-bold flex items-center space-x-1"
                  title="Cycle Reminders"
                >
                  <RefreshCw className="w-3 h-3 text-slate-400 mr-1" />
                  <span>Cycle Breathers</span>
                </button>
              </div>
              <p className="font-sans text-slate-650 text-xs leading-relaxed">
                {activeRefreshment}
              </p>
            </div>
            <div className="pt-4 border-t border-slate-100/60 mt-4 text-[10px] text-amber-650 font-sans font-semibold">
              ☕ CAFFEINE, HYDRO & POSTURE HEALTH REMINDERS FOR TAX DESKS
            </div>
          </div>
        </div>

        {/* Layout Locker Details */}
        <div className="bg-white border border-slate-100 rounded-3xl p-6 text-center shadow-xs">
          <Lock className="w-8 h-8 text-slate-300 mx-auto" />
          <h3 className="font-sans font-bold text-slate-700 mt-3 text-sm">Auditing Cabinet Restricted</h3>
          <p className="font-sans text-slate-450 text-slate-400 text-xs mt-1 max-w-sm mx-auto leading-relaxed">
            Please deposit NSDL caret-delimited statements in the Document Locker tab. Once imported, compliance analytics charts will automatically resolve.
          </p>
        </div>

        {/* Dynamic Filing Period & Future Rollover Console */}
        <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-500">
                <Compass className="w-5 h-5 animate-spin-slow" />
              </div>
              <div>
                <span className="font-mono text-[9px] uppercase tracking-widest text-indigo-600 font-bold">compliance timeline sandbox</span>
                <h3 className="font-sans font-bold text-slate-800 text-sm">Filing Period Rollovers & Future Forecasting</h3>
              </div>
            </div>

            {/* Simulate rollover controls */}
            <div className="flex items-center space-x-2">
              <span className="font-sans text-[10px] text-slate-450 text-slate-400 font-semibold uppercase">Simulated Date: June {simulatedYear}</span>
              <button
                onClick={() => {
                  if (setSimulatedYear) {
                    setSimulatedYear(prev => {
                      const next = prev + 1;
                      // Automatically switch to the new dynamic natural year as the default activePeriod
                      const nextEndYear = (next + 1) % 100;
                      const endPadded = nextEndYear < 10 ? '0' + nextEndYear : '' + nextEndYear;
                      const nextFy = `${next}-${endPadded}`;
                      if (setActivePeriod) setActivePeriod(nextFy);
                      return next;
                    });
                  }
                }}
                className="flex items-center space-x-1.5 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-sans text-xs font-bold px-3 py-1.5 rounded-xl transition shadow-sm cursor-pointer hover:shadow-md hover:scale-102 active:scale-95 duration-200"
                title="Simulate Year-End Rollover to next Fiscal Year"
              >
                <RefreshCw className="w-3 h-3 animate-spin text-white" />
                <span>Simulate Year End / Rollover</span>
              </button>
            </div>
          </div>

          <p className="font-sans text-xs text-slate-500 leading-relaxed text-justify">
            The Indian Financial Year (FY) rolls over every March 31st. This compliance dashboard is fully future-ready and dynamically shifts with calendar transitions. Below, manage and monitor filing portals for subsequent accounting epochs. You can seed mock validation data for future fiscal years to verify multi-period reporting structures automatically.
          </p>

          {/* Dynamic List Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {periodsList.slice(0, 6).map(fy => {
              const startYear = parseInt(fy.split('-')[0], 10);
              const ayYear = startYear + 1;
              const ayEnd = (ayYear + 1) % 100;
              const ayStr = `${ayYear}-${ayEnd < 10 ? '0' + ayEnd : ayEnd}`;
              const isSelected = activePeriod === fy;
              
              return (
                <div
                  key={fy}
                  className={`p-4 rounded-2xl border transition duration-200 flex flex-col justify-between ${
                    isSelected 
                    ? 'bg-indigo-50/40 border-indigo-200 shadow-xs' 
                    : 'bg-slate-50/50 border-slate-100 hover:bg-slate-50 hover:border-slate-200'
                  }`}
                >
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-sans font-extrabold text-xs text-slate-800">FY {fy}</span>
                      {isSelected && (
                        <span className="bg-indigo-600 text-white font-mono text-[9px] uppercase tracking-wide px-2 py-0.5 rounded font-extrabold">
                          ACTIVE
                        </span>
                      )}
                    </div>
                    <span className="block font-mono text-[10px] text-slate-450 text-slate-400">Assessment Year: AY {ayStr}</span>
                    <p className="font-sans text-[10px] text-slate-500 mt-1.5 leading-relaxed">
                      Compliance status: {startYear > 2026 ? "⚠️ Future Aspect Draft" : "✓ Active Period"}
                    </p>
                  </div>

                  <div className="flex items-center space-x-2 mt-4 pt-3 border-t border-slate-100/60 font-sans">
                    <button
                      onClick={() => setActivePeriod && setActivePeriod(fy)}
                      disabled={isSelected}
                      className={`flex-1 text-[10px] font-sans font-bold py-1 px-2 rounded-lg text-center transition cursor-pointer ${
                        isSelected 
                        ? 'bg-slate-200/55 text-slate-400 cursor-not-allowed'
                        : 'bg-white hover:bg-indigo-50 text-indigo-600 border border-indigo-100'
                      }`}
                    >
                      Select FY
                    </button>
                    <button
                      onClick={() => onSeedPeriodData && onSeedPeriodData(fy)}
                      className="flex-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-[10px] font-sans font-bold py-1 px-2 rounded-lg text-center transition border border-indigo-100 cursor-pointer"
                      title="Seed standard compliance seed records"
                    >
                      Seed Data
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div id="dashboard-view" className="space-y-8 animate-fadeIn">
      {/* Redesigned Branded Header Block */}
      <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 border border-indigo-900/45 rounded-3xl p-6 text-white relative shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center space-x-2 bg-indigo-500/10 px-2.5 py-1 rounded border border-indigo-500/20 w-fit">
            <Shield className="w-3.5 h-3.5 text-indigo-400" />
            <span className="font-mono text-[9px] uppercase tracking-wider text-indigo-300 font-bold">SANTHAPPA & CO • CENTRAL AUDITING STATION</span>
          </div>
          <h2 className="font-sans font-extrabold text-lg md:text-xl text-white tracking-tight mt-2">
            {company?.companyName || "Consolidated Client Portal"}
          </h2>
          <p className="font-sans text-[11px] text-slate-350 mt-1">
            Assessment Year: <strong className="text-white">{company?.assessmentYear}</strong> | Financial Year: <strong className="text-white">{company?.financialYear}</strong>
          </p>
        </div>

        {/* Dynamic Mini Quote Rotator on active dashboard */}
        <div className="bg-slate-950/65 border border-slate-800 rounded-2xl p-4 max-w-md">
          <div className="flex items-center space-x-1.5 text-indigo-400 mb-1">
            <Bookmark className="w-3.5 h-3.5" />
            <span className="font-sans font-bold text-[9px] uppercase tracking-wider">Thought & Wisdom</span>
            {isSyncingUpdates && <RefreshCw className="w-2.5 h-2.5 text-indigo-400 animate-spin ml-1" />}
          </div>
          <p className="font-sans italic text-slate-300 text-xs leading-relaxed">
            "{activeThought}"
          </p>
          <div className="flex justify-between items-center mt-2 pt-2 border-t border-slate-900 text-[8px] text-slate-500">
            <span>{onlineData ? "ONLINE SYNCED" : `REFRESH: T${thoughtIndex + 1}`}</span>
            <button onClick={handleNextThought} className="hover:text-indigo-400 transition font-bold font-mono uppercase">SYNC Wisdom ➔</button>
          </div>
        </div>
      </div>

      {/* Coffee reminder for logged in users */}
      <div className="bg-amber-50/50 border border-amber-100 rounded-2xl p-4 flex items-center justify-between text-xs text-amber-800 font-sans">
        <div className="flex items-center space-x-2.5">
          <Coffee className="w-4 h-4 text-amber-500 animate-bounce" />
          <span>{activeRefreshment}</span>
        </div>
        <button onClick={handleNextRefreshment} className="font-sans font-bold text-[10px] text-amber-700 bg-amber-100 hover:bg-amber-200/80 transition px-2.5 py-1 rounded-lg">Cycle Breather Note</button>
      </div>

      {/* Top filter row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between p-4 bg-white border border-slate-100 rounded-2xl shadow-xs gap-4">
        <span className="font-sans text-xs text-slate-500 font-medium">Reconciled Core ledger data analytics filtering options:</span>
        <div className="flex flex-wrap gap-3">
          <div className="flex flex-col">
            <select
              id="dash-quarter-select"
              value={selectedQuarter}
              onChange={(e) => setSelectedQuarter(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-sans text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            >
              <option value="All">All Quarters (Consolidated)</option>
              <option value="Q1">Q1 (Apr - Jun)</option>
              <option value="Q2">Q2 (Jul - Sep)</option>
              <option value="Q3">Q3 (Oct - Dec)</option>
              <option value="Q4">Q4 (Jan - Mar)</option>
            </select>
          </div>

          <div className="flex flex-col">
            <select
              id="dash-section-select"
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-sans text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            >
              <option value="All">All Sections</option>
              {uniqueSections.map(sec => (
                <option key={sec} value={sec}>Section {sec}</option>
              ))}
            </select>
          </div>
        </div>
      </div>


      {/* Numerical Stats overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Card 1: Total Deducted */}
        <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-xs flex items-center space-x-5 hover:shadow-md hover:border-indigo-100 transition duration-300">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-500 flex-shrink-0">
            <IndianRupee className="w-6 h-6" />
          </div>
          <div>
            <span className="font-sans text-xs text-slate-400 font-medium">Total Deducted / Paid</span>
            <h3 className="font-sans font-bold text-xl text-slate-800 mt-1">{formattingRupee(stats.totalTds)}</h3>
            <span className="font-mono text-[9px] text-slate-500 bg-slate-50 px-1.5 py-0.5 rounded">TDS Core Collection</span>
          </div>
        </div>

        {/* Card 2: Total Taxable base */}
        <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-xs flex items-center space-x-5 hover:shadow-md hover:border-emerald-100 transition duration-300">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-500 flex-shrink-0">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <span className="font-sans text-xs text-slate-400 font-medium">Total Exemption Base</span>
            <h3 className="font-sans font-bold text-xl text-slate-800 mt-1">{formattingRupee(stats.totalTaxable)}</h3>
            <span className="font-mono text-[9px] text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded font-semibold">Compliance Safe</span>
          </div>
        </div>

        {/* Card 3: Challan Matching index */}
        <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-xs flex items-center space-x-5 hover:shadow-md hover:border-cyan-100 transition duration-300">
          <div className="w-12 h-12 rounded-2xl bg-cyan-50 flex items-center justify-center text-cyan-500 flex-shrink-0">
            <CheckCircle className="w-6 h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <span className="font-sans text-xs text-slate-400 font-medium">Challan Match Ratio</span>
            <h3 className="font-sans font-bold text-xl text-slate-800 mt-1">{stats.matchRatio}%</h3>
            <div className="w-full bg-slate-100 h-1.5 rounded-full mt-2 overflow-hidden">
              <div 
                className={`h-full rounded-full ${stats.matchRatio > 80 ? 'bg-emerald-500' : 'bg-amber-500'}`} 
                style={{ width: `${stats.matchRatio}%` }}
              />
            </div>
          </div>
        </div>

        {/* Card 4: Compliance alerts */}
        <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-xs flex items-center space-x-5 hover:shadow-md hover:border-rose-100 transition duration-300">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 ${stats.flaggedCount > 0 ? 'bg-amber-550/10 text-amber-500 animate-pulse' : 'bg-slate-50 text-slate-400'}`}>
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <span className="font-sans text-xs text-slate-400 font-medium">Compliance Alerts</span>
            <h3 className="font-sans font-bold text-xl text-slate-800 mt-1">{stats.flaggedCount} Flagged</h3>
            <span className="font-mono text-[9px] text-rose-500 bg-rose-50 px-1.5 py-0.5 rounded font-semibold">Action Required</span>
          </div>
        </div>
      </div>

      {/* Main Charts block */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Core Quarter trends bar */}
        <div className="lg:col-span-2 p-6 bg-white border border-slate-100 rounded-3xl shadow-xs">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-sans font-bold text-slate-800 text-sm">Quarterly TDS Volume</h3>
              <p className="font-sans text-xs text-slate-400">TDS liability timeline for {company?.financialYear}</p>
            </div>
            <div className="flex items-center space-x-1.5 text-xs text-slate-500 font-sans">
              <Clock className="w-4 h-4 text-indigo-500" />
              <span>Real-time Sync</span>
            </div>
          </div>
          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={quarterData} margin={{ top: 10, right: 10, left: 0, bottom: 5 }}>
                <defs>
                  <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6366f1" stopOpacity={0.95}/>
                    <stop offset="100%" stopColor="#4f46e5" stopOpacity={0.6}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickFormatter={(val) => `₹${val/1000}k`} tickLine={false} axisLine={false} />
                <Tooltip 
                  formatter={(val: number) => [formattingRupee(val), 'Total TDS']}
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', color: '#f8fafc' }}
                  labelStyle={{ color: '#cbd5e1', fontWeight: 'bold' }}
                />
                <Bar dataKey="TDS" fill="url(#barGrad)" radius={[8, 8, 0, 0]} barSize={45} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Section-wise Pie Contribution chart */}
        <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-xs flex flex-col">
          <h3 className="font-sans font-bold text-slate-800 text-sm mb-1">Section-wise Share</h3>
          <p className="font-sans text-xs text-slate-400 mb-6 font-light">Distribution of tax across provisions</p>
          
          <div className="h-[200px] w-full relative flex-1 flex items-center justify-center">
            {sectionData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={sectionData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {sectionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(val: number) => [formattingRupee(val), 'TDS Amount']}
                    contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '10px', color: '#f8fafc' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center text-slate-400 text-xs font-mono">No Section Data</div>
            )}
            <div className="absolute flex flex-col items-center">
              <span className="font-mono text-[10px] uppercase tracking-wider text-slate-400 font-medium font-semibold">Total Share</span>
              <span className="font-sans font-extrabold text-slate-800 text-lg">{formattingRupee(stats.totalTds)}</span>
            </div>
          </div>

          {/* Section Legends */}
          <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
            {sectionData.slice(0, 4).map((entry, idx) => (
              <div key={entry.name} className="flex items-center space-x-1.5 min-w-0">
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                <span className="font-medium text-slate-650 truncate uppercase font-sans tracking-tight">{entry.name}</span>
                <span className="font-mono text-[10px] text-slate-400">({Math.round((entry.value/stats.totalTds)*100)}%)</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Challan and PAN detailed Analytics Lists */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* PAN-wise Top Deductee List */}
        <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-xs">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="font-sans font-bold text-slate-800 text-sm">Top Deductees (PAN Analytics)</h3>
              <p className="font-sans text-xs text-slate-400">Highest compliance tax volume allocation</p>
            </div>
            <span className="font-mono text-[10px] bg-slate-50 text-indigo-600 px-2 py-1 rounded font-semibold uppercase">PAN verified</span>
          </div>

          <div className="space-y-4">
            {panData.map((pd, index) => (
              <div key={pd.pan} className="flex items-center justify-between p-3.5 bg-slate-50 hover:bg-slate-100/60 rounded-2xl transition duration-200">
                <div className="flex items-center space-x-3.5 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-indigo-50 flex items-center justify-center font-sans font-bold text-xs text-indigo-600">
                    {index + 1}
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-sans font-semibold text-xs text-slate-800 truncate" title={pd.name}>
                      {pd.name}
                    </h4>
                    <p className="font-mono text-[10px] text-slate-400 mt-0.5 uppercase">
                      {pd.pan} <span className="mx-1">•</span> {pd.count} {pd.count === 1 ? 'record' : 'records'}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-xs text-slate-700">{formattingRupee(pd.tds)}</span>
                  <span className="block font-sans text-[9px] text-slate-400 mt-0.5">{Math.round((pd.tds / stats.totalTds) * 100)}% contribution</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Challan status & matching desk */}
        <div className="p-6 bg-white border border-slate-100 rounded-3xl shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="font-sans font-bold text-slate-800 text-sm mb-1">Challan Reconciliation Desk</h3>
            <p className="font-sans text-xs text-slate-400 mb-6">Real-time matching status on ITD TRACES Portal</p>

            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="p-4 bg-emerald-50/50 border border-emerald-100 rounded-2xl text-center">
                <span className="block font-sans text-[10px] text-emerald-600 font-semibold uppercase tracking-wider">Matched</span>
                <span className="font-mono text-2xl font-extrabold text-emerald-600 mt-1 block">{challanStats.matched}</span>
                <span className="font-sans text-[9px] text-emerald-500 block mt-1">Cleared in FVU</span>
              </div>
              <div className="p-4 bg-amber-50/50 border border-amber-100 rounded-2xl text-center">
                <span className="block font-sans text-[10px] text-amber-600 font-semibold uppercase tracking-wider">Unmatched</span>
                <span className="font-mono text-2xl font-extrabold text-amber-600 mt-1 block">{challanStats.unmatched}</span>
                <span className="font-sans text-[9px] text-amber-500 block mt-1">Review ledger</span>
              </div>
              <div className="p-4 bg-slate-50 border border-slate-200/60 rounded-2xl text-center">
                <span className="block font-sans text-[10px] text-slate-600 font-semibold uppercase tracking-wider">Unpaid</span>
                <span className="font-mono text-2xl font-extrabold text-slate-600 mt-1 block">{challanStats.unpaid}</span>
                <span className="font-sans text-[9px] text-slate-400 block mt-1">Liability open</span>
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-150 rounded-2xl p-4">
              <div className="flex items-start space-x-3">
                <Briefcase className="w-5 h-5 text-indigo-500 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-sans font-semibold text-xs text-slate-800">Compliance Reconciliation Report</h4>
                  <p className="font-sans text-[11px] text-slate-500 mt-1 leading-relaxed">
                    {challanStats.unmatched > 0 || challanStats.unpaid > 0 ? (
                      <span className="text-amber-600 font-medium">
                        Alert: You have {challanStats.unmatched + challanStats.unpaid} unresolved liabilities. Ensure unmatched OLTAS challans are re-linked prior to return filing for {selectedQuarter === 'All' ? 'any quarter' : selectedQuarter} to prevent Section 234E late interest charges.
                      </span>
                    ) : (
                      <span className="text-emerald-600 font-medium">
                        Excellent: All challans in this workspace are mathematically balanced and validated against the Income Tax Department's direct records!
                      </span>
                    )}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-sans">
            <span className="text-slate-400">Total processed lines: <strong className="text-slate-600">{filteredRecords.length}</strong></span>
            <span className="text-indigo-600 hover:text-indigo-700 font-medium flex items-center cursor-pointer">
              View Return Details <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </span>
          </div>
        </div>
      </div>

      {/* Dynamic Filing Period & Future Rollover Console */}
      <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-500">
              <Compass className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <span className="font-mono text-[9px] uppercase tracking-widest text-indigo-600 font-bold">compliance timeline sandbox</span>
              <h3 className="font-sans font-bold text-slate-800 text-sm">Filing Period Rollovers & Future Forecasting</h3>
            </div>
          </div>

          {/* Simulate rollover controls */}
          <div className="flex items-center space-x-2">
            <span className="font-sans text-[10px] text-slate-450 text-slate-400 font-semibold uppercase">Simulated Date: June {simulatedYear}</span>
            <button
              onClick={() => {
                if (setSimulatedYear) {
                  setSimulatedYear(prev => {
                    const next = prev + 1;
                    // Automatically switch to the new dynamic natural year as the default activePeriod
                    const nextEndYear = (next + 1) % 100;
                    const endPadded = nextEndYear < 10 ? '0' + nextEndYear : '' + nextEndYear;
                    const nextFy = `${next}-${endPadded}`;
                    if (setActivePeriod) setActivePeriod(nextFy);
                    return next;
                  });
                }
              }}
              className="flex items-center space-x-1.5 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-sans text-xs font-bold px-3 py-1.5 rounded-xl transition shadow-sm cursor-pointer hover:shadow-md hover:scale-102 active:scale-95 duration-200"
              title="Simulate Year-End Rollover to next Fiscal Year"
            >
              <RefreshCw className="w-3 h-3 animate-spin text-white" />
              <span>Simulate Year End / Rollover</span>
            </button>
          </div>
        </div>

        <p className="font-sans text-xs text-slate-500 leading-relaxed text-justify">
          The Indian Financial Year (FY) rolls over every March 31st. This compliance dashboard is fully future-ready and dynamically shifts with calendar transitions. Below, manage and monitor filing portals for subsequent accounting epochs. You can seed mock validation data for future fiscal years to verify multi-period reporting structures automatically.
        </p>

        {/* Dynamic List Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {periodsList.slice(0, 6).map(fy => {
            const startYear = parseInt(fy.split('-')[0], 10);
            const ayYear = startYear + 1;
            const ayEnd = (ayYear + 1) % 100;
            const ayStr = `${ayYear}-${ayEnd < 10 ? '0' + ayEnd : ayEnd}`;
            const isSelected = activePeriod === fy;
            
            return (
              <div
                key={fy}
                className={`p-4 rounded-2xl border transition duration-200 flex flex-col justify-between ${
                  isSelected 
                  ? 'bg-indigo-50/40 border-indigo-200 shadow-xs' 
                  : 'bg-slate-50/50 border-slate-100 hover:bg-slate-50 hover:border-slate-200'
                }`}
              >
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-sans font-extrabold text-xs text-slate-800">FY {fy}</span>
                    {isSelected && (
                      <span className="bg-indigo-600 text-white font-mono text-[9px] uppercase tracking-wide px-2 py-0.5 rounded font-extrabold">
                        ACTIVE
                      </span>
                    )}
                  </div>
                  <span className="block font-mono text-[10px] text-slate-450 text-slate-400">Assessment Year: AY {ayStr}</span>
                  <p className="font-sans text-[10px] text-slate-500 mt-1.5 leading-relaxed">
                    Compliance status: {startYear > 2026 ? "⚠️ Future Aspect Draft" : "✓ Active Period"}
                  </p>
                </div>

                <div className="flex items-center space-x-2 mt-4 pt-3 border-t border-slate-100/60 font-sans">
                  <button
                    onClick={() => setActivePeriod && setActivePeriod(fy)}
                    disabled={isSelected}
                    className={`flex-1 text-[10px] font-sans font-bold py-1 px-2 rounded-lg text-center transition cursor-pointer ${
                      isSelected 
                      ? 'bg-slate-200/55 text-slate-400 cursor-not-allowed'
                      : 'bg-white hover:bg-indigo-50 text-indigo-600 border border-indigo-100'
                    }`}
                  >
                    Select FY
                  </button>
                  <button
                    onClick={() => onSeedPeriodData && onSeedPeriodData(fy)}
                    className="flex-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-[10px] font-sans font-bold py-1 px-2 rounded-lg text-center transition border border-indigo-100 cursor-pointer"
                    title="Seed standard compliance seed records"
                  >
                    Seed Data
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
