/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  BookOpen, 
  Layers, 
  HelpCircle, 
  Scale, 
  Calculator, 
  ChevronRight, 
  Quote, 
  ExternalLink,
  MessageSquareDiff,
  Award,
  BookmarkCheck,
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { TDS_SECTIONS_DATA, OLD_VS_NEW_SCHEME, RECENT_CIRCULARS, RELEVANT_CASE_LAWS } from '../data/tdsLibrary';

const FALLBACK_UPDATES = [
  {
    title: "NSDL releases FVU Version 8.6 for e-TDS Statement Validation",
    date: "June 2026",
    category: "System Update",
    snippet: "The Income Tax Department and NSDL have released a new version of the File Validation Utility (FVU v8.6) today. This utility has strict validation rules for Q1 filings and ensures clean processing of TDS on virtual digital assets (VDA) under Sec 194S.",
    fullText: "The NSDL File Validation Utility (FVU) has been updated to version 8.6, enabling enhanced validation checks for quarterly TDS/TCS statement uploads. Users of TRACES suite are advised to validate files using only the latest FVU tool to avoid parsing rejections. Major additions include robust checks for PAN-Aadhaar linkage mismatch and lower deduction rate validation under certificate Section 197."
  },
  {
    title: "Aadhaar-PAN Linking Grace Extension under Section 139AA",
    date: "May 2026",
    category: "Circular Alert",
    snippet: "In a massive relief to individual tax payees, the Central Board of Direct Taxes (CBDT) has issued circular 10/2026, extending compliance leniencies for unlinked PANs to prevent high-rate 20% double-taxation under Sec 206AA.",
    fullText: "In accordance with Circular No. 10/2026, the CBDT has announced that no penal higher rate of TDS (under Section 206AA) will be triggered for unlinked PANs provided the deductee completes the linking procedure before the specified extended date. This provides substantial relief to employers deducting TDS under Section 192 (salary) who were previously facing non-compliance queries."
  },
  {
    title: "Finance Act 2025 Standard Deduction Options and Slab Adjustments",
    date: "April 2026",
    category: "Statutory Law",
    snippet: "The statutory provisions of the Finance Act 2025 are now active. Note that the default tax regime under Section 115BAC now boasts an elevated standard deduction of ₹75,000 for salaried employees, compared to ₹50,0050 in the old regime.",
    fullText: "The Union Budget adjustments have elevated the default new tax regime standard deduction limit from ₹50,000 to ₹75,000, while the old regime remains at ₹50,000. Under Section 115BAC, salary slabs have been further optimized to deliver maximum tax savings for middle-income employees. Tax calculators and reports in the TRACES suite are updated with these exact rules."
  }
];

interface LibraryViewProps {
  onlineData?: {
    thought: string;
    refreshment: string;
    announcements: string[];
    detailedUpdates: any[];
  } | null;
  isSyncingUpdates?: boolean;
  lastSyncedTime?: string;
  onSyncUpdates?: () => void;
}

export default function LibraryView({
  onlineData,
  isSyncingUpdates,
  lastSyncedTime,
  onSyncUpdates
}: LibraryViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<'updates' | 'rates' | 'calculator' | 'circulars' | 'caselaws'>('updates');
  const [searchSection, setSearchSection] = useState('');
  
  // Tax Slab Comparison Calculator states
  const [calcSalarySum, setCalcSalarySum] = useState<number>(1200000);
  const [calculatedRef, setCalculatedRef] = useState<{
    taxOld: number;
    taxNew: number;
    savings: number;
    recommended: string;
  } | null>(null);

  // Filter sections
  const filteredSections = TDS_SECTIONS_DATA.filter(sec => {
    return sec.section.toLowerCase().includes(searchSection) || 
           sec.title.toLowerCase().includes(searchSection.toLowerCase()) ||
           sec.provisions.toLowerCase().includes(searchSection.toLowerCase());
  });

  // Calculate tax math for Old vs New Regime
  const handleCalcTaxRegimes = () => {
    const baseIncome = Number(calcSalarySum) || 0;
    if (baseIncome <= 0) return;

    // 1. Math for Old Regime
    // Exempted deduction limit: 50,0050. Net taxable for old:
    const oldDeduction = OLD_VS_NEW_SCHEME.standardDeduction.old;
    const oldNet = Math.max(0, baseIncome - oldDeduction);
    let taxOld = 0;
    
    let tempOldNet = oldNet;
    const oldSlabs = OLD_VS_NEW_SCHEME.slabs.old;
    
    // Slab math calculation loop
    for (let i = 0; i < oldSlabs.length; i++) {
      const slab = oldSlabs[i];
      const prevMax = i === 0 ? 0 : oldSlabs[i-1].max;
      if (oldNet > prevMax) {
        const taxableInThisSlab = Math.min(slab.max - prevMax, oldNet - prevMax);
        taxOld += (taxableInThisSlab * slab.rate) / 100;
      }
    }

    // 87A rebate old regime (up to 5L net income rebate)
    if (oldNet <= 500000 && taxOld > 0) {
      taxOld = 0; // Rebate deletes tax liability
    }

    // Add 4% cess to old tax
    if (taxOld > 0) taxOld = taxOld * 1.04;

    // 2. Math for New Regime
    // Exemption limit: 75,000 standard deduction updated inside our dataset
    const newDeduction = OLD_VS_NEW_SCHEME.standardDeduction.new;
    const newNet = Math.max(0, baseIncome - newDeduction);
    let taxNew = 0;
    
    const newSlabs = OLD_VS_NEW_SCHEME.slabs.new;
    for (let i = 0; i < newSlabs.length; i++) {
      const slab = newSlabs[i];
      const prevMax = i === 0 ? 0 : newSlabs[i-1].max;
      if (newNet > prevMax) {
        const taxableInThisSlab = Math.min(slab.max - prevMax, newNet - prevMax);
        taxNew += (taxableInThisSlab * slab.rate) / 100;
      }
    }

    // 87A rebate new regime (up to 7L net income rebate)
    if (newNet <= 700000 && taxNew > 0) {
      taxNew = 0; // Rebate deletes tax liability
    }

    // Add 4% cess to new tax
    if (taxNew > 0) taxNew = taxNew * 1.04;

    const savings = Math.abs(taxOld - taxNew);
    const recommended = taxNew < taxOld 
      ? 'New Regime (Default 115BAC)' 
      : (taxOld < taxNew ? 'Old Regime (with exemptions)' : 'Dual Regime Mapped');

    setCalculatedRef({
      taxOld,
      taxNew,
      savings,
      recommended
    });
  };

  const formattingRupee = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(value);
  };

  return (
    <div id="library-view" className="space-y-8 animate-fadeIn">
      {/* Visual Header */}
      <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="font-mono text-xs uppercase tracking-wider text-indigo-500 font-bold">Indian Income Tax Code</span>
          <h2 className="font-sans font-bold text-xl text-slate-800 tracking-tight flex items-center mt-0.5">
            <BookOpen className="w-5.5 h-5.5 text-indigo-500 mr-2" />
            TDS / TCS Provisions Library 1961 & 2025
          </h2>
          <p className="font-sans text-xs text-slate-400 mt-0.5">
            Fully updated to reflect latest <strong className="text-slate-600">Union Budget structural rates, sections and circular rulings</strong>.
          </p>
        </div>

        {/* Small badge layout */}
        <span className="font-mono text-[10px] bg-indigo-50/70 border border-indigo-100 text-indigo-700 px-3 py-1.5 rounded-xl font-bold uppercase tracking-wider">
          Act Version: Finance Bill 2025 Act
        </span>
      </div>

      {/* Sub tabs line */}
      <div className="border-b border-slate-200">
        <div className="flex flex-wrap gap-4 -mb-px">
          {[
            { id: 'updates', label: 'Income Tax Updates', icon: Sparkles },
            { id: 'rates', label: 'Provisions Explorer', icon: Layers },
            { id: 'calculator', label: 'TDS Slab Comparison Math', icon: Calculator },
            { id: 'circulars', label: 'Circulars & notifications', icon: HelpCircle },
            { id: 'caselaws', label: 'Supreme Court Case Laws', icon: Scale },
          ].map(tab => {
            const Icon = tab.icon;
            const isSel = activeSubTab === tab.id;
            return (
              <button
                id={`subtab-btn-${tab.id}`}
                key={tab.id}
                onClick={() => {
                  setActiveSubTab(tab.id as any);
                  if (tab.id === 'calculator' && !calculatedRef) {
                    // pre-load math
                    setTimeout(() => handleCalcTaxRegimes(), 10);
                  }
                }}
                className={`py-3.5 px-4 font-sans text-xs font-semibold flex items-center space-x-2 border-b-2 transition duration-250 ${
                  isSel 
                    ? 'border-indigo-600 text-indigo-600' 
                    : 'border-transparent text-slate-400 hover:text-slate-850 hover:border-slate-350'
                }`}
              >
                <Icon className="w-4.5 h-4.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Dynamic Content Panels based on Sub tab selection */}
      <div className="mt-6">

        {/* Tab 0: Income Tax updates */}
        {activeSubTab === 'updates' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center bg-gradient-to-r from-indigo-50 to-indigo-100/40 p-5 border border-indigo-150 rounded-2xl animate-pulse-subtle">
              <div>
                <h3 className="font-sans font-bold text-indigo-950 text-sm flex items-center">
                  <Sparkles className="w-4.5 h-4.5 mr-2 text-indigo-600" />
                  Live Compliance Updates Feed
                </h3>
                <p className="font-sans text-xs text-indigo-800/80 mt-0.5">
                  Synchronized with Income Tax Department e-filing news & Gemini AI insights.
                </p>
              </div>

              {onSyncUpdates && (
                <button
                  onClick={onSyncUpdates}
                  disabled={isSyncingUpdates}
                  className="flex items-center space-x-1.5 bg-white text-indigo-600 border border-indigo-200 hover:bg-indigo-50 active:scale-95 transition px-3.5 py-2 rounded-xl text-xs font-sans font-bold shadow-xs cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncingUpdates ? 'animate-spin' : ''}`} />
                  <span>{isSyncingUpdates ? 'Syncing...' : 'Sync Updates'}</span>
                </button>
              )}
            </div>

            {lastSyncedTime && (
              <p className="font-mono text-[9px] text-indigo-600 text-left -mt-4 pl-1">
                LAST COMPLIANCE SYNC SECURE: <strong>{lastSyncedTime}</strong>
              </p>
            )}

            <div className="grid grid-cols-1 gap-6">
              {(onlineData?.detailedUpdates || FALLBACK_UPDATES).map((article: any, idx: number) => (
                <div key={idx} className="bg-white border border-slate-100 p-6 rounded-3xl space-y-4 hover:border-indigo-100/65 hover:shadow-2xs transition">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase tracking-wider font-bold bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded">
                      {article.category || 'Compliance alert'}
                    </span>
                    <span className="font-mono text-[10px] text-slate-400 font-medium">
                      {article.date || 'Live update'}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-sans font-extrabold text-slate-800 text-sm">
                      {article.title}
                    </h3>
                    <p className="font-sans text-slate-500 text-xs leading-relaxed mt-2 text-justify">
                      {article.snippet}
                    </p>
                  </div>
                  <div className="bg-slate-50 border border-slate-100/50 p-4 rounded-xl text-xs text-slate-500 font-sans leading-relaxed text-justify">
                    {article.fullText}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Tab 1: Provisions Explorer */}
        {activeSubTab === 'rates' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-white border border-slate-100 rounded-2xl shadow-3xs">
              <div>
                <h3 className="font-sans font-bold text-slate-800 text-sm">Interactive TDS/TCS Rates Table</h3>
                <p className="font-sans text-xs text-slate-400 mt-0.5">Filter by section numbers (e.g. 194), description keywords, or form numbers</p>
              </div>
              <input
                id="lib-search-input"
                type="text"
                placeholder="Search TDS sections / titles..."
                value={searchSection}
                onChange={(e) => setSearchSection(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-1.5 text-xs text-slate-700 w-full sm:w-64 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredSections.map(sec => (
                <div key={sec.section} className="p-6 bg-white border border-slate-100 rounded-3xl hover:shadow-xs transition flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between pb-3.5 border-b border-slate-100 mb-4">
                      <div>
                        <span className="font-sans text-[10px] bg-slate-100 text-slate-655 text-slate-600 px-2.5 py-0.5 rounded font-bold uppercase">Form {sec.formType}</span>
                        <h4 className="font-sans font-extrabold text-slate-800 text-sm mt-1">Section {sec.section}: {sec.title}</h4>
                      </div>
                      <span className="font-mono text-[10px] bg-indigo-50 text-indigo-700 font-bold px-2.5 py-1 rounded">Sec {sec.section}</span>
                    </div>
                    
                    <p className="font-sans text-xs text-slate-500 leading-relaxed font-light mb-4">{sec.provisions}</p>

                    <div className="grid grid-cols-3 gap-2 text-xs py-3.5 bg-slate-50/50 rounded-2xl px-4">
                      <div>
                        <span className="block text-[9px] uppercase tracking-wider text-slate-400 font-semibold mb-0.5">Threshold</span>
                        <span className="font-mono font-bold text-slate-800">{sec.threshold > 0 ? formattingRupee(sec.threshold) : 'NIL'}</span>
                      </div>
                      <div>
                        <span className="block text-[9px] uppercase tracking-wider text-slate-400 font-semibold mb-0.5">Indiv/HUF Rate</span>
                        <span className="font-mono font-bold text-slate-800">{sec.rateInd > 0 ? `${sec.rateInd}%` : 'Slab Rate'}</span>
                      </div>
                      <div>
                        <span className="block text-[9px] uppercase tracking-wider text-slate-400 font-semibold mb-0.5">Corporate Rate</span>
                        <span className="font-mono font-bold text-slate-800">{sec.rateCo > 0 ? `${sec.rateCo}%` : 'Slab Rate'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3.5 border-t border-slate-50 flex items-center justify-between text-[11px] text-slate-400 font-sans">
                    <span>Category: <strong className="text-slate-600">{sec.category}</strong></span>
                    <button 
                      id={`inspect-rules-btn-${sec.section}`}
                      className="text-indigo-600 font-medium flex items-center hover:text-indigo-700"
                      onClick={() => alert(`Rules details for Section ${sec.section}:\nDeduction must happen at the time of credit or payment, whichever is earlier. Failures invoke Section 201(1A) 1%/1.5% interest rates.`)}
                    >
                      Audit Rules <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: Tax Slab Comparison Calculator */}
        {activeSubTab === 'calculator' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Input form panel card */}
            <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs flex flex-col justify-between h-fit">
              <div className="space-y-4">
                <h3 className="font-sans font-bold text-slate-855 text-slate-850 text-sm">Income Tax Slab calculator</h3>
                <p className="font-sans text-xs text-slate-400 leading-relaxed font-light">
                  Input estimated annual taxable CTC to compute tax difference under Old vs New exemption regimes for FY 22025-26.
                </p>

                <div>
                  <label className="font-sans text-[10px] text-slate-400 font-bold uppercase block mb-1">Annual Taxable CTC (INR)</label>
                  <input
                    id="calc-salary-input"
                    type="number"
                    value={calcSalarySum}
                    onChange={(e) => setCalcSalarySum(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-205 border-slate-200 rounded-xl px-4 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-750 font-mono font-bold"
                  />
                </div>

                <div className="bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100">
                  <h4 className="font-sans font-semibold text-xs text-indigo-850 mb-1 flex items-center">
                    <Award className="w-4 h-4 mr-1 text-indigo-650" /> FY 2025-26 Budget Update
                  </h4>
                  <ul className="list-disc pl-4 space-y-1 text-[11px] text-indigo-700 leading-relaxed">
                    <li>New regime deduction increased to ₹75,000</li>
                    <li>Slabs relaxed; zero tax liability up to ₹4,00,000 net</li>
                    <li>Surcharge and 4% standard education cess are active</li>
                  </ul>
                </div>
              </div>

              <button
                id="calculate-tax-btn"
                onClick={handleCalcTaxRegimes}
                className="w-full mt-6 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 active:scale-95 transition text-white text-xs font-bold font-sans py-2.5 rounded-xl uppercase tracking-wider shadow-md shadow-indigo-600/10"
              >
                Compute Comparative Regimes
              </button>
            </div>

            {/* Results comparative panels */}
            {calculatedRef && (
              <div className="lg:col-span-2 space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {/* Old Regime Card */}
                  <div className="p-6 bg-white border border-slate-100/80 rounded-3xl relative">
                    <span className="font-sans text-[10px] uppercase font-bold text-slate-450 block">Old Tax Regime</span>
                    <h4 className="font-sans font-extrabold text-sm text-slate-700 mt-1">Section 115BAC (Opt-out)</h4>
                    
                    <div className="my-5">
                      <span className="block text-[10px] text-slate-400">Total Regime Tax (with Cess)</span>
                      <span className="font-mono text-xl font-bold text-slate-800 tracking-tight block mt-1">
                        {formattingRupee(calculatedRef.taxOld)}
                      </span>
                    </div>

                    <div className="bg-slate-50 rounded-xl p-3 text-[10px] text-slate-500 font-mono flex justify-between">
                      <span>Standard Exemption:</span>
                      <strong className="text-slate-700">₹{OLD_VS_NEW_SCHEME.standardDeduction.old.toLocaleString('en-IN')}</strong>
                    </div>
                  </div>

                  {/* New Regime Card */}
                  <div className="p-6 bg-indigo-950 text-white rounded-3xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-3 bg-indigo-500/10 text-cyan-400 rounded-bl-xl font-sans text-[9px] uppercase tracking-wider font-bold">
                      Default Scheme
                    </div>
                    
                    <span className="font-sans text-[10px] uppercase font-semibold text-indigo-300 block">Revised New tax regime</span>
                    <h4 className="font-sans font-extrabold text-xs text-white mt-1">Finance Act 2025 update</h4>
                    
                    <div className="my-5">
                      <span className="block text-[10px] text-indigo-300">Total Regime Tax (with Cess)</span>
                      <span className="font-mono text-xl font-bold text-cyan-300 tracking-tight block mt-1">
                        {formattingRupee(calculatedRef.taxNew)}
                      </span>
                    </div>

                    <div className="bg-indigo-900/40 rounded-xl p-3 text-[10px] text-indigo-200 font-mono flex justify-between">
                      <span>Standard Exemption:</span>
                      <strong className="text-white">₹{OLD_VS_NEW_SCHEME.standardDeduction.new.toLocaleString('en-IN')}</strong>
                    </div>
                  </div>
                </div>

                {/* Savings and Recommendations Bar */}
                <div className="p-6 bg-slate-900 text-white rounded-3xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <span className="font-mono text-[9px] uppercase tracking-widest text-indigo-400">Analytical Recommendation</span>
                    <h4 className="font-sans font-bold text-sm">Recommended Regime: <strong className="text-cyan-400">{calculatedRef.recommended}</strong></h4>
                    <p className="font-sans text-[11px] text-slate-400 leading-relaxed font-light">
                      The default New Tax Regime provides a lower tax liability for individual deductions of this specific size.
                    </p>
                  </div>
                  {calculatedRef.savings > 0 && (
                    <div className="bg-indigo-950 border border-indigo-800 p-4 rounded-2xl flex-shrink-0 text-center">
                      <span className="text-[9px] uppercase text-indigo-300 block font-semibold">Regime Tax Savings</span>
                      <span className="font-mono text-lg font-bold text-emerald-400 block mt-1">{formattingRupee(calculatedRef.savings)}</span>
                    </div>
                  )}
                </div>

                {/* Extra advice tips list */}
                <div className="bg-white border border-slate-100 rounded-3xl p-6">
                  <h4 className="font-sans font-bold text-slate-800 text-xs uppercase mb-3 tracking-wider">Expert Advice regarding slabs</h4>
                  <ul className="space-y-2">
                    {OLD_VS_NEW_SCHEME.tips.map((tip, idx) => (
                      <li key={idx} className="flex items-start space-x-2 text-xs text-slate-500 font-sans leading-relaxed">
                        <span className="font-bold text-indigo-500 mr-1 mt-0.5">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Circulars */}
        {activeSubTab === 'circulars' && (
          <div className="space-y-6">
            <h3 className="font-sans font-bold text-slate-800 text-sm">Official TRACES Circular Notifications</h3>
            <div className="space-y-4">
              {RECENT_CIRCULARS.map(cir => (
                <div key={cir.id} className="p-6 bg-white border border-slate-100 rounded-3xl hover:border-indigo-150 transition self-stretch">
                  <div className="flex items-center justify-between border-b border-slate-50 pb-3.5 mb-4">
                    <div className="flex items-center space-x-2.5">
                      <BookmarkCheck className="w-5 h-5 text-indigo-500" />
                      <h4 className="font-sans font-bold text-slate-800 text-xs sm:text-sm">{cir.title}</h4>
                    </div>
                    <span className="font-mono text-[10px] text-slate-450">{cir.date}</span>
                  </div>
                  <h5 className="font-sans font-semibold text-xs text-slate-700 tracking-tight uppercase">{cir.subject}</h5>
                  <p className="font-sans text-xs text-slate-500 mt-2 leading-relaxed font-light">{cir.summary}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 4: Case Laws */}
        {activeSubTab === 'caselaws' && (
          <div className="space-y-6">
            <h3 className="font-sans font-bold text-slate-800 text-sm">Key Direct Tax Judgments</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {RELEVANT_CASE_LAWS.map(caseLaw => (
                <div key={caseLaw.id} className="p-6 bg-white border border-slate-100 rounded-3xl hover:shadow-2xs transition flex flex-col justify-between">
                  <div className="space-y-4">
                    <Quote className="w-8 h-8 text-indigo-400 opacity-20" />
                    <h4 className="font-sans font-extrabold text-sm text-slate-800 tracking-tight leading-snug">
                      {caseLaw.citation}
                    </h4>
                    <p className="font-sans text-[11px] uppercase tracking-wider text-indigo-650 font-bold">Subject: {caseLaw.subject}</p>
                    <p className="font-sans text-xs text-slate-500 leading-relaxed font-light italic bg-slate-50 p-4 rounded-2xl border border-slate-100">
                      &ldquo;{caseLaw.summary}&rdquo;
                    </p>
                  </div>
                  <div className="mt-5 pt-3 border-t border-slate-50 text-right">
                    <span className="text-[10px] text-slate-400 font-mono">Mapped in TDS return guidance</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
