/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { 
  Printer, 
  Trash2, 
  Download, 
  AlertTriangle, 
  FileText, 
  Archive, 
  CheckCircle,
  HelpCircle
} from 'lucide-react';
import { UploadedFile } from '../types';

interface OldClientViewProps {
  backup: {
    name: string;
    content: string;
    timestamp: string;
  } | null;
  onClearBackup: () => void;
  onArchiveToDocuments: (file: UploadedFile) => void;
}

export default function OldClientView({ backup, onClearBackup, onArchiveToDocuments }: OldClientViewProps) {
  const printAreaRef = useRef<HTMLDivElement>(null);
  const [showOldClientPrintGuide, setShowOldClientPrintGuide] = useState<boolean>(false);

  if (!backup) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] p-8 text-center bg-slate-50 border border-dashed border-slate-200 rounded-3xl">
        <Archive className="w-12 h-12 text-slate-300 mx-auto" />
        <h3 className="font-sans font-bold text-slate-700 mt-4 text-sm">No Old Client backup found</h3>
        <p className="font-sans text-slate-400 text-xs mt-1.5 max-w-sm mx-auto leading-relaxed">
          There are no temporary backups stored currently. Old client files are automatically cached here when you overwrite active data by uploading fresh statement sets in the Document Locker.
        </p>
      </div>
    );
  }

  // Handle printing
  const handlePrint = () => {
    try {
      window.focus();
      window.print();
      
      // If we are inside an iframe, native browser print is typically blocked;
      // show guidance rather than immediately deleting so they don't lose raw data!
      if (window.self !== window.top) {
        setShowOldClientPrintGuide(true);
        return;
      }
    } catch (e) {
      console.warn("Direct browser print restricted by sandbox iframe policy:", e);
      setShowOldClientPrintGuide(true);
      return;
    }

    archiveAndTriggerSuccess();
  };

  const archiveAndTriggerSuccess = () => {
    const fileSize = `${(backup.content.length / 1024).toFixed(2)} KB`;
    const currentTime = new Date().toISOString().replace('T', ' ').substring(0, 16);
    
    // Extract first client name or fallback
    let clientName = "Archived Client";
    const nameMatch = backup.content.match(/Client Name\s*:\s*(.+)/i);
    if (nameMatch && nameMatch[1]) {
      clientName = nameMatch[1].trim();
    }

    const archivedFile: UploadedFile = {
      id: `archived_txt_${Date.now()}`,
      name: backup.name,
      type: 'FVU',
      size: fileSize,
      uploadedAt: currentTime,
      status: 'Completed',
      recordCount: 1, // Compiled txt report
      extractedCompany: {
        companyName: clientName
      }
    };

    // Callback to App state to register this in document list, and clear old backup tab
    onArchiveToDocuments(archivedFile);
    alert("Printing process initiated! The temporary backup has been successfully filed as a permanent text log inside the 'Document Locker'.");
  };

  // Raw file downloading support
  const handleDownloadTxt = () => {
    const element = document.createElement("a");
    const file = new Blob([backup.content], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = backup.name;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div id="old-client-view" className="space-y-6 animate-fadeIn">
      {/* Alert Warning Box */}
      <div className="bg-amber-50 border border-amber-200/60 rounded-3xl p-5 md:p-6 flex items-start space-x-3.5">
        <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0 animate-pulse" />
        <div className="space-y-1">
          <h4 className="font-sans font-bold text-amber-800 text-xs uppercase tracking-wide">Pending Old Client Workspace Backup</h4>
          <p className="font-sans text-amber-700/95 text-xs leading-relaxed max-w-4xl">
            This repository contains the full transactions text files of the previous client overwritten during your latest NSDL statement upload. 
            Before continuing, please <strong>review</strong> or <strong>print the transaction certificate</strong> below. Once printing is complete, the 
            temporary active status will be wiped from this menu and filed into your global <strong>Document Locker</strong> as a permanent <code>.txt</code> log asset.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* Actions Cards */}
        <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs space-y-6">
          <div className="space-y-3">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-lg bg-teal-50 text-teal-600 flex items-center justify-center">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-sans font-bold text-slate-800 text-xs uppercase tracking-wider">Archive Details</h3>
                <span className="font-mono text-[9px] text-slate-400">STATUS: LOCKED</span>
              </div>
            </div>
            <div className="pt-3 border-t border-slate-50 space-y-2 text-xs">
              <div>
                <span className="block text-[10px] text-slate-400">File Name</span>
                <strong className="block font-mono text-[11px] text-slate-700 break-all">{backup.name}</strong>
              </div>
              <div>
                <span className="block text-[10px] text-slate-400">Backup Date</span>
                <strong className="block text-slate-700 font-sans">{new Date(backup.timestamp).toLocaleString('en-IN')}</strong>
              </div>
              <div>
                <span className="block text-[10px] text-slate-400">Storage Size</span>
                <strong className="block font-mono text-[11px] text-slate-700">{(backup.content.length / 1024).toFixed(2)} KB</strong>
              </div>
            </div>
          </div>

          <div className="space-y-2.5 pt-4 border-t border-slate-100">
            <button
              id="print-old-client-btn"
              onClick={handlePrint}
              className="w-full flex items-center justify-center space-x-2 bg-teal-650 hover:bg-teal-700 active:scale-95 transition text-white text-xs font-bold font-sans py-3 rounded-xl uppercase tracking-wider shadow-lg shadow-teal-900/10 cursor-pointer"
            >
              <Printer className="w-4 h-4 text-emerald-300" />
              <span>Print and Archive File</span>
            </button>

            <button
              id="download-old-client-btn"
              onClick={handleDownloadTxt}
              className="w-full flex items-center justify-center space-x-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-bold font-sans py-2.5 rounded-xl uppercase tracking-wider active:scale-95 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Raw TXT</span>
            </button>

            <button
              id="discard-old-client-btn"
              onClick={() => {
                if (window.confirm("Are you absolutely sure you want to discard this temporary backup permanently without archiving it to the Document Locker?")) {
                  onClearBackup();
                }
              }}
              className="w-full flex items-center justify-center space-x-1.5 text-xs text-rose-600 hover:text-rose-700 font-bold font-sans hover:bg-rose-50/50 py-2 rounded-lg transition text-center"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Wipe Backup Cache</span>
            </button>

            {showOldClientPrintGuide && (
              <div className="p-4 bg-teal-50/80 border border-teal-150 rounded-2xl space-y-3 mt-4 text-left text-slate-850 animate-fadeIn">
                <p className="font-sans text-[11px] text-teal-800 leading-relaxed font-semibold">
                  Iframe print warning detected:
                </p>
                <p className="font-sans text-[11px] text-slate-600 leading-relaxed font-light">
                  Direct browser print is blocked by local iframe sandbox restrictions. Use these robust options:
                </p>
                <div className="grid grid-cols-1 gap-2 pt-1 font-sans">
                  <a
                    href={window.location.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex flex-col justify-center items-center text-center p-2.5 border border-teal-200 bg-white hover:bg-teal-50/50 rounded-xl transition cursor-pointer"
                  >
                    <span className="font-bold text-[10px] text-teal-700">1. Open App in New Tab</span>
                    <span className="text-[8px] text-slate-500 mt-0.5">Supports standard browser printing</span>
                  </a>
                  <button
                    onClick={() => {
                      handleDownloadTxt();
                      archiveAndTriggerSuccess();
                    }}
                    className="flex flex-col justify-center items-center text-center p-2.5 border border-teal-200 bg-teal-600 hover:bg-teal-700 text-white rounded-xl transition cursor-pointer"
                  >
                    <span className="font-bold text-[10px]">2. Direct Archive & Download</span>
                    <span className="text-[8px] text-teal-150 mt-0.5">Files backup to locker instantly</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Text Review Box Container */}
        <div className="lg:col-span-3 bg-slate-950 text-slate-205 border border-slate-800 rounded-3xl p-6 shadow-xl flex flex-col">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
              <span className="font-mono text-xs text-slate-400 uppercase tracking-widest">Cached Client Statement Log Viewer</span>
            </div>
            <span className="font-mono text-[10px] text-indigo-400">RO-MODE (ASCII ENCODING)</span>
          </div>

          {/* TXT content area */}
          <div 
            ref={printAreaRef}
            id="printable-old-client-card"
            className="font-mono text-xs text-slate-300 whitespace-pre overflow-x-auto overflow-y-auto max-h-[500px] leading-relaxed select-all selection:bg-indigo-650 selection:text-white bg-slate-900 border border-slate-800 rounded-xl p-5 select-text print:bg-white print:text-black print:border-none print:p-0 print:overflow-visible print:max-h-none print:whitespace-pre-wrap selection-background"
          >
            {backup.content}
          </div>

          <div className="mt-4 flex items-center space-x-2 text-[10px] text-slate-500 font-sans">
            <HelpCircle className="w-3.5 h-3.5 text-slate-600" />
            <span>Select rules: double click or press Ctrl+A inside the dark box to select all text for copy-pasting to compliance utilities if required.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
