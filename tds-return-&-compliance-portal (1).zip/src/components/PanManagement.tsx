/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Users, 
  Search, 
  Fingerprint, 
  CheckCircle, 
  TrendingUp, 
  ClipboardCheck, 
  UserPlus, 
  Activity,
  History,
  Clock,
  Briefcase
} from 'lucide-react';
import { TdsRecord, VerificationLog } from '../types';

interface PanManagementProps {
  records: TdsRecord[];
  onAddNewPanRecord: (pan: string, name: string, active: boolean, aadhaar: boolean) => void;
}

export default function PanManagement({ records, onAddNewPanRecord }: PanManagementProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPanId, setSelectedPanId] = useState<string>('');
  
  // PAN verification form fields
  const [inputPan, setInputPan] = useState('');
  const [inputName, setInputName] = useState('');
  const [isVerifyingState, setIsVerifyingState] = useState(false);
  const [verificationHistory, setVerificationHistory] = useState<VerificationLog[]>([]);

  // Extract unique PANs list and aggregate their stats
  const panRegistry = useMemo(() => {
    const pans: { 
      [key: string]: { 
        name: string; 
        status: string; 
        aadhaarLinked: boolean; 
        recordsCount: number; 
        totalAmount: number;
        totalTds: number;
        quarterBreakdown: { Q1: number; Q2: number; Q3: number; Q4: number };
        monthBreakdown: { [key: string]: number };
      } 
    } = {};

    records.forEach(r => {
      if (!pans[r.pan]) {
        pans[r.pan] = {
          name: r.deducteeName,
          status: r.panStatus,
          aadhaarLinked: r.aadhaarLinked,
          recordsCount: 0,
          totalAmount: 0,
          totalTds: 0,
          quarterBreakdown: { Q1: 0, Q2: 0, Q3: 0, Q4: 0 },
          monthBreakdown: {}
        };
      }

      const p = pans[r.pan];
      p.recordsCount += 1;
      p.totalAmount += r.amount;
      p.totalTds += r.tdsAmount;
      p.quarterBreakdown[r.quarter] += r.tdsAmount;

      // Extract month name from date "YYYY-MM-DD"
      if (r.date) {
        const parts = r.date.split('-');
        if (parts.length > 1) {
          const monthNum = parts[1];
          const monthNames: { [key: string]: string } = {
            '01': 'Jan', '02': 'Feb', '03': 'Mar', '04': 'Apr', '05': 'May', '06': 'Jun',
            '07': 'Jul', '08': 'Aug', '09': 'Sep', '10': 'Oct', '11': 'Nov', '12': 'Dec'
          };
          const mName = monthNames[monthNum] || 'Other';
          p.monthBreakdown[mName] = (p.monthBreakdown[mName] || 0) + r.tdsAmount;
        }
      }
    });

    return Object.keys(pans).map(key => ({
      pan: key,
      ...pans[key]
    }));
  }, [records]);

  // Filter PANs based on search
  const filteredPans = useMemo(() => {
    return panRegistry.filter(p => {
      return p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.pan.toLowerCase().includes(searchQuery.toLowerCase());
    });
  }, [panRegistry, searchQuery]);

  // Automatically select the first PAN if none selected
  const activePan = useMemo(() => {
    if (!selectedPanId && filteredPans.length > 0) {
      return filteredPans[0];
    }
    return filteredPans.find(p => p.pan === selectedPanId) || filteredPans[0] || null;
  }, [filteredPans, selectedPanId]);

  // Handle Verify Form submit
  const handleVerifyPanSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputPan.trim() || !inputName.trim()) return;

    const cleanPan = inputPan.trim().toUpperCase();
    const cleanName = inputName.trim();

    if (cleanPan.length !== 10) {
      alert("Indian Income Tax PAN must be exactly 10 characters long.");
      return;
    }

    setIsVerifyingState(true);

    setTimeout(() => {
      setIsVerifyingState(false);
      
      // Verification results
      const linkAadhaar = Math.random() > 0.15; // 85% chance of linked
      const activeStatus = 'Active';

      // Insert verification log
      const newLog: VerificationLog = {
        id: `log_${Date.now()}`,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
        pan: cleanPan,
        name: cleanName,
        status: activeStatus,
        aadhaarStatus: linkAadhaar ? 'Linked' : 'Not Linked',
        type: 'API_VERIFY'
      };

      setVerificationHistory(prev => [newLog, ...prev]);
      
      // Call parent hook to register PAN in simulated records list
      onAddNewPanRecord(cleanPan, cleanName, true, linkAadhaar);
      
      // Clear fields
      setInputPan('');
      setInputName('');
      setSelectedPanId(cleanPan);
    }, 1200);
  };

  const formattingRupee = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(value);
  };

  return (
    <div id="pan-view" className="space-y-8 animate-fadeIn">
      {/* Top statistics Header summary counts */}
      <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <span className="font-mono text-xs uppercase tracking-wider text-indigo-500 font-semibold font-bold">NSDL PAN Registry</span>
          <h2 className="font-sans font-bold text-xl text-slate-800 tracking-tight flex items-center mt-0.5">
            <Users className="w-5.5 h-5.5 text-indigo-500 mr-2" />
            PAN & Aadhaar Compliance Registry
          </h2>
          <p className="font-sans text-xs text-slate-400 mt-0.5">
            Scanned <strong className="text-slate-600">{panRegistry.length} deductees</strong> in current tax returns database.
          </p>
        </div>

        {/* Aggregate Badging */}
        <div className="flex flex-wrap gap-3 text-xs">
          <div className="flex items-center space-x-2 bg-slate-50 border border-slate-250 px-3 py-1.5 rounded-xl">
            <Fingerprint className="w-4 h-4 text-emerald-500" />
            <span className="font-sans font-medium text-slate-600">Aadhaar Linked Check: <strong>{panRegistry.filter(p => p.aadhaarLinked).length} verified / {panRegistry.length}</strong></span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Panel 1: PAN Directory search list */}
        <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs flex flex-col h-[600px]">
          {/* Search bar */}
          <div className="relative mb-4">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input
              id="pan-search-input"
              type="text"
              placeholder="Search deductor name or PAN..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-slate-50 border border-slate-200/80 rounded-xl px-10 py-2 text-xs w-full focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-705"
            />
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {filteredPans.map(p => {
              const isSelected = activePan && activePan.pan === p.pan;
              return (
                <button
                  id={`pan-list-btn-${p.pan}`}
                  key={p.pan}
                  onClick={() => setSelectedPanId(p.pan)}
                  className={`w-full text-left p-3.5 rounded-2xl border transition duration-200 flex items-center justify-between ${
                    isSelected 
                      ? 'bg-indigo-50/50 border-indigo-200 text-indigo-900 shadow-3xs' 
                      : 'bg-white border-slate-100/80 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <div className="min-w-0">
                    <h4 className="font-sans font-bold text-xs text-slate-800 truncate" title={p.name}>
                      {p.name}
                    </h4>
                    <p className="font-mono text-[10px] text-slate-400 mt-1 uppercase">
                      {p.pan} <span className="mx-1">•</span> {p.recordsCount} filings
                    </p>
                  </div>
                  
                  <div className="flex flex-col items-end flex-shrink-0 ml-3">
                    <span className="font-mono font-semibold text-[11px] text-slate-750">{formattingRupee(p.totalTds)}</span>
                    <span className={`block text-[8px] font-bold px-1.5 rounded-full uppercase mt-1 ${p.aadhaarLinked ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                      {p.aadhaarLinked ? 'Linked' : 'Pending'}
                    </span>
                  </div>
                </button>
              );
            })}
            {filteredPans.length === 0 && (
              <div className="py-12 text-center text-slate-400 text-xs font-mono">
                No matching PAN records
              </div>
            )}
          </div>
        </div>

        {/* Panel 2: PAN TDS monthly & quarterly tracking breakdown details */}
        <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs h-[600px] flex flex-col justify-between overflow-y-auto">
          {activePan ? (
            <div className="space-y-6">
              {/* Header card details */}
              <div className="pb-4 border-b border-slate-100">
                <span className="font-sans text-[10px] uppercase font-bold text-slate-400">Selected Entity Ledger</span>
                <h3 className="font-sans font-extrabold text-sm text-slate-800 mt-1">{activePan.name}</h3>
                <div className="flex items-center space-x-2.5 mt-2">
                  <span className="font-mono text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded uppercase font-semibold">{activePan.pan}</span>
                  <span className={`font-sans text-[9px] font-bold px-2 py-0.5 rounded-full uppercase ${activePan.status === 'Active' ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-800'}`}>
                    PAN {activePan.status}
                  </span>
                </div>
              </div>

              {/* Total Financial stats */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3.5 bg-slate-50 border border-slate-100 rounded-2xl">
                  <span className="block font-sans text-[10px] text-slate-400">Taxable Payments</span>
                  <span className="font-mono text-sm font-bold text-slate-800 mt-1 block">{formattingRupee(activePan.totalAmount)}</span>
                </div>
                <div className="p-3.5 bg-indigo-50/40 border border-indigo-100 rounded-2xl">
                  <span className="block font-sans text-[10px] text-indigo-500">Tax Deducted (TDS)</span>
                  <span className="font-mono text-sm font-bold text-indigo-700 mt-1 block">{formattingRupee(activePan.totalTds)}</span>
                </div>
              </div>

              {/* Quarter wise Tracker */}
              <div>
                <h4 className="font-sans font-bold text-xs uppercase text-slate-700 tracking-wider mb-2 flex items-center">
                  <TrendingUp className="w-4 h-4 mr-1 text-slate-400" /> Quarter-wise Deductions
                </h4>
                <div className="grid grid-cols-4 gap-2">
                  {['Q1', 'Q2', 'Q3', 'Q4'].map(q => {
                    const amt = (activePan as any).quarterBreakdown[q] || 0;
                    return (
                      <div key={q} className="p-2.5 bg-slate-50/50 border border-slate-100/80 rounded-xl text-center">
                        <span className="block font-sans text-[10px] text-slate-400 font-semibold">{q}</span>
                        <span className="block font-mono text-[11px] font-bold text-slate-650 mt-1 truncate" title={formattingRupee(amt)}>
                          {amt > 0 ? formattingRupee(amt) : '₹0'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Month-wise Tracker */}
              <div>
                <h4 className="font-sans font-bold text-xs uppercase text-slate-700 tracking-wider mb-2">Month-wise Deductions</h4>
                <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                  {Object.keys(activePan.monthBreakdown).length > 0 ? (
                    Object.keys(activePan.monthBreakdown).map(mon => (
                      <div key={mon} className="flex items-center justify-between p-2 hover:bg-slate-50 rounded-lg">
                        <span className="font-sans text-xs text-slate-500">{mon} Ledger Statement</span>
                        <span className="font-mono text-xs font-bold text-slate-755 text-slate-700">{formattingRupee(activePan.monthBreakdown[mon]!)}</span>
                      </div>
                    ))
                  ) : (
                    <span className="font-mono text-[10px] text-slate-450 block italic">No month metadata mapped. Only quarterly file reports registered.</span>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-center">
              <span className="font-sans text-slate-400 text-xs italic">Select a deductee to view chronological monthly and quarterly trackers</span>
            </div>
          )}

          {/* Bottom Aadhaar warning prompt if unlinked */}
          {activePan && !activePan.aadhaarLinked && (
            <div className="mt-4 p-3 rounded-2xl bg-amber-50 border border-amber-200 text-[11px] text-amber-800 leading-relaxed font-sans">
              <strong>Risk Alert:</strong> Deductee's Aadhaar linkage is pending. Income Tax Department rules mandatorily require active linkage. Deduct at 1.5x rates to preempt audit queries on TRACES.
            </div>
          )}
        </div>

        {/* Panel 3: Add / Verify PAN Box & History logs */}
        <div className="space-y-6">
          {/* Form container */}
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs">
            <h3 className="font-sans font-bold text-slate-800 text-sm mb-3">Live Verify PAN via TRACES Utility</h3>
            
            <form onSubmit={handleVerifyPanSubmit} className="space-y-4">
              <div>
                <label className="font-sans text-[10px] text-slate-400 font-bold uppercase block mb-1">Deductee PAN (10 chars)</label>
                <input
                  id="pan-verify-input"
                  type="text"
                  maxLength={10}
                  placeholder="e.g. ABCDE1234F"
                  value={inputPan}
                  onChange={(e) => setInputPan(e.target.value.toUpperCase())}
                  className="w-full bg-slate-50 border border-slate-200/85 rounded-xl px-3.5 py-1.5 text-xs font-mono uppercase focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  required
                />
              </div>

              <div>
                <label className="font-sans text-[10px] text-slate-400 font-bold uppercase block mb-1">Official Name / Entity Title</label>
                <input
                  id="pan-verify-name"
                  type="text"
                  placeholder="e.g. Anand Sharma"
                  value={inputName}
                  onChange={(e) => setInputName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200/85 rounded-xl px-3.5 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  required
                />
              </div>

              <button
                id="pan-verify-submit-btn"
                type="submit"
                disabled={isVerifyingState}
                className="w-full flex items-center justify-center space-x-2 bg-slate-900 hover:bg-slate-950 active:scale-95 transition text-white font-bold font-sans text-xs py-2.5 rounded-xl uppercase tracking-wider disabled:opacity-40"
              >
                {isVerifyingState ? (
                  <>
                    <Activity className="w-4 h-4 text-slate-200 animate-spin" />
                    <span>Inquiring TRACES...</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4 text-white" />
                    <span>Execute Verify & Register</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* History log block */}
          <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-xs max-h-[290px] overflow-y-auto">
            <h4 className="font-sans font-bold text-slate-800 text-xs uppercase tracking-wider mb-3 flex items-center">
              <History className="w-4 h-4 mr-1 text-slate-400" /> Verification History
            </h4>

            <div className="space-y-3">
              {verificationHistory.map(log => (
                <div key={log.id} className="p-3 border border-slate-100 rounded-xl bg-slate-50/50 flex flex-col space-y-1">
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="font-mono text-slate-400">{log.timestamp}</span>
                    <span className="font-sans font-bold text-indigo-600 tracking-wider text-[8px] bg-indigo-50 px-1 rounded uppercase">
                      {log.type.replace('_', ' ')}
                    </span>
                  </div>
                  <h5 className="font-sans font-semibold text-xs text-slate-800 truncate">{log.name}</h5>
                  <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono">
                    <span>{log.pan}</span>
                    <span className="text-emerald-600 font-bold">● {log.aadhaarStatus}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
