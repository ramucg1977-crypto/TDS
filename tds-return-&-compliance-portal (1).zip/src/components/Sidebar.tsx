/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  ShieldCheck, 
  FolderOpen, 
  Users, 
  DownloadCloud,
  X,
  Building,
  Archive,
  Lock,
  Clock,
  BookOpen
} from 'lucide-react';
import { CompanyDetails } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  company: CompanyDetails | null;
  hasBackup: boolean;
  onLockSession?: () => void;
}

export default function Sidebar({ 
  activeTab, 
  setActiveTab, 
  isOpen, 
  setIsOpen, 
  company, 
  hasBackup,
  onLockSession 
}: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Analytics Dashboard', icon: LayoutDashboard },
    { id: 'tds_returns_24q', label: 'Salary Returns (24Q)', icon: FileText },
    { id: 'tds_returns_26q', label: 'Non-Salary Returns (26Q)', icon: FileText },
    { id: 'nri_returns', label: 'NRI Returns (27Q)', icon: FileText },
    { id: 'tcs_returns', label: 'TCS Returns (27EQ)', icon: FileText },
    { id: 'reconciliation', label: 'Reconciliation & Audits', icon: ShieldCheck },
    { id: 'documents', label: 'Document Locker', icon: FolderOpen },
    { id: 'pan', label: 'PAN & Contact Registry', icon: Users },
    { id: 'reports', label: 'Tax Report Builder', icon: DownloadCloud },
    { id: 'library', label: 'Tax Updates & Library', icon: BookOpen },
  ];

  if (hasBackup) {
    menuItems.push({ id: 'old_client', label: '(Old Client)', icon: Archive });
  }

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-40 lg:hidden transition-opacity duration-300"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <aside
        id="sidebar-container"
        className={`fixed inset-y-0 left-0 bg-slate-900 text-slate-100 w-72 transform ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 transition-transform duration-300 ease-in-out z-50 flex flex-col border-r border-slate-800 shadow-2xl`}
      >
        {/* Header Block / Logo */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <span className="font-sans font-bold text-lg text-white">IT</span>
            </div>
            <div>
              <h1 className="font-sans font-semibold text-sm tracking-tight text-white">TRACES Suite</h1>
              <span className="font-mono text-[10px] text-slate-400">e-TDS Filing v2.5</span>
            </div>
          </div>
          <button 
            id="close-sidebar-btn"
            className="lg:hidden p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 transition"
            onClick={() => setIsOpen(false)}
          >
            <X className="w-5 h-5 text-slate-300" />
          </button>
        </div>

        {/* Dynamic Company Quick Cards */}
        {company ? (
          <div className="mx-4 mt-6 p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <div className="flex items-start space-x-3">
              <div className="p-1 rounded bg-indigo-5050/10 text-indigo-400 mt-0.5">
                <Building className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-sans font-medium text-xs text-white truncate" title={company.companyName}>
                  {company.companyName}
                </h3>
                <p className="font-mono text-[10px] text-slate-400 mt-0.5 flex flex-col space-y-0.5">
                  <span className="flex items-center">
                    <span className="font-semibold text-[9px] bg-slate-800 text-slate-300 px-1 py-0.2 rounded mr-1">PAN:</span> {company.pan}
                  </span>
                  <span className="flex items-center">
                    <span className="font-semibold text-[9px] bg-slate-800 text-slate-300 px-1 py-0.2 rounded mr-1">TAN:</span> {company.tan}
                  </span>
                </p>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-800/80 flex justify-between items-center text-center">
              <div>
                <span className="block text-[8px] uppercase tracking-wider text-slate-500 font-semibold">Financial Year</span>
                <span className="font-mono text-[11px] text-indigo-300 font-medium">{company.financialYear}</span>
              </div>
              <div className="h-4 w-[1px] bg-slate-850" />
              <div>
                <span className="block text-[8px] uppercase tracking-wider text-slate-500 font-semibold">Assessment Year</span>
                <span className="font-mono text-[11px] text-indigo-300 font-medium">{company.assessmentYear}</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="mx-4 mt-6 p-4 rounded-xl bg-slate-950/20 border border-dashed border-slate-800/60 text-center">
            <p className="font-sans text-xs text-slate-500 font-light">No Active Company Profile</p>
            <span className="block font-mono text-[10px] text-slate-600 mt-1">Upload FVU or Form 16 to sync</span>
          </div>
        )}

        {/* Navigation Items */}
        <nav className="flex-1 px-4 py-8 space-y-1.5 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                id={`sidebar-item-${item.id}`}
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsOpen(false);
                }}
                className={`w-full flex items-center space-x-3.5 px-4 py-3 rounded-xl transition-all duration-200 text-left ${
                  isActive
                    ? 'bg-gradient-to-r from-indigo-500/10 to-indigo-500/5 border-l-4 border-indigo-500 text-indigo-300 font-medium'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/40 border-l-4 border-transparent'
                }`}
              >
                <Icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-indigo-400' : 'text-slate-400 hover:text-white'}`} />
                <span className="font-sans text-sm">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Secure session lock interface */}
        {onLockSession && (
          <div className="px-4 pb-2">
            <button
              onClick={onLockSession}
              className="w-full flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl bg-slate-950/40 hover:bg-rose-950/30 border border-slate-800 hover:border-rose-900/50 text-slate-400 hover:text-rose-400 text-xs font-sans transition cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Lock Audit Station</span>
            </button>
          </div>
        )}

        {/* Footer info lockup */}
        <div className="p-6 border-t border-slate-850 bg-slate-950/40 text-center">
          <p className="font-sans text-[10px] text-slate-500 font-medium">Compliance Monitoring Engine</p>
          <div className="flex items-center justify-center space-x-1 mt-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-mono text-[9px] text-emerald-400 font-semibold tracking-wider">SECURE CLIENT ENVIRONMENT</span>
          </div>
        </div>
      </aside>
    </>
  );
}
