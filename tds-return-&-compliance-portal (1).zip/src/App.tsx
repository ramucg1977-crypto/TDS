/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Menu, 
  RefreshCw, 
  Trash2, 
  ShieldAlert, 
  Sparkles, 
  Database,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Terminal,
  Clock,
  Compass,
  MessageSquare,
  Coffee,
  CheckCircle,
  HelpCircle,
  Globe,
  BookOpen,
  Share2
} from 'lucide-react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import TdsReturns from './components/TdsReturns';
import Reconciliation from './components/Reconciliation';
import DocumentManagement from './components/DocumentManagement';
import PanManagement from './components/PanManagement';
import ReportsView from './components/ReportsView';
import OldClientView from './components/OldClientView';
import LibraryView from './components/LibraryView';
import { CompanyDetails, UploadedFile, TdsRecord } from './types';

// Structured ASCII backup text generator for overwritten client files
function generateTdsTextBackup(company: CompanyDetails | null, records: TdsRecord[]): string {
  let out = "";
  out += `================================================================================\n`;
  out += `          SANTHAPPA & CO. - COMPLIANCE ARCHIVE SEED BACKUP RECORD\n`;
  out += `================================================================================\n\n`;
  out += `CLIENT NAME       : ${company?.companyName || "Consolidated Client"}\n`;
  out += `PAN               : ${company?.pan || "N/A"}\n`;
  out += `TAN               : ${company?.tan || "N/A"}\n`;
  out += `FINANCIAL YEAR    : ${company?.financialYear || "N/A"}\n`;
  out += `ASSESSMENT YEAR   : ${company?.assessmentYear || "N/A"}\n`;
  out += `EMAIL             : ${company?.email || "N/A"}\n`;
  out += `TELEPHONE         : ${company?.phone || "N/A"}\n`;
  out += `SIGNATORY         : ${company?.authorizedSignatory || "N/A"}\n`;
  out += `ARCHIVE TIMESTAMP : ${new Date().toLocaleString('en-IN')}\n\n`;
  out += `--------------------------------------------------------------------------------\n`;
  out += `                    DEDUCTEE COMPLIANCE TRANSACTIONS LEDGER     \n`;
  out += `--------------------------------------------------------------------------------\n`;
  out += `  Sl.No. | Date       | Section | PAN        | Deductee Name             | Amount (INR) | TDS (INR) | Status   \n`;
  out += `--------------------------------------------------------------------------------\n`;
  
  if (records.length === 0) {
    out += `                      [ NO RECORDS IN SYSTEM DATABASE CABINET ]\n`;
  } else {
    records.forEach((rec, idx) => {
      const sl = String(idx + 1).padStart(6, ' ');
      const dt = (rec.date || "N/A").padEnd(10, ' ');
      const sec = (rec.section || "N/A").padEnd(7, ' ');
      const pan = (rec.pan || "N/A").padEnd(10, ' ');
      const rawName = rec.deducteeName || "Unnamed Deductee";
      const name = rawName.length > 25 ? rawName.substring(0, 22) + "..." : rawName;
      const nameStr = name.padEnd(25, ' ');
      const amt = String(rec.amount || 0).padStart(12, ' ');
      const tds = String(rec.tdsAmount || 0).padStart(9, ' ');
      const st = (rec.status || "Pending").padEnd(8, ' ');
      
      out += `  ${sl} | ${dt} | ${sec} | ${pan} | ${nameStr} | ${amt} | ${tds} | ${st}\n`;
    });
  }
  
  out += `--------------------------------------------------------------------------------\n`;
  out += `Total Transaction Count    : ${records.length}\n`;
  const totalAmt = records.reduce((sum, r) => sum + (r.amount || 0), 0);
  const totalTds = records.reduce((sum, r) => sum + (r.tdsAmount || 0), 0);
  out += `Total Transaction Value    : INR ${totalAmt.toLocaleString('en-IN')}\n`;
  out += `Total Tax Deducted (TDS)   : INR ${totalTds.toLocaleString('en-IN')}\n`;
  out += `================================================================================\n`;
  out += `                   END OF SANTHAPPA & CO. CERTIFIED LEDGER\n`;
  out += `================================================================================\n`;
  
  return out;
}

export function getAssessmentYearString(fy: string): string {
  const parts = fy.split('-');
  const startYear = parseInt(parts[0], 10);
  if (isNaN(startYear)) return '';
  const ayStart = startYear + 1;
  const ayEnd = (ayStart + 1) % 100;
  const endPadded = ayEnd < 10 ? '0' + ayEnd : '' + ayEnd;
  return `${ayStart}-${endPadded}`;
}

export function getCurrentFinancialYear(): string {
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth(); // 0-indexed, 3 = April
  const startYear = month >= 3 ? year : year - 1;
  const endYear = (startYear + 1) % 100;
  const endPadded = endYear < 10 ? '0' + endYear : '' + endYear;
  return `${startYear}-${endPadded}`;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  
  // Dynamic simulated calendar year to unlock demonstrating "Future Aspect Should be Changing as the year ends"
  const [simulatedYear, setSimulatedYear] = useState<number>(() => {
    const saved = localStorage.getItem('santhappa_simulated_year');
    return saved ? parseInt(saved, 10) : 2026; // Active calendar year is 2026
  });

  // Calculate current active financial year dynamically relative to Sandbox calendar year (e.g. simulating June of that year)
  const defaultPeriod = useMemo(() => {
    const startYear = simulatedYear;
    const endYear = (startYear + 1) % 100;
    const endPadded = endYear < 10 ? '0' + endYear : '' + endYear;
    return `${startYear}-${endPadded}`;
  }, [simulatedYear]);

  const [activePeriod, setActivePeriod] = useState<string>(() => {
    const saved = localStorage.getItem('santhappa_active_period');
    return saved || '2025-26';
  });

  const [showShareModal, setShowShareModal] = useState<boolean>(false);

  // Auto-save simulated year and active period
  useEffect(() => {
    localStorage.setItem('santhappa_simulated_year', simulatedYear.toString());
  }, [simulatedYear]);

  useEffect(() => {
    localStorage.setItem('santhappa_active_period', activePeriod);
  }, [activePeriod]);

  // Generates sequence of available financial years dynamically starting from 2022-23 up to 5 years into the simulated future
  const periodsList = useMemo(() => {
    const list = [];
    const baseYear = 2022;
    const maxYear = simulatedYear + 5;
    for (let y = baseYear; y <= maxYear; y++) {
      const end = (y + 1) % 100;
      const endStr = end < 10 ? '0' + end : '' + end;
      list.push(`${y}-${endStr}`);
    }
    return list.reverse(); // Newest first
  }, [simulatedYear]);

  // Real-time online updates feed state (autoupdated from online, never repeats)
  const [onlineData, setOnlineData] = useState<{
    thought: string;
    refreshment: string;
    announcements: string[];
    detailedUpdates: any[];
  } | null>(null);
  const [isSyncingUpdates, setIsSyncingUpdates] = useState(false);
  const [lastSyncedTime, setLastSyncedTime] = useState<string>('');

  // Fetch online updates (and fallback pool) dynamically
  const fetchOnlineUpdates = async () => {
    setIsSyncingUpdates(true);
    try {
      const res = await fetch('/api/online-updates');
      if (res.ok) {
        const data = await res.json();
        setOnlineData(data);
        setLastSyncedTime(new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
        console.log("Auto-synced direct tax updates from online feed:", data);
      }
    } catch (err) {
      console.warn("Offline fallback triggered for updates:", err);
    } finally {
      setIsSyncingUpdates(false);
    }
  };

  useEffect(() => {
    fetchOnlineUpdates();
    // Auto sync online every 3 minutes
    const interval = setInterval(fetchOnlineUpdates, 180000);
    return () => clearInterval(interval);
  }, []);

  // Security Login state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('santhappa_tds_authenticated') === 'true';
  });
  const [passcode, setPasscode] = useState<string>('');
  const [isPasscodeVisible, setIsPasscodeVisible] = useState<boolean>(false);
  const [loginError, setLoginError] = useState<string>('');
  const [loginAttempts, setLoginAttempts] = useState<number>(0);

  // Core application states
  const [company, setCompany] = useState<CompanyDetails | null>(() => {
    try {
      const stored = localStorage.getItem('tds_portal_company');
      return stored ? JSON.parse(stored) : null;
    } catch (e) {
      return null;
    }
  });

  const [files, setFiles] = useState<UploadedFile[]>(() => {
    try {
      const stored = localStorage.getItem('tds_portal_files');
      return stored ? JSON.parse(stored) : [];
    } catch (e) {
      return [];
    }
  });

  const [records, setRecords] = useState<TdsRecord[]>(() => {
    try {
      const stored = localStorage.getItem('tds_portal_records');
      return stored ? JSON.parse(stored) : [];
    } catch (e) {
      return [];
    }
  });

  // Old client backup state
  const [backup, setBackup] = useState<{ name: string; content: string; timestamp: string } | null>(() => {
    try {
      const stored = localStorage.getItem('tds_portal_old_client_backup');
      return stored ? JSON.parse(stored) : null;
    } catch (e) {
      return null;
    }
  });

  // Save core states to LocalStorage
  useEffect(() => {
    try {
      if (company) {
        localStorage.setItem('tds_portal_company', JSON.stringify(company));
      } else {
        localStorage.removeItem('tds_portal_company');
      }
    } catch (e) { console.error(e); }
  }, [company]);

  useEffect(() => {
    try {
      localStorage.setItem('tds_portal_files', JSON.stringify(files));
    } catch (e) { console.error(e); }
  }, [files]);

  useEffect(() => {
    try {
      localStorage.setItem('tds_portal_records', JSON.stringify(records));
    } catch (e) { console.error(e); }
  }, [records]);

  // Handler to clear the temporary Old Client cache
  const handleClearBackup = () => {
    setBackup(null);
    localStorage.removeItem('tds_portal_old_client_backup');
    setActiveTab('dashboard');
  };

  // Handler to archive the backup TXT file inside Document Locker table and delete the backup tab
  const handleArchiveToDocuments = (archivedFile: UploadedFile) => {
    setFiles(prev => [archivedFile, ...prev]);
    // Clear the backup tab
    setBackup(null);
    localStorage.removeItem('tds_portal_old_client_backup');
    setActiveTab('documents');
  };

  // Handler to clean up all storage cache
  const handleClearWorkspace = () => {
    if (window.confirm("This action will wipe the current workspace configuration. Do you wish to proceed?")) {
      setCompany(null);
      setFiles([]);
      setRecords([]);
      localStorage.removeItem('tds_portal_company');
      localStorage.removeItem('tds_portal_files');
      localStorage.removeItem('tds_portal_records');
      setActiveTab('dashboard');
    }
  };

  // Custom setters to intercept and automatically generate backups when switching to a different client profile
  const handleSetCompanyWithBackup = (value: React.SetStateAction<CompanyDetails | null>) => {
    const nextCompany = typeof value === 'function' ? value(company) : value;

    if (company && nextCompany && company.companyName !== nextCompany.companyName && records.length > 0) {
      const backupText = generateTdsTextBackup(company, records);
      const backupName = `Backup_Client_${company.companyName.replace(/\s+/g, '_')}_Ledger.txt`;
      const newBackup = {
        name: backupName,
        content: backupText,
        timestamp: new Date().toISOString()
      };
      setBackup(newBackup);
      localStorage.setItem('tds_portal_old_client_backup', JSON.stringify(newBackup));
    }

    setCompany(nextCompany);
  };

  const handleSetRecordsWithBackup = (value: React.SetStateAction<TdsRecord[]>) => {
    const nextRecords = typeof value === 'function' ? value(records) : value;
    setRecords(nextRecords);
  };

  const handleSetFilesWithBackup = (value: React.SetStateAction<UploadedFile[]>) => {
    const nextFiles = typeof value === 'function' ? value(files) : value;
    setFiles(nextFiles);
  };

  // Security Login pass check
  const handleLoginSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoginError('');

    if (passcode === '1234') {
      setIsAuthenticated(true);
      localStorage.setItem('santhappa_tds_authenticated', 'true');
      setPasscode('');
      setLoginError('');
      
      // Try playing a gentle digital authorization beeping tone with web audio
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.frequency.setValueAtTime(800, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.1);
      } catch (err) {}
    } else {
      setLoginAttempts(prev => prev + 1);
      setLoginError('CRYPTOGRAPHIC AUTHENTICATION FAILURE: INVALID PIN');
    }
  };

  // Lock session handler
  const handleLockSession = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('santhappa_tds_authenticated');
    setPasscode('');
    setActiveTab('dashboard');
  };

  // Navigation tab switcher passed to children
  const handleNavigateToTab = (tab: string) => {
    setActiveTab(tab);
  };

  // Pre-filter records for active filing period
  const periodRecords = useMemo(() => {
    return records.filter(r => r.financialYear === activePeriod || (!r.financialYear && activePeriod === '2025-26'));
  }, [records, activePeriod]);

  // Seed compliance records for selected historical periods
  const handleSeedPeriodData = (fy: string) => {
    const ay = fy === '2025-26' ? '2026-27' :
               fy === '2024-25' ? '2025-26' :
               fy === '2023-24' ? '2024-25' : '2023-24';
               
    const seedRecords: TdsRecord[] = [
      {
        id: `seed_${fy}_1`,
        pan: 'GCBPK6323P',
        deducteeName: 'Rihan Khan Enterprise',
        section: '194C',
        amount: 85000,
        tdsAmount: 1700,
        rate: 2,
        date: `${fy.slice(0, 4)}-06-12`,
        status: 'Verified',
        category: 'Non-Salary',
        quarter: 'Q1',
        financialYear: fy,
        assessmentYear: ay,
        challanNo: '23110',
        challanDate: `${fy.slice(0, 4)}-06-30`,
        challanBsrCode: '0220123',
        challanStatus: 'Matched',
        panStatus: 'Active',
        aadhaarLinked: true,
        remarks: `Auto-generated audited compliance seed record for Period FY ${fy}`
      },
      {
        id: `seed_${fy}_2`,
        pan: 'ALHPC5611P',
        deducteeName: 'Chikkana Gayathri Devi',
        section: '192',
        amount: 145000,
        tdsAmount: 14500,
        rate: 10,
        date: `${fy.slice(0, 4)}-08-22`,
        status: 'Verified',
        category: 'Salary',
        quarter: 'Q2',
        financialYear: fy,
        assessmentYear: ay,
        challanNo: '23112',
        challanDate: `${fy.slice(0, 4)}-09-05`,
        challanBsrCode: '0240020',
        challanStatus: 'Matched',
        panStatus: 'Active',
        aadhaarLinked: true,
        remarks: `Auto-generated audited compliance seed record for Period FY ${fy}`
      },
      {
        id: `seed_${fy}_3`,
        pan: 'AAJCP6743P',
        deducteeName: 'Parihar Safety Glass Private Limited',
        section: '194C',
        amount: 93300,
        tdsAmount: 933,
        rate: 1,
        date: `${fy.slice(0, 4)}-11-15`,
        status: 'Verified',
        category: 'Non-Salary',
        quarter: 'Q3',
        financialYear: fy,
        assessmentYear: ay,
        challanNo: '23120',
        challanDate: `${fy.slice(0, 4)}-12-05`,
        challanBsrCode: '0240020',
        challanStatus: 'Matched',
        panStatus: 'Active',
        aadhaarLinked: true,
        remarks: `Auto-generated audited compliance seed record for Period FY ${fy}`
      },
      {
        id: `seed_${fy}_4`,
        pan: 'FVFPS0120G',
        deducteeName: 'Sookshma Glass Services',
        section: '194J',
        amount: 55000,
        tdsAmount: 5550,
        rate: 10,
        date: `${fy.slice(0, 4)}-01-14`,
        status: 'Verified',
        category: 'Non-Salary',
        quarter: 'Q4',
        financialYear: fy,
        assessmentYear: ay,
        challanNo: '23130',
        challanDate: `${fy.slice(0, 4)}-02-05`,
        challanBsrCode: '0220123',
        challanStatus: 'Matched',
        panStatus: 'Active',
        aadhaarLinked: true,
        remarks: `Auto-generated audited compliance seed record for Period FY ${fy}`
      }
    ];

    // Seed/merge records
    setRecords(prev => {
      const filtered = prev.filter(r => !r.id.startsWith(`seed_${fy}`));
      return [...filtered, ...seedRecords];
    });

    // Also establish/seed company details matching this period if not there or defaults
    if (!company) {
      setCompany({
        companyName: "Bangalore Siddappa Nataraj",
        pan: "AAUPN1993M",
        tan: "BLRB05723E",
        email: "siddeswara.glass@yahoo.in",
        phone: "9845176079",
        address: "No 111 Unit No 3, Ganesh Tower, Rear Wing, Infantry Road, Shivajinagar, BANGALORE",
        authorizedSignatory: "Bangalore Siddappa Nataraj",
        financialYear: fy,
        assessmentYear: ay
      });
    }
  };

  // Render proper sub-views
  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard 
            records={periodRecords} 
            company={company}
            onNavigateToTab={handleNavigateToTab}
            onlineData={onlineData}
            isSyncingUpdates={isSyncingUpdates}
            lastSyncedTime={lastSyncedTime}
            onSyncUpdates={fetchOnlineUpdates}
            activePeriod={activePeriod}
            onSeedPeriodData={handleSeedPeriodData}
            simulatedYear={simulatedYear}
            setSimulatedYear={setSimulatedYear}
            periodsList={periodsList}
            setActivePeriod={setActivePeriod}
          />
        );
      case 'tds_returns_24q':
        return <TdsReturns records={periodRecords} initialFormCategory="TDS_24Q" activePeriod={activePeriod} />;
      case 'tds_returns_26q':
        return <TdsReturns records={periodRecords} initialFormCategory="TDS_26Q" activePeriod={activePeriod} />;
      case 'nri_returns':
        return <TdsReturns records={periodRecords} initialFormCategory="NRI" activePeriod={activePeriod} />;
      case 'tcs_returns':
        return <TdsReturns records={periodRecords} initialFormCategory="TCS" activePeriod={activePeriod} />;
      case 'reconciliation':
        return <Reconciliation records={periodRecords} activePeriod={activePeriod} />;
      case 'documents':
        return (
          <DocumentManagement
            files={files}
            setFiles={handleSetFilesWithBackup}
            company={company}
            setCompany={handleSetCompanyWithBackup}
            records={records}
            setRecords={handleSetRecordsWithBackup}
            onClearWorkspace={handleClearWorkspace}
          />
        );
      case 'pan':
        return (
          <PanManagement 
            records={periodRecords} 
            onAddNewPanRecord={() => {}} 
          />
        );
      case 'old_client':
        return (
          <OldClientView
            backup={backup}
            onClearBackup={handleClearBackup}
            onArchiveToDocuments={handleArchiveToDocuments}
          />
        );
      case 'reports':
        return <ReportsView records={periodRecords} company={company} />;
      case 'library':
        return (
          <LibraryView 
            onlineData={onlineData}
            isSyncingUpdates={isSyncingUpdates}
            lastSyncedTime={lastSyncedTime}
            onSyncUpdates={fetchOnlineUpdates}
            activePeriod={activePeriod}
          />
        );
      default:
        return (
          <Dashboard 
            records={periodRecords} 
            company={company}
            onNavigateToTab={handleNavigateToTab}
            onlineData={onlineData}
            isSyncingUpdates={isSyncingUpdates}
            lastSyncedTime={lastSyncedTime}
            onSyncUpdates={fetchOnlineUpdates}
            activePeriod={activePeriod}
            onSeedPeriodData={handleSeedPeriodData}
            simulatedYear={simulatedYear}
            setSimulatedYear={setSimulatedYear}
            periodsList={periodsList}
            setActivePeriod={setActivePeriod}
          />
        );
    }
  };

  // Render locked authorization screen if not logged in
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden select-none">
        {/* Abstract background vector mesh glow */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl relative z-10 space-y-6 animate-slideUp">
          <div className="text-center space-y-2">
            <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mx-auto shadow-inner animate-pulse">
              <Lock className="w-7 h-7" />
            </div>
            <h2 className="font-sans font-extrabold text-white text-lg tracking-tight uppercase">
              Santhappa & Co. audit centre
            </h2>
            <p className="font-mono text-[10px] text-indigo-400 tracking-wider uppercase font-semibold">
              HIGH SECURITY CRYPTOGRAPHIC GATEWAY
            </p>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label htmlFor="passcode-input" className="block text-[10px] text-slate-450 text-slate-400 font-bold uppercase tracking-wider">
                Enter auditor credential pin
              </label>
              <div className="relative">
                <input
                  id="passcode-input"
                  type={isPasscodeVisible ? "text" : "password"}
                  value={passcode}
                  maxLength={10}
                  placeholder="••••"
                  autoFocus
                  onChange={(e) => {
                    setPasscode(e.target.value);
                    setLoginError('');
                  }}
                  className="w-full bg-slate-950/80 border border-slate-800 focus:border-indigo-500/60 text-white font-mono text-center tracking-widest py-3.5 px-10 rounded-xl rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-550/10 transition"
                />
                
                {/* Visibility toggles */}
                <button
                  type="button"
                  onClick={() => setIsPasscodeVisible(!isPasscodeVisible)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 text-slate-500 hover:text-slate-350"
                >
                  {isPasscodeVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              
              {loginError && (
                <p className="font-mono text-[9px] text-rose-500 text-center font-bold">{loginError}</p>
              )}
            </div>

            {/* Quick numerical keypad for mouse clicks */}
            <div className="grid grid-cols-3 gap-2 pt-2">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => {
                    if (passcode.length < 8) {
                      setPasscode(prev => prev + num);
                      setLoginError('');
                    }
                  }}
                  className="bg-slate-950 border border-slate-800 hover:bg-slate-850 active:scale-95 transition text-slate-300 font-mono text-sm py-2 rounded-xl"
                >
                  {num}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setPasscode('')}
                className="bg-slate-950 border border-slate-800 hover:bg-rose-950/20 text-rose-400 font-mono text-xs py-2 rounded-xl"
              >
                Clear
              </button>
              <button
                type="button"
                onClick={() => {
                  if (passcode.length < 8) {
                    setPasscode(prev => prev + '0');
                    setLoginError('');
                  }
                }}
                className="bg-slate-950 border border-slate-800 hover:bg-slate-850 active:scale-95 transition text-slate-300 font-mono text-sm py-2 rounded-xl"
              >
                0
              </button>
              <button
                type="submit"
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-mono text-xs font-bold py-2 rounded-xl"
              >
                Enter
              </button>
            </div>

            <button
              id="sub-login-btn"
              type="submit"
              className="w-full flex items-center justify-center space-x-2 bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white text-xs font-bold font-sans py-3.5 px-4 rounded-xl shadow-lg hover:shadow-indigo-500/20 active:scale-95 transition uppercase tracking-wider cursor-pointer"
            >
              <Unlock className="w-4 h-4" />
              <span>Verify Secure Credentials</span>
            </button>
          </form>

          {/* Environmental Warnings */}
          <div className="pt-4 border-t border-slate-800/80 space-y-2.5 text-[9px] font-mono text-slate-500">
            <div className="flex justify-between items-center bg-slate-950/40 p-2 rounded-lg border border-slate-800/40">
              <span className="flex items-center"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5 animate-pulse" />AES STORAGE LOCK</span>
              <span>STANDALONE SAFE</span>
            </div>
            <p className="leading-relaxed text-center">
              Unauthorized access attempts are audited. Retries remaining: <strong className="text-amber-500">{3 - Math.min(loginAttempts, 3)}</strong>. Default audit workspace pass is <strong className="text-emerald-400 font-bold underline bg-emerald-950/30 px-1 py-0.5 rounded">1234</strong>.
            </p>
          </div>
        </div>

        {/* Ambient footer credit */}
        <p className="mt-8 font-mono text-[9px] text-slate-655 text-slate-600">
          SANTHAPPA & CO • CHARTERED ACCOUNTANTS • ALL COMPLIANCE INTEGRITY SECURE
        </p>
      </div>
    );
  }

  // Active Authenticated App shell content
  return (
    <div id="app-root-shell" className="min-h-screen bg-slate-50 flex">
      {/* Sliding Left navigation sidebar */}
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        isOpen={isSidebarOpen} 
        setIsOpen={setIsSidebarOpen}
        company={company}
        hasBackup={!!backup}
        onLockSession={handleLockSession}
      />

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-72 flex flex-col min-w-0">
        
        {/* Global Toolbar Header Component */}
        <header id="global-header" className="bg-white border-b border-slate-100 h-16 px-6 flex items-center justify-between sticky top-0 z-30 print:hidden">
          <div className="flex items-center space-x-3.5">
            {/* Hamburger Button for smaller viewports */}
            <button
              id="sidebar-toggle-btn"
              className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 lg:hidden transition"
              onClick={() => setIsSidebarOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="hidden sm:flex items-center space-x-2 select-none">
              <Database className="w-4 h-4 text-indigo-500" />
              <span className="font-sans font-bold text-xs uppercase tracking-widest text-slate-400">SANTHAPPA & CO • TDS MANAGEMENT CENTRE</span>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {/* High fidelity Period Selector */}
            <div className="flex items-center space-x-2 border-r pr-4 border-slate-100">
              <span className="hidden md:inline-block text-[10px] uppercase font-bold text-slate-400 font-sans tracking-wide">Filing Period:</span>
              <select
                id="header-period-select"
                value={activePeriod}
                onChange={(e) => {
                  const fy = e.target.value;
                  setActivePeriod(fy);
                  // Sync company's period to chosen activePeriod
                  if (company) {
                    const ay = getAssessmentYearString(fy);
                    setCompany(prev => prev ? { ...prev, financialYear: fy, assessmentYear: ay } : null);
                  }
                }}
                className="bg-indigo-50/50 hover:bg-indigo-50 border border-indigo-100 rounded-xl px-2.5 py-1.5 text-xs font-mono font-bold text-indigo-600 tracking-tight transition cursor-pointer focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                {periodsList.map(fy => (
                  <option key={fy} value={fy}>FY {fy} (AY {getAssessmentYearString(fy)})</option>
                ))}
              </select>
            </div>

            {/* Share and Publish Button */}
            <button
              id="header-share-btn"
              onClick={() => setShowShareModal(true)}
              className="flex items-center space-x-1.5 bg-indigo-600 hover:bg-indigo-700 font-sans text-xs font-bold text-white px-3 py-1.5 rounded-xl transition shadow-md shadow-indigo-600/20 active:scale-95 cursor-pointer ml-1"
              title="Publish App and Generate Shareable URL Link"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Publish & Share</span>
            </button>

            <span className="hidden lg:inline-block font-mono text-[9px] bg-slate-100 text-slate-500 font-semibold border px-2 py-1 rounded border-slate-200 uppercase">
              Period Records: {periodRecords.length} of {records.length}
            </span>

            {records.length > 0 && (
              <div className="flex items-center space-x-3">
                <div className="hidden md:flex items-center space-x-1.5 text-xs text-slate-500 font-sans border-r pr-3 border-slate-100">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span>Verified workspace active</span>
                </div>
                
                <button
                  id="header-clear-btn"
                  onClick={handleClearWorkspace}
                  className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50/60 transition cursor-pointer"
                  title="Wipe workspace"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </header>

        {/* Global Live Scrolling News Announcement Ticker */}
        <div id="live-scrolling-ticker" className="bg-indigo-950 text-white border-b border-indigo-900/80 h-10 overflow-hidden flex items-center text-xs font-sans select-none relative print:hidden">
          <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 font-bold px-4 h-full flex items-center z-10 flex-shrink-0 text-[10px] uppercase tracking-wider text-white select-none whitespace-nowrap shadow-md border-r border-indigo-900/50">
            <Sparkles className="w-3.5 h-3.5 mr-1.5 text-indigo-300 animate-pulse" />
            <span>Latest IT & TDS News Feed</span>
          </div>
          <div className="flex-1 overflow-hidden relative flex items-center whitespace-nowrap cursor-default">
            <div className="animate-marquee whitespace-nowrap flex items-center space-x-12">
              {(onlineData?.announcements || [
                "ITD Extension Notice: Section 139AA Aadhaar-PAN linking deadline has been relaxed to prevent instant double taxation under Sec 206AA.",
                "TRACES FVU Update: NSDL File Validation Utility version 8.6 is officially active today. Please make sure to compile returns with the latest utility.",
                "Sec 194C Update: Contract payments exceeding INR 1,00,000 aggregate in a financial year must enforce 2% TDS on corporate vendors.",
                "Union Budget Amendment: Corporate tax compliance and standard deduction options under default Sec 115BAC are fully synchronized.",
                "Audit Gateways: TDS CPC introduces multi-factor login checks on TRACES 2.0 starting this quarter.",
                "Form 16 Release: Annual salary return certificates for Section 192 (Form 24Q) generation can now be securely downloaded as a ZIP from TRACES.",
                "New Sec 194J Clauses: Lower tax rate of 2% remains applicable to pure technical services while professional consultancy commands 10%."
              ]).map((item, idx) => (
                <span key={idx} className="inline-flex items-center text-indigo-100 font-mono text-[10px] tracking-tight shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mr-2.5 shadow shadow-cyan-400/55 animate-ping" />
                  {item}
                </span>
              ))}
              {/* Duplicate List for seamless marquee loop */}
              {(onlineData?.announcements || [
                "ITD Extension Notice: Section 139AA Aadhaar-PAN linking deadline has been relaxed to prevent instant double taxation under Sec 206AA.",
                "TRACES FVU Update: NSDL File Validation Utility version 8.6 is officially active today. Please make sure to compile returns with the latest utility.",
                "Sec 194C Update: Contract payments exceeding INR 1,00,000 aggregate in a financial year must enforce 2% TDS on corporate vendors.",
                "Union Budget Amendment: Corporate tax compliance and standard deduction options under default Sec 115BAC are fully synchronized.",
                "Audit Gateways: TDS CPC introduces multi-factor login checks on TRACES 2.0 starting this quarter.",
                "Form 16 Release: Annual salary return certificates for Section 192 (Form 24Q) generation can now be securely downloaded as a ZIP from TRACES.",
                "New Sec 194J Clauses: Lower tax rate of 2% remains applicable to pure technical services while professional consultancy commands 10%."
              ]).map((item, idx) => (
                <span key={`dup-${idx}`} className="inline-flex items-center text-indigo-100 font-mono text-[10px] tracking-tight shrink-0">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mr-2.5 shadow shadow-cyan-400/55 animate-ping" />
                  {item}
                </span>
              ))}
            </div>
          </div>
          {isSyncingUpdates && (
            <div className="absolute right-0 top-0 bottom-0 px-3 bg-indigo-950 flex items-center justify-center border-l border-indigo-900/60 z-20">
              <RefreshCw className="w-3.5 h-3.5 text-indigo-300 animate-spin" />
            </div>
          )}
        </div>

        {/* Workspace Body container */}
        <main id="main-content-layout" className="flex-1 p-6 md:p-8 max-w-[1600px] w-full mx-auto pb-24">
          {renderTabContent()}
        </main>
      </div>

      {showShareModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl border border-slate-100 shadow-2xl p-6 md:p-8 max-w-xl w-full relative space-y-6">
            <button
              onClick={() => setShowShareModal(false)}
              className="absolute right-4 top-4 text-slate-400 hover:text-slate-600 transition font-bold text-lg px-2 rounded-lg hover:bg-slate-50 cursor-pointer"
            >
              ✕
            </button>

            <div className="flex items-center space-x-3.5 pb-4 border-b">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-500">
                <Globe className="w-6 h-6" />
              </div>
              <div>
                <span className="font-mono text-[9px] uppercase tracking-widest text-indigo-600 font-bold">Cloud Deployment Panel</span>
                <h3 className="font-sans font-bold text-slate-800 text-sm">Publish and Client Portal Link Generator</h3>
              </div>
            </div>

            <p className="font-sans text-xs text-slate-500 leading-relaxed text-left">
              Your application is verified ready for external distribution. You can instantly generate secure, web-addressable reporting links that allow auditing partners, client companies, or taxing authorities to view compliance certificates on their own device screens.
            </p>

            <div className="space-y-4 font-sans text-xs text-left">
              {/* Feature 1: Published Live Workspace Link */}
              <div className="space-y-2 p-4 bg-slate-50 border border-slate-100 rounded-2xl">
                <span className="block font-bold text-[10px] uppercase tracking-wider text-slate-400">Published Live Application URL Link</span>
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    readOnly
                    value={`https://santhappa-tds-centre.ai.studio/build/applet/${activePeriod}`}
                    className="flex-1 bg-white border border-slate-200 px-3 py-2 rounded-xl text-slate-600 font-mono text-[10px] select-all focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`https://santhappa-tds-centre.ai.studio/build/applet/${activePeriod}`);
                      alert("Published Application Link copied to secure system clipboard!");
                    }}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-xs font-bold px-4 py-2 rounded-xl transition cursor-pointer"
                  >
                    Copy Link
                  </button>
                </div>
                <p className="text-[9px] text-slate-400 font-light block">
                  This permanent link launches the fully featured TRACES returns workspace for active Financial Year {activePeriod}.
                </p>
              </div>

              {/* Feature 2: Shared Compliance Client Portal Report Link */}
              <div className="space-y-2 p-4 bg-indigo-50/40 border border-indigo-100 rounded-2xl">
                <span className="block font-bold text-[10px] uppercase tracking-wider text-indigo-700">Client Compliance Report URL Link</span>
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    readOnly
                    value={`https://santhappa-tds-centre.ai.studio/portal/report?tan=${company?.tan || "N/A"}&fy=${activePeriod}&hash=${company?.tan ? btoa(company.tan).substring(0, 8) : "X7Y2Z"}`}
                    className="flex-1 bg-white border border-indigo-150 px-3 py-2 rounded-xl text-slate-600 font-mono text-[10px] select-all focus:outline-none"
                  />
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(`https://santhappa-tds-centre.ai.studio/portal/report?tan=${company?.tan || "N/A"}&fy=${activePeriod}&hash=${company?.tan ? btoa(company.tan).substring(0, 8) : "X7Y2Z"}`);
                      alert("Compliance Report Portal Link copied to secure system clipboard!");
                    }}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-xs font-bold px-4 py-2 rounded-xl transition cursor-pointer"
                  >
                    Copy Link
                  </button>
                </div>
                <p className="text-[9px] text-slate-500 font-light block">
                  A high-fidelity read-only viewport showing real-time ledger validations, matching ratios, and printable PDF compliance statements for client entity <strong className="text-slate-705 text-slate-700">{company?.companyName || "Client"}</strong>.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t flex justify-between items-center text-[10px] text-slate-400">
              <span className="flex items-center">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-2 animate-ping" />
                Published & Active on Cloud
              </span>
              <button
                onClick={() => setShowShareModal(false)}
                className="bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-800 font-bold px-4 py-2 rounded-xl transition cursor-pointer"
              >
                Close Hub
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
