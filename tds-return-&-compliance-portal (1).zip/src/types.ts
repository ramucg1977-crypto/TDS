/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface TdsRecord {
  id: string;
  pan: string;
  deducteeName: string;
  section: string;
  amount: number;
  tdsAmount: number;
  rate: number;
  date: string;
  status: 'Verified' | 'Pending' | 'Flagged';
  category: 'Salary' | 'Non-Salary' | 'NRI' | 'TCS'; // 24Q, 26Q, 27Q, 27EQ
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  financialYear: string;
  assessmentYear: string;
  challanNo: string;
  challanDate: string;
  challanBsrCode: string;
  challanStatus: 'Matched' | 'Unmatched' | 'Unpaid';
  panStatus: 'Active' | 'Inactive' | 'NotFound' | 'NoAadhaar';
  aadhaarLinked: boolean;
  remarks?: string;
}

export interface CompanyDetails {
  companyName: string;
  pan: string;
  tan: string;
  email: string;
  phone: string;
  address: string;
  authorizedSignatory: string;
  financialYear: string;
  assessmentYear: string;
}

export interface UploadedFile {
  id: string;
  name: string;
  type: 'FVU' | 'Excel' | 'PDF' | '26AS' | 'AIS' | 'Form 16' | 'Form 16B';
  size: string;
  uploadedAt: string;
  status: 'Processing' | 'Completed' | 'Failed';
  recordCount: number;
  extractedCompany?: Partial<CompanyDetails>;
}

export interface VerificationLog {
  id: string;
  timestamp: string;
  pan: string;
  name: string;
  status: string;
  aadhaarStatus: string;
  type: 'API_VERIFY' | 'TRACE_VERIFY';
}

export interface TdsSectionInfo {
  section: string;
  title: string;
  category: string;
  threshold: number;
  rateInd: number; // Rate for individuals/HUFs (percentage)
  rateCo: number; // Rate for companies (percentage)
  provisions: string;
  formType: string;
}
