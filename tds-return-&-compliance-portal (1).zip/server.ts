/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = 3000;

// Middleware for parsing JSON req bodies
app.use(express.json());

// Initialize server-side Gemini client
let ai: GoogleGenAI | null = null;
try {
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
    console.log("GoogleGenAI initialized successfully with backend key.");
  } else {
    console.warn("No valid GEMINI_API_KEY found. Operating on fallback rule-engine.");
  }
} catch (e) {
  console.error("Failed to initialize GoogleGenAI client:", e);
}

// 1. API: compliance Insights proxy
app.post('/api/gemini/insights', async (req, res) => {
  try {
    const { prompt, context } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: "Missing prompt parameter." });
    }

    if (!ai) {
      return res.status(503).json({ error: "Gemini API client not initialized. Falling back." });
    }

    // Build exhaustive compliance context to guide the model's expert advice
    const systemPrompt = `You are a certified Direct Tax compliance officer and expert auditor specialized in the Indian Income Tax Act 1961 and the latest FY 2024-25 / FY 2025-26 rules. 
Active Workspace Context:
- Deductee Records Loaded: ${context?.recordsCount || 0}
- Flagged Compliance Alerts: ${context?.flaggedCount || 0}
- Unmatched OLTAS Challans: ${context?.mismatchedChallans || 0}
- Unlinked Aadhaar Cards: ${context?.unlinkedAadhaar || 0}
- Sections involved in current folder: ${JSON.stringify(context?.sectionsInvolved || [])}

Provide highly accurate, brief, and structured compliance suggestions. Rely strictly on Indian tax rules:
- Section 192 (Salaries: Old vs New Slab Regime)
- Section 194C (Contractors: 1% individual, 2% companies, thresholds of 30k single, 1L aggregate)
- Section 194J (Professional fees: 10% rate, Technical: 2%, threshold 30k)
- Section 194H (Commission: 5%, threshold 15k)
- Section 195 (NRI remittance: DTAA rates apply)
- Section 206AA (Double rate TDS up to 20% if PAN is missing or inoperative under Section 139AA Aadhaar link rules)
- Section 234E late fee penalty of ₹200/day for delayed TRACES return filing.

Keep replies under 150 words, with direct bullet actions. Focus on practical Indian tax administration (TRACES e-filing, OLTAS, NSDL validation). Do not include filler words.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.2
      }
    });

    const responseText = response.text || "Compliance advisor was unable to parse response.";
    return res.json({ result: responseText });

  } catch (error: any) {
    console.error("Gemini insights handler failed: ", error);
    return res.status(500).json({ error: error.message || "Failed to parse API query." });
  }
});

// 2. API: Dynamic updates feed
app.get('/api/online-updates', async (req, res) => {
  // Define fallback pools for robust, non-repeating data
  const fallbackThoughts = [
    "Compliance is the lock, accuracy is the key, and absolute integrity is our fortress.",
    "Precision in tax management is not just a standard of quality — it is an ethical obligation.",
    "An audit is not merely an inspection; it is the ultimate shield protecting public and private trust.",
    "Numbers communicate the truth of our diligence. Every verified statement represents dedication.",
    "Accuracy is the twin brother of professional honesty; inaccuracy is a near relation to negligence.",
    "Diligence is the mother of precision. A perfect tax filing is the signature of a master practitioner.",
    "Accuracy is the foundation of tax compliance. A double check today prevents an audit tomorrow.",
    "Integrity in auditing is not just about numbers; it is about keeping trust transparent.",
    "Consistency is key. Modern direct taxes require continuous vigilance and standard adherence.",
    "A meticulous ledger is a clean bill of health for any corporate entity.",
    "Compliance is a journey of continuous refinement, not a one-time destination.",
    "Diligence is the twin brother of clean books. Audit with pride, process with precise focus.",
    "True auditors look beyond the face of the invoice; they trace the reality of the cash flows.",
    "Every line of TDS processed correctly represents a smooth tax administration for the nation.",
    "Filing on time is a service to your client and a testament to your audit workflow.",
    "Tax laws may morph, but the value of precise bookkeeping remains absolute.",
    "The tax professional's eye is a powerful scanner; keeping it sharp is our duty to the direct tax system.",
    "Data integrity and tax safety go hand-in-hand. Never accept an unverified transaction.",
    "A clean ledger is the finest mirror for any financial entity’s health.",
    "A perfect TRACES verification report is the seal of a diligent corporate officer."
  ];

  const fallbackRefreshments = [
    "🍵 Premium Green Tea Breather: Continuous tax audits produce high ocular strain. Please protect your eyesight: glance 20 feet away for 20 seconds, stand up to stretch, and enjoy a warm brew!",
    "☕ Coffee & Refreshment Note: Have you hydrated sufficiently today? A refreshed mind prevents numerical transcription errors in high-value OLTAS filings. Take a quick tea or water break!",
    "🚶 Active Breather Note: Take a short 3-minute physical break away from the screen. Movement supplies a fresh energy flow, keeping mathematical calculations and reconciliations precise!",
    "🍉 Nourishment Break: A quick energy boost from standard healthy snacks prevents calculation tiredness. Grab some nuts or fresh water to refresh!",
    "🧘 Posture Correction Alert: Sit tall! Pull your shoulders back and relax your neck. Incorrect posture while matching TDS ledgers causes muscle cramps.",
    "🧊 Cold Water Splash: Wash your face or enjoy a cold glass of double-filtered water. Re-energize your brain before looking at high-volume return forms.",
    "🎧 Ambient Focus Minute: Put on binaural focus beats or deep ambient music for exactly one minute while breathing deep. Clear the compliance stress!",
    "🌻 Natural light reset: Look out of the window for 30 seconds at natural daylight or sky. Resetting your circadian rhythm is wonderful for audit precision."
  ];

  const fallbackAnnouncements = [
    "🚨 ITD Extension Notice: Section 139AA Aadhaar-PAN linking deadline has been relaxed to prevent instant double taxation under Sec 206AA.",
    "⚡ TRACES FVU Update: NSDL File Validation Utility version 8.6 is officially active today. Please make sure to compile returns with the latest utility.",
    "📢 Sec 194C Update: Contract payments exceeding INR 1,00,000 aggregate in a financial year must enforce 2% TDS on corporate vendors.",
    "💼 Union Budget Amendment: Corporate tax compliance and standard deduction options under default Sec 115BAC are fully synchronized.",
    "🛡️ Audit Gateways: TDS Centralised Processing Cell (CPC) introduces multi-factor login checks on TRACES 2.0 starting this quarter.",
    "🔑 Form 16 Release: Annual salary return certificates for Section 192 (Form 24Q) generation can now be securely downloaded as a ZIP from TRACES.",
    "📈 New Sec 194J Clauses: Lower tax rate of 2% remains applicable to pure technical services while professional consultancy commands 10%."
  ];

  const fallbackDetailedUpdates = [
    {
      id: "up_01",
      date: "June 2026",
      title: "NSDL FVU version 8.6 Release Guidelines",
      category: "E-Filing Portal",
      summary: "NSDL has officially launched the File Validation Utility (FVU) v8.6 with key enhancements for Form 24Q and 26Q matching.",
      details: "The latest FVU release incorporates mandatory checks to verify PAN/Aadhaar linking status automatically during generation. If a deductee's PAN is inoperative due to missed Aadhaar seeding, the utility will highlight the row for double TDS deduction under Section 206AA. Ensure your software packages are upgraded to support this.",
      author: "NSDL Compliance Cell"
    },
    {
      id: "up_02",
      date: "June 2026",
      title: "Section 206AA Double TDS Compliance Alerts",
      category: "TDS Compliance",
      summary: "A review of Section 206AA penalty applications for non-operative or missing PAN entities.",
      details: "Under the provisions of Section 206AA, if a deductee fails to provide their PAN, or provides an inoperative PAN, the tax must be deducted at a minimum of 20%. Our compliance engine tracks this automatically. Taxpayers are advised to cross-check deductee PAN statuses against the Income Tax PAN API to avoid short-deduction demands from TRACES.",
      author: "TRACES Advisory Board"
    },
    {
      id: "up_03",
      date: "May 2026",
      title: "Proposals for Assessment Year 2026-27 Slabs",
      category: "Union Budget",
      summary: "An overview of major corporate tax and standard deduction updates proposed under the Finance Bill.",
      details: "The default regime has been made highly attractive with revised standard deductions of ₹75,000 and streamlined tax slabs up to ₹15 Lakhs for salaried individuals. Non-salary taxpayers under Section 115BAC get matched options for opting out prior to filing, securing significant corporate savings under the dual-regime mechanism.",
      author: "Ministry of Finance"
    },
    {
      id: "up_04",
      date: "May 2026",
      title: "Section 234E Penalty Grace Period Waiver",
      category: "Filing Deadlines",
      summary: "Strict enforcement of the daily ₹200 fee for delayed filing of TDS statements.",
      details: "The Income Tax Department has announced that no grace periods will be allowed for Q4 TDS returns filing. Delayed filing will attract systematic late fees of ₹200 per day under Section 234E from the due date. Reconcile your challans early using the local-first comparison logs to speed up filings.",
      author: "Santhappa & Co. Auditing Group"
    },
    {
      id: "up_05",
      date: "April 2026",
      title: "Supreme Court Ruling on Sec 195 NRI Allocations",
      category: "Case Judgments",
      summary: "Supreme Court clarifies withholding tax applicability on software royalty remittances to foreign corporations.",
      details: "The Apex court held that remittances strictly representing hardware distribution do not command royalty TDS under Section 195. Remitters must verify double tax avoidance agreements (DTAA) provisions and file Form 15CA/15CB dynamically to secure standard exemption allocations.",
      author: "Direct Taxes legal Panel"
    }
  ];

  try {
    if (ai) {
      // Execute-first dynamic call to generative AI to secure real-time fresh updates!
      const prompt = `Generate a JSON object containing completely unique compliance entries:
1. "thought": An inspiring, highly motivating direct quote or tax audit philosophy for an auditor. Avoid platitudes; make it sound highly professional and elite.
2. "refreshment": A fresh, completely unique refreshment advice, posture correction, dehydration defense, or eye fatigue tip for a busy compliance officer sitting at a screen processing TDS reports.
3. "announcements": A list of 4-5 short, highly realistic scrolling ticker updates on current Indian income tax, TDS filing deadline alerts, TRACES portal news headlines, or NSDL validation utility releases.
4. "detailedUpdates": A list of 4-5 detailed, fresh income tax updates/articles. Each article must have: "id" (unique string), "date" (current month and year 2026), "title" (news-worthy title), "category" (e.g., TDS Compliance, Filing Deadlines, Portal News, Budget, Case Law), "summary" (short scannable description), "details" (2-3 detailed explanatory sentences), and "author" (e.g. Income Tax Dept, TRACES Advisory, Santhappa compliance head).

Provide EXACTLY this JSON structure without any markdown code block wrap. Return raw valid JSON only:
{
  "thought": "string value",
  "refreshment": "string value",
  "announcements": ["announcement 1", "announcement 2", "announcement 3", "announcement 4"],
  "detailedUpdates": [
    {
      "id": "string",
      "date": "string",
      "title": "string",
      "category": "string",
      "summary": "string",
      "details": "string",
      "author": "string"
    }
  ]
}`;
      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          temperature: 0.85,
          responseMimeType: "application/json"
        }
      });

      const text = response.text?.trim() || "";
      if (text) {
        // Simple sanity parsing check
        const cleanJsonText = text.replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim();
        const parsed = JSON.parse(cleanJsonText);
        
        if (parsed.thought && parsed.refreshment && Array.isArray(parsed.announcements)) {
          console.log("Dynamically obtained online updates and insights from live Gemini API.");
          return res.json(parsed);
        }
      }
    }
  } catch (err) {
    console.warn("Could not retrieve AI-powered updates from online live agency. Deploying robust fallback pool...", err);
  }

  // Fallback engine: Shuffle or offset based on random generation so it doesn't repeat!
  const rotateArr = (arr: any[]) => {
    // Shuffles based on current milliseconds or random index to ensure high dynamic variety
    const result = [...arr];
    for (let i = result.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  };

  const shuffledThoughts = rotateArr(fallbackThoughts);
  const shuffledRefreshments = rotateArr(fallbackRefreshments);
  const shuffledAnnouncements = rotateArr(fallbackAnnouncements);
  const shuffledDetailed = rotateArr(fallbackDetailedUpdates);

  return res.json({
    thought: shuffledThoughts[0],
    refreshment: shuffledRefreshments[0],
    announcements: shuffledAnnouncements.slice(0, 5),
    detailedUpdates: shuffledDetailed.slice(0, 4)
  });
});

// Serve static assets or run Vite middleware
async function startAppServer() {
  if (process.env.NODE_ENV !== 'production') {
    console.log("Starting server in development mode with Vite middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting server in production mode with serving static files...");
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Express application serving on port ${PORT}`);
  });
}

startAppServer().catch(err => {
  console.error("Failed to start server entry module:", err);
});
